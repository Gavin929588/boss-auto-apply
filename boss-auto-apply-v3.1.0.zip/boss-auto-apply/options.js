'use strict';

var $ = function (id) { return document.getElementById(id); };
var current = null;

var SEL_LABELS = {
  jobCard: '岗位卡片（最关键）', title: '岗位名称', salary: '薪资', company: '公司名称',
  link: '岗位链接', infoBlock: '城市/经验/学历信息块', tagList: '岗位标签',
  companyInfo: '城市/区域信息', chatButton: '立即沟通按钮（详情页）', applyButton: '投简历按钮',
  detailBox: '岗位详情面板', detailName: '详情内岗位名',
  nextPage: '下一页按钮', loadMore: '加载更多按钮', dialog: '沟通弹窗',
  dialogInput: '招呼语输入框', dialogSend: '发送按钮', verification: '验证组件',
  chatSessionItem: '沟通页会话条目（li）', chatComposer: '沟通页聊天输入框（#chat-input）',
  chatSend: '沟通页发送按钮（button.btn-send）', chatConversationHead: '当前会话头部信息',
  chatMessage: '聊天消息元素', chatFrame: '沟通页 iframe'
};

function toast(msg) {
  var el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(function () { el.remove(); }, 2600);
}

function esc(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function splitList(v) {
  return String(v || '').split(/[\n,，;；]/).map(function (x) { return x.trim(); }).filter(Boolean);
}
function getPath(obj, parts) {
  var cur = obj;
  for (var i = 0; i < parts.length; i++) {
    if (cur === undefined || cur === null) return undefined;
    cur = cur[parts[i]];
  }
  return cur;
}
function setPath(obj, parts, val) {
  var cur = obj;
  for (var i = 0; i < parts.length - 1; i++) {
    if (!cur[parts[i]] || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
    cur = cur[parts[i]];
  }
  cur[parts[parts.length - 1]] = val;
}

/* ---------------- Tabs ---------------- */
Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (btn) {
  btn.onclick = function () {
    Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (b) { b.classList.remove('active'); });
    Array.prototype.forEach.call(document.querySelectorAll('.tabpane'), function (p) { p.classList.remove('active'); });
    btn.classList.add('active');
    document.querySelector('.tabpane[data-pane="' + btn.dataset.tab + '"]').classList.add('active');
    if (btn.dataset.tab === 'data') refreshData();
  };
});

/* ---------------- Tasks ---------------- */
$('platformSelect').onchange = function () { switchPlatform(this.value); };

function cityOptions(selected) {
  var list = (current && current.cities) || BAA.CITY_OPTIONS_BOSS;
  var opts = list.map(function (c) {
    return '<option value="' + c.code + '"' + (c.code === selected ? ' selected' : '') + '>' + esc(c.name) + '</option>';
  });
  if (selected && !list.some(function (c) { return c.code === selected; })) {
    opts.unshift('<option value="' + esc(selected) + '" selected>自定义：' + esc(selected) + '</option>');
  }
  return opts.join('');
}

function renderTasks(tasks) {
  $('taskBody').innerHTML = (tasks || []).map(function (t) {
    return '<tr>' +
      '<td><input type="text" data-t="query" value="' + esc(t.query) + '" placeholder="如：新媒体运营"></td>' +
      '<td><select data-t="city">' + cityOptions(t.city) + '</select></td>' +
      '<td style="text-align:center"><input type="checkbox" data-t="enabled"' + (t.enabled !== false ? ' checked' : '') + '></td>' +
      '<td><button class="sm danger" data-del-task>删除</button></td>' +
      '</tr>';
  }).join('');
}

function readTasks() {
  return Array.prototype.slice.call($('taskBody').querySelectorAll('tr')).map(function (tr) {
    var sel = tr.querySelector('[data-t="city"]');
    return {
      query: tr.querySelector('[data-t="query"]').value.trim(),
      city: sel.value,
      cityName: sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '',
      enabled: tr.querySelector('[data-t="enabled"]').checked
    };
  }).filter(function (t) { return t.query; });
}

/* ---------------- Advanced rules ---------------- */
function fieldOptions(sel) {
  return Object.keys(BAA.FIELDS).map(function (k) {
    return '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + esc(BAA.FIELDS[k]) + '</option>';
  }).join('');
}
function opOptions(sel) {
  return Object.keys(BAA.OPS).map(function (k) {
    return '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + esc(BAA.OPS[k]) + '</option>';
  }).join('');
}
function renderRules(rules) {
  $('ruleBody').innerHTML = (rules || []).map(function (r) {
    return '<tr>' +
      '<td><select data-r="field">' + fieldOptions(r.field) + '</select></td>' +
      '<td><select data-r="op">' + opOptions(r.op) + '</select></td>' +
      '<td><input type="text" data-r="value" value="' + esc(r.value) + '" placeholder="值 / 正则"></td>' +
      '<td style="text-align:center"><input type="checkbox" data-r="enabled"' + (r.enabled !== false ? ' checked' : '') + '></td>' +
      '<td><button class="sm danger" data-del-rule>删除</button></td>' +
      '</tr>';
  }).join('') || '<tr><td colspan="5" class="hint">暂无规则，点下方添加</td></tr>';
}
function readRules() {
  return Array.prototype.slice.call($('ruleBody').querySelectorAll('tr')).filter(function (tr) {
    return tr.querySelector('[data-r="field"]');
  }).map(function (tr) {
    return {
      field: tr.querySelector('[data-r="field"]').value,
      op: tr.querySelector('[data-r="op"]').value,
      value: tr.querySelector('[data-r="value"]').value,
      enabled: tr.querySelector('[data-r="enabled"]').checked
    };
  });
}

/* ---------------- Selectors (two independent platform lists) ---------------- */
/* v2.6: BOSS and 鱼泡 each own a SEPARATE selector + login-detection list,
   stored under overrides[platform]. Editing one can never overwrite the other,
   which is what caused "切换平台后选择器/登录判定不更新" before. */
var selectorCache = null;   // { boss: {selectors, login}, yupao: {...} }
var editPlatform = 'boss';

var LOGIN_LABELS = {
  sessionCookies: '登录会话 cookie（强证据，仅登录后才有）',
  guestSelectors: '未登录特征选择器（必须可见）',
  guestTexts: '未登录特征文本',
  loggedSelectors: '已登录特征选择器',
  loggedTexts: '已登录特征文本',
  cookieNames: '登录态 cookie 名（只记录名称）'
};

function buildSelectorCache(baseCfg) {
  var cache = {};
  BAA.PLATFORM_IDS.forEach(function (id) {
    var view = BAA.getPlatformView(baseCfg, id);
    cache[id] = {
      selectors: BAA.clone(view.selectors || {}),
      login: BAA.clone(view.login || {})
    };
  });
  return cache;
}

function renderSelectorPlatforms() {
  var sel = $('selectorPlatform');
  if (!sel) return;
  sel.innerHTML = BAA.PLATFORM_IDS.map(function (id) {
    return '<option value="' + id + '"' + (id === editPlatform ? ' selected' : '') + '>' +
      esc(BAA.platformName(id)) + ' 选择器</option>';
  }).join('');
  var hint = $('selectorSavedHint');
  if (hint) {
    var other = BAA.PLATFORM_IDS.filter(function (x) { return x !== editPlatform; })[0];
    hint.textContent = '当前编辑：' + BAA.platformName(editPlatform) +
      (other ? '（与 ' + BAA.platformName(other) + ' 互不影响）' : '');
  }
}

function renderSelectorEditor() {
  if (!selectorCache) selectorCache = buildSelectorCache(current || BAA.DEFAULT_CONFIG);
  var id = editPlatform;
  var def = (BAA.PLATFORM_DEFAULTS[id] || BAA.PLATFORM_DEFAULTS.boss);
  var cur = selectorCache[id] || { selectors: {}, login: {} };

  $('selectorGrid').innerHTML = Object.keys(def.selectors || {}).map(function (k) {
    var val = (cur.selectors && cur.selectors[k]) || def.selectors[k] || [];
    return '<div class="field"><label>' + esc(SEL_LABELS[k] || k) +
      ' <span style="color:#5f6e86">(' + k + ')</span></label>' +
      '<textarea data-sel="' + k + '" rows="3">' + esc((val || []).join('\n')) + '</textarea></div>';
  }).join('');

  $('loginGrid').innerHTML = Object.keys(LOGIN_LABELS).map(function (k) {
    var val = (cur.login && cur.login[k]) || [];
    return '<div class="field"><label>' + esc(LOGIN_LABELS[k]) +
      ' <span style="color:#5f6e86">(' + k + ')</span></label>' +
      '<textarea data-login="' + k + '" rows="3">' + esc((val || []).join('\n')) + '</textarea></div>';
  }).join('');

  renderSelectorPlatforms();
}

function readSelectorEditor() {
  if (!selectorCache) selectorCache = {};
  var out = { selectors: {}, login: {} };
  Array.prototype.forEach.call(document.querySelectorAll('#selectorGrid [data-sel]'), function (el) {
    out.selectors[el.dataset.sel] = splitList(el.value);
  });
  Array.prototype.forEach.call(document.querySelectorAll('#loginGrid [data-login]'), function (el) {
    out.login[el.dataset.login] = splitList(el.value);
  });
  // Don't wipe a platform's cache when the grid happens to be empty.
  if (Object.keys(out.selectors).length || Object.keys(out.login).length) {
    selectorCache[editPlatform] = out;
  }
}

if ($('selectorPlatform')) {
  $('selectorPlatform').onchange = function () {
    readSelectorEditor();
    editPlatform = this.value;
    renderSelectorEditor();
  };
}

if ($('btnResetSelectors')) {
  $('btnResetSelectors').onclick = function () {
    var id = editPlatform;
    var def = BAA.PLATFORM_DEFAULTS[id] || BAA.PLATFORM_DEFAULTS.boss;
    if (current && current.overrides && current.overrides[id]) {
      delete current.overrides[id].selectors;
      delete current.overrides[id].login;
    }
    selectorCache[id] = {
      selectors: BAA.clone(def.selectors || {}),
      login: BAA.clone(def.login || {})
    };
    renderSelectorEditor();
    toast('已恢复 ' + BAA.platformName(id) + ' 的默认选择器，点「保存全部设置」后生效');
  };
}

/* ---------------- Platform switcher ---------------- */
function populatePlatforms() {
  var sel = $('platformSelect');
  if (!sel) return;
  var cur = (current && current.platform) || 'boss';
  sel.innerHTML = BAA.PLATFORM_IDS.map(function (id) {
    return '<option value="' + id + '"' + (id === cur ? ' selected' : '') + '>' +
      esc(BAA.platformName(id)) + '</option>';
  }).join('');
  sel.value = cur;
}

var switchingPlatform = false;

function renderSwitchState() {
  var el = $('platformSwitchState');
  if (!el) return;
  var cur = (current && current.platform) || 'boss';
  el.innerHTML = '当前编辑：<b style="color:#a8c7ff">' + esc(BAA.platformName(cur)) + '</b>' +
    ' · 下面几个页签都是这个平台自己的设置';
}

/* v3.1: 把「本平台写死的那套规则」直接列出来。
   以前要知道这个平台跑什么，得把五个页签挨个点一遍；现在一眼看完。
   这套是 BAA.PLATFORM_PRESETS 里的常量，切换平台时自动套用。 */
function renderPreset() {
  var el = $('presetSummary');
  if (!el || !current) return;
  var id = current.platform || 'boss';
  var p = BAA.getPlatformPreset(id);
  var tasks = (p.tasks || []).filter(function (t) { return t && String(t.query || '').trim(); });
  var taskText = tasks.length
    ? tasks.map(function (t) {
        var cn = t.cityName || '', cc = String(t.city || '');
        return t.query + ' · ' + cn + (cc ? '(' + cc + ')' : '');
      }).join('；')
    : '（无）';
  var f = p.filter || {};
  var b = p.behavior || {};
  var excl = (f.titleExclude || []).length
    ? '排除 ' + (f.titleExclude || []).length + ' 个词：' + (f.titleExclude || []).join('/')
    : '未设排除词';
  var salary = (Number(f.salaryMin) || 0) + '-' +
    (Number(f.salaryMax) ? Number(f.salaryMax) + 'K' : '不限');
  var schedOn = !!(p.schedule && p.schedule.enabled);
  var lines = [
    '<b>搜索任务</b>：' + esc(taskText),
    '<b>筛选</b>：薪资 ' + esc(salary) + ' · ' + esc(excl),
    '<b>行为</b>：每日 ' + (Number(b.dailyLimit) || 0) + ' 个 · 最多 ' + (Number(b.maxPagesPerTask) || 0) +
      ' 页/任务 · 每页 ' + (Number(b.maxJobsPerPage) > 0 ? Number(b.maxJobsPerPage) + ' 个' : '不限') +
      ' · ' + esc(b.action === 'chat' ? '立即沟通' : (b.action || 'chat')) +
      ' · 招呼语' + (b.chatGreetingEnabled === false ? '关' : '开') +
      (b.dedupeByCompany === false ? '' : ' · 同公司只打一次'),
    '<b>定时</b>：' + (schedOn ? '已启用' : '未启用（手动点「开始」）')
  ];
  el.innerHTML = lines.map(function (x) { return '<div>' + x + '</div>'; }).join('');
}

if ($('btnOpenPlatform')) {
  $('btnOpenPlatform').onclick = async function () {
    var id = (current && current.platform) || 'boss';
    var r = await chrome.runtime.sendMessage({ type: 'BAA_FOCUS_PLATFORM', platform: id });
    toast(r && r.ok ? ('已打开' + BAA.platformName(id) + '页面') : ((r && r.msg) || '打开失败'));
  };
}

if ($('btnResetPreset')) {
  $('btnResetPreset').onclick = async function () {
    var id = (current && current.platform) || 'boss';
    if (!confirm('把「' + BAA.platformName(id) + '」的任务 / 筛选 / 行为 / 定时全部恢复成内置规则？\n\n' +
      '只影响这个平台，另一个平台的设置不会被改动。')) return;
    try {
      var cfg = collect();
      cfg.platform = id;
      BAA.applyPlatformPreset(cfg, id);
      await BAA.saveConfig(cfg);
      var fresh = await BAA.getConfig();
      fill(fresh);
      previewSchedule();
      toast('已恢复「' + BAA.platformName(id) + '」的内置规则');
    } catch (e) {
      toast('恢复失败：' + String(e && e.message || e));
    }
  };
}

/* v3.0 重写。v2.x 的写法有两个坑：
 *   1) 切换只改 tasks/selectors，而 filter/behavior/schedule/advancedRules 存在
 *      配置顶层共用 —— 切完平台下面几个页签一模一样，看起来「没切换」。
 *   2) 全程 await 后台消息，失败就什么都没有：<select> 已经被浏览器改成新值，
 *      而 current 还是旧平台，再选同一项不会再触发 change，界面就永久卡在
 *      「选了鱼泡、内容是 BOSS」，用户只能刷新 —— 这就是「切不过来、卡死」。
 * 现在：本地先存当前平台这套 → 后台尽力而为（失败只提示）→ 回读真实配置整页重渲染
 *      → 最后用真实 platform 复位 <select>，任何失败都不会留下错位状态。
 */
function switchPlatform(p) {
  var sel = $('platformSelect');
  var prev = (current && current.platform) || 'boss';
  if (!BAA.PLATFORM_DEFAULTS[p]) { populatePlatforms(); return; }
  if (p === prev || switchingPlatform) { populatePlatforms(); return; }

  switchingPlatform = true;
  if (sel) { sel.disabled = true; }
  var stateEl = $('platformSwitchState');
  if (stateEl) stateEl.textContent = '正在切换到 ' + BAA.platformName(p) + '…（保存当前平台配置）';

  (async function () {
    var bgMsg = '', bgWarn = '';
    try {
      // 1) 先把当前平台这一整套存进它自己的槽（不依赖后台，纯本地存储）
      var cfg = collect();
      cfg.platform = prev;
      await BAA.saveConfig(cfg);

      // 2) 让后台切平台：重置运行/登录态。失败不阻塞。
      //    v3.0: 不再清 cookie —— 切个页签就退出登录没有任何道理，还逼用户每次
      //    重新扫码。要真正退出某个平台，用旁边的「清除本平台 Cookie」按钮。
      try {
        // 设置页切平台不抢走当前标签页（goto:false）；需要看该平台页面时点
        // 上方「打开该平台页面」。插件面板里切平台则会自动带过去。
        var r = await chrome.runtime.sendMessage({
          type: 'BAA_SET_PLATFORM', platform: p, clearOldCookies: false, goto: false
        });
        if (r && r.ok === false) bgWarn = r.msg || '后台未完成切换';
        else if (r && r.msg) bgMsg = r.msg;
      } catch (e) {
        bgWarn = String(e && e.message || e);
      }

      // 3) 回读真实配置并整页重渲染 —— 七个页签全部换成这个平台自己的那份
      var fresh = await BAA.getConfig();
      current = BAA.clone(fresh);
      fill(fresh);
      previewSchedule();
      var dataPane = document.querySelector('.tabpane[data-pane="data"]');
      if (dataPane && dataPane.classList.contains('active')) refreshData();
      BAA.log('info', '平台已切换：' + BAA.platformName(fresh.platform) + '（两个平台配置各自独立）');
      toast(bgWarn ? ('已切到 ' + BAA.platformName(fresh.platform) + '；后台提示：' + bgWarn)
                   : (bgMsg || ('已切换到 ' + BAA.platformName(fresh.platform))));
    } catch (e) {
      toast('切换失败：' + String(e && e.message || e));
    } finally {
      switchingPlatform = false;
      if (sel) { sel.disabled = false; }
      // 关键：<select> 永远以真实 storage 里的 platform 为准，杜绝错位假死
      populatePlatforms();
      renderSwitchState();
    }
  })();
}

if ($('btnClearCookies')) {
  $('btnClearCookies').onclick = async function () {
    var id = (current && current.platform) || 'boss';
    if (!confirm('确定清除 ' + BAA.platformName(id) + ' 的浏览器 cookie？\n\n这会退出该平台登录，需要重新登录。')) return;
    try {
      var r = await chrome.runtime.sendMessage({ type: 'BAA_CLEAR_COOKIES', platform: id });
      await chrome.storage.local.remove('baa.login');
      toast(r && r.ok
        ? ('已清除 ' + BAA.platformName(id) + ' cookie ' + (r.cleared && r.cleared.removed) + ' 项，请到插件面板点「去登录」')
        : ((r && r.msg) || '清除失败'));
    } catch (e) { toast('清除失败：' + String(e && e.message || e)); }
  };
}

/* ---------------- Schedule (v2.4) ---------------- */
function renderWeekdays(days) {
  var picked = (days || []).map(Number);
  $('weekdayBox').innerHTML = BAA.WEEKDAY_NAMES.map(function (name, i) {
    return '<span class="checkline" style="display:inline-flex;margin:0 14px 8px 0">' +
      '<input type="checkbox" data-wd="' + i + '" id="wd' + i + '"' +
      (picked.indexOf(i) >= 0 ? ' checked' : '') + '>' +
      '<label for="wd' + i + '" style="margin:0">' + name + '</label></span>';
  }).join('');
}
function readWeekdays() {
  return Array.prototype.slice.call($('weekdayBox').querySelectorAll('[data-wd]'))
    .filter(function (el) { return el.checked; })
    .map(function (el) { return Number(el.dataset.wd); });
}

function renderWindows(wins) {
  var list = wins || [];
  $('windowBody').innerHTML = list.length ? list.map(function (w) {
    return '<tr>' +
      '<td><input type="time" data-w="start" value="' + esc(w.start || '09:00') + '"></td>' +
      '<td><input type="time" data-w="end" value="' + esc(w.end || '18:00') + '"></td>' +
      '<td style="text-align:center"><input type="checkbox" data-w="enabled"' +
        (w.enabled !== false ? ' checked' : '') + '></td>' +
      '<td><button class="sm danger" data-del-window>删除</button></td>' +
      '</tr>';
  }).join('') : '<tr><td colspan="4" class="hint">暂无时间段，点下方添加</td></tr>';
}
function readWindows() {
  return Array.prototype.slice.call($('windowBody').querySelectorAll('tr')).filter(function (tr) {
    return tr.querySelector('[data-w="start"]');
  }).map(function (tr) {
    return {
      start: tr.querySelector('[data-w="start"]').value,
      end: tr.querySelector('[data-w="end"]').value,
      enabled: tr.querySelector('[data-w="enabled"]').checked
    };
  });
}

function previewSchedule() {
  if (!$('schedulePreview')) return;
  var cfg;
  try { cfg = collect(); } catch (e) { return; }
  if (!cfg.schedule) cfg.schedule = BAA.clone(BAA.DEFAULT_CONFIG.schedule);
  var st = BAA.scheduleStatus(cfg.schedule, Date.now());
  var lines = [BAA.scheduleSummary(cfg.schedule)];
  if (!st.enabled) {
    lines.push('当前：手动模式（定时未启用），任务完全由你点「开始 / 暂停 / 停止」控制。');
  } else if (st.reason === 'no-windows') {
    lines.push('当前：没有有效时间段，不会自动执行。请检查开始/结束时间是否相同或格式错误。');
  } else if (st.reason === 'no-weekdays') {
    lines.push('当前：没有选择执行日，不会自动执行。');
  } else if (st.active) {
    lines.push('当前：在执行时段 ' + st.windowLabel + ' 内，' + BAA.formatClock(st.windowEnd) +
      ' 自动' + (cfg.schedule.onWindowEnd === 'stop' ? '停止' : '暂停') + '。');
  } else {
    lines.push('当前：不在执行时段，' +
      (st.nextStartAt ? BAA.formatDateTime(st.nextStartAt) : '暂无可预计的下次开始时间') + ' 自动开始。');
  }
  $('schedulePreview').innerHTML = lines.map(function (l) { return esc(l); }).join('<br>');
  BAA.getScheduleRuntime().then(function (rt) {
    var el = $('schedRuntime');
    if (el) el.textContent = rt.message ? ('后台：' + rt.message) : '';
  }).catch(function () { /* ignore */ });
}

/* ---------------- Fill / collect ---------------- */
function fill(cfg) {
  current = BAA.clone(cfg);
  Array.prototype.forEach.call(document.querySelectorAll('[data-path]'), function (el) {
    var v = getPath(cfg, el.dataset.path.split('.'));
    var type = el.dataset.type;
    if (type === 'array') el.value = (v || []).join('\n');
    else if (type === 'bool') el.checked = !!v;
    else el.value = v === undefined || v === null ? '' : v;
  });
  renderTasks(cfg.tasks);
  renderRules(cfg.advancedRules);
  selectorCache = buildSelectorCache(cfg);
  editPlatform = cfg.platform || 'boss';
  renderSelectorEditor();
  renderWeekdays(cfg.schedule && cfg.schedule.weekdays);
  renderWindows(cfg.schedule && cfg.schedule.windows);
  try { renderPreset(); } catch (e) { /* 只是展示，出错不影响编辑 */ }
}

function collect() {
  readSelectorEditor();
  var cfg = BAA.clone(current || BAA.DEFAULT_CONFIG);
  Array.prototype.forEach.call(document.querySelectorAll('[data-path]'), function (el) {
    var type = el.dataset.type, v;
    if (type === 'array') v = splitList(el.value);
    else if (type === 'number') v = Number(el.value) || 0;
    else if (type === 'bool') v = el.checked;
    else v = el.value;
    setPath(cfg, el.dataset.path.split('.'), v);
  });
  cfg.tasks = readTasks();
  cfg.advancedRules = readRules();

  // Write BOTH platforms' selector / login lists back into their own override
  // slot, then mirror the active platform onto the resolved cfg fields.
  cfg.overrides = cfg.overrides || {};
  if (selectorCache) {
    BAA.PLATFORM_IDS.forEach(function (id) {
      var e = selectorCache[id];
      if (!e) return;
      cfg.overrides[id] = cfg.overrides[id] || {};
      cfg.overrides[id].selectors = BAA.clone(e.selectors || {});
      cfg.overrides[id].login = BAA.clone(e.login || {});
    });
  }
  var activeId = cfg.platform || 'boss';
  var active = selectorCache && selectorCache[activeId];
  cfg.selectors = (active && active.selectors) || (BAA.PLATFORM_DEFAULTS[activeId] || {}).selectors || {};
  cfg.login = (active && active.login) || {};

  if (!cfg.schedule) cfg.schedule = BAA.clone(BAA.DEFAULT_CONFIG.schedule);
  cfg.schedule.weekdays = readWeekdays();
  cfg.schedule.windows = readWindows();
  cfg.version = 1;
  return cfg;
}

/* ---------------- Data tab ---------------- */
async function refreshData() {
  var h = await BAA.getHistory();
  var logs = await BAA.getLogs();
  var login = (await chrome.storage.local.get('baa.login'))['baa.login'];
  var pf = (current && current.platform) || 'boss';
  var pfName = BAA.platformName(pf);
  // v3.0: 记录按平台分开数 —— 鱼泡的投递不会算进 BOSS 的账
  var mine = Object.keys(h).filter(function (k) {
    var r = h[k] || {};
    return (r.platform || 'boss') === pf;
  }).length;
  $('dataStat').textContent = pfName + ' 已投递 ' + mine + ' 条 · 两个平台合计 ' +
    Object.keys(h).length + ' 条 · 运行日志 ' + logs.length + ' 条 · 配置版本 ' + (current && current.version);
  $('loginStat').textContent = login
    ? '平台 ' + (login.platformName || login.platform || '-') + ' · 状态 ' + login.status +
      ' · ' + (login.reason || login.domReason || '') +
      ' · 判定来源：' + (login.source === 'background' ? '后台（cookie + 页面）' : '本地页面') +
      ' · 自检于 ' + new Date(login.checkedAt || Date.now()).toLocaleString('zh-CN')
    : '尚未自检。打开插件面板或点「开始」时会自动自检。';
  $('dataLogs').innerHTML = logs.slice(-100).reverse().map(function (l) {
    return '<div class="' + l.level + '"><span class="t">' + BAA.formatTime(l.ts) + '</span>' + esc(l.msg) + '</div>';
  }).join('') || '<div class="debug">暂无日志</div>';
  refreshCompanies().catch(function (e) { /* 记录读不到不影响其它面板 */ });
}

/* v2.9: 已打招呼的公司（本地记录）—— 按公司聚合，可搜索、可单家删除
   v3.0: 只看当前平台的记录；切换平台后这张表跟着换 */
async function refreshCompanies() {
  var el = $('companyList');
  if (!el) return;
  var days = Number((current && current.behavior && current.behavior.dedupeDays) || 0);
  var pf = (current && current.platform) || 'boss';
  var list = await BAA.listCompanies(days, pf);
  var kw = String(($('companyFilter') && $('companyFilter').value) || '').trim().toLowerCase();
  var show = kw ? list.filter(function (c) {
    return String(c.company || '').toLowerCase().indexOf(kw) >= 0;
  }) : list;
  var totalJobs = list.reduce(function (a, c) { return a + (Number(c.jobs) || 0); }, 0);
  $('companyStat').textContent = BAA.platformName(pf) + ' · 共 ' + list.length + ' 家公司 · ' + totalJobs + ' 条岗位记录' +
    (days > 0 ? '（统计最近 ' + days + ' 天，按「去重天数」过滤）' : '') +
    (kw ? ' · 匹配 ' + show.length + ' 家' : '');
  if (!show.length) {
    el.innerHTML = '<div class="hint">' + (kw ? '没有匹配的公司。' :
      '暂无记录。成功打过招呼后会自动写在这里，下次运行遇到同一家公司会跳过。') + '</div>';
    return;
  }
  var rows = show.slice(0, 400).map(function (c) {
    var pf = Object.keys(c.platforms || {}).map(function (p) {
      return p === 'yupao' ? '鱼泡' : (p === 'boss' ? 'BOSS' : p);
    }).join('/') || '-';
    return '<tr>' +
      '<td>' + esc(c.company) + '</td>' +
      '<td style="text-align:center">' + (Number(c.jobs) || 0) + '</td>' +
      '<td>' + BAA.formatDay(c.last) + '</td>' +
      '<td>' + esc(pf) + '</td>' +
      '<td style="text-align:right"><button class="sm ghost" data-del="' + esc(c.key) + '">删除</button></td>' +
      '</tr>';
  }).join('');
  el.innerHTML = '<table><thead><tr><th>公司</th><th style="width:52px;text-align:center">岗位</th>' +
    '<th style="width:92px">最近打招呼</th><th style="width:58px">平台</th><th style="width:66px"></th>' +
    '</tr></thead><tbody>' + rows + '</tbody></table>' +
    (show.length > 400 ? '<div class="hint">只显示最近 400 家，用搜索框缩小范围。</div>' : '');
}

/* ---------------- Events ---------------- */
$('btnAddTask').onclick = function () {
  var list = readTasks();
  var firstCity = (current && current.cities && current.cities[0]) || { code: '101280600', name: '深圳' };
  list.push({ query: '', city: firstCity.code, cityName: firstCity.name, enabled: true });
  renderTasks(list);
};
$('btnAddRule').onclick = function () {
  var list = readRules();
  list.push({ field: 'title', op: 'contains', value: '', enabled: true });
  renderRules(list);
};

/* ---- schedule events ---- */
Array.prototype.forEach.call(document.querySelectorAll('[data-weekdays]'), function (btn) {
  btn.onclick = function () {
    var presets = { all: [0, 1, 2, 3, 4, 5, 6], work: [1, 2, 3, 4, 5], weekend: [0, 6] };
    renderWeekdays(presets[btn.dataset.weekdays]);
    previewSchedule();
  };
});
$('btnAddWindow').onclick = function () {
  var list = readWindows();
  list.push({ start: '09:00', end: '12:00', enabled: true });
  renderWindows(list);
  previewSchedule();
};
$('btnSchedTest').onclick = async function () {
  try {
    await chrome.runtime.sendMessage({ type: 'BAA_SCHEDULE_TICK' });
    toast('已触发一次后台检查');
  } catch (e) { toast('触发失败：' + String(e && e.message || e)); }
  setTimeout(previewSchedule, 1500);
};
$('btnSchedClearOverride').onclick = async function () {
  await BAA.clearScheduleOverride();
  toast('已清除，下个检查周期按设置自动开始');
  previewSchedule();
};
document.addEventListener('change', function (e) {
  if (e.target && (e.target.dataset.wd !== undefined || e.target.dataset.w ||
                   e.target.dataset.path)) previewSchedule();
});
document.addEventListener('input', function (e) {
  if (e.target && e.target.dataset.w) previewSchedule();
});

document.addEventListener('click', function (e) {
  var t = e.target;
  if (t.hasAttribute('data-del-task')) {
    var list = readTasks();
    var tr = t.closest('tr');
    var idx = Array.prototype.indexOf.call(tr.parentNode.children, tr);
    list.splice(idx, 1);
    renderTasks(list);
  }
  if (t.hasAttribute('data-del-rule')) {
    var rules = readRules();
    var row = t.closest('tr');
    var i = Array.prototype.indexOf.call(row.parentNode.children, row);
    rules.splice(i, 1);
    renderRules(rules);
  }
  if (t.hasAttribute('data-del-window')) {
    var wins = readWindows();
    var wtr = t.closest('tr');
    var wi = Array.prototype.indexOf.call(wtr.parentNode.children, wtr);
    wins.splice(wi, 1);
    renderWindows(wins);
    previewSchedule();
  }
});

$('btnSave').onclick = async function () {
  var cfg = collect();
  if (Number(cfg.behavior.maxDelaySec) < Number(cfg.behavior.minDelaySec)) {
    toast('最大间隔不能小于最小间隔'); return;
  }
  if (Number(cfg.behavior.dailyLimit) < 1) { toast('每日上限至少为 1'); return; }
  if (cfg.schedule && cfg.schedule.enabled && BAA.scheduleWindows(cfg.schedule).length === 0) {
    toast('定时执行已开启，但没有有效时间段（开始/结束不能相同或为空）'); return;
  }
  await BAA.saveConfig(cfg);
  current = cfg;
  await BAA.log('info', '设置已保存');
  toast('设置已保存');
  $('saveHint').textContent = '已保存（' + BAA.formatTime(Date.now()) + '）';
};
$('btnReload').onclick = async function () {
  fill(await BAA.getConfig());
  toast('已放弃未保存的修改');
};
$('btnReset').onclick = async function () {
  if (!confirm('确定恢复全部默认配置？当前规则会丢失（已投递记录会保留）。')) return;
  fill(BAA.clone(BAA.DEFAULT_CONFIG));
  await BAA.saveConfig(collect());
  toast('已恢复默认，请确认后保存');
};
$('btnExport').onclick = function () {
  var blob = new Blob([JSON.stringify(collect(), null, 2)], { type: 'application/json' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'boss-auto-apply-config-' + BAA.today() + '.json';
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  toast('配置已导出');
};
$('btnImport').onclick = function () { $('fileInput').click(); };
$('fileInput').onchange = function (e) {
  var file = e.target.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function () {
    try {
      var obj = JSON.parse(reader.result);
      if (!obj || typeof obj !== 'object' || !obj.tasks) throw new Error('不是有效的配置文件');
      fill(BAA.merge(BAA.DEFAULT_CONFIG, obj));
      toast('已导入，请点「保存全部设置」生效');
    } catch (err) { toast('导入失败：' + err.message); }
  };
  reader.readAsText(file);
  e.target.value = '';
};
$('btnClearHistory').onclick = async function () {
  if (!confirm('清空后，同一岗位可能被再次投递。确定继续？')) return;
  await BAA.clearHistory(); refreshData(); toast('已清空已投递记录');
};
$('btnCleanHistory').onclick = async function () {
  var cfg = collect();
  var n = await BAA.cleanHistory(Number(cfg.behavior.dedupeDays));
  refreshData(); toast('已清理 ' + n + ' 条过期记录');
};
$('btnClearLogs').onclick = async function () {
  await BAA.clearLogs(); refreshData(); toast('已清空日志');
};
$('btnClearLogin').onclick = async function () {
  await chrome.storage.local.remove('baa.login');
  refreshData(); toast('已清除登录态快照（浏览器中的登录状态不受影响）');
};

/* v2.9: 已打招呼公司名单的交互 */
if ($('btnCompanyRefresh')) {
  $('btnCompanyRefresh').onclick = async function () {
    await refreshCompanies();
    toast('已刷新公司名单');
  };
}
if ($('companyFilter')) {
  $('companyFilter').oninput = function () { refreshCompanies().catch(function () {}); };
}
if ($('companyList')) {
  $('companyList').onclick = async function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('[data-del]') : null;
    if (!btn) return;
    var key = btn.getAttribute('data-del');
    var name = btn.parentNode && btn.parentNode.parentNode ?
      btn.parentNode.parentNode.firstChild.textContent : key;
    if (!confirm('删除「' + name + '」的本地记录？\n删除后下次运行会重新给这家公司打招呼。')) return;
    var n = await BAA.removeCompany(key);
    toast('已删除 ' + n + ' 条记录');
    await refreshCompanies();
    await refreshData();
  };
}

/* ---------------- Boot ---------------- */
BAA.getConfig().then(function (cfg) {
  current = BAA.clone(cfg);
  populatePlatforms();
  fill(cfg);
  renderSwitchState();
  previewSchedule();
});
setInterval(previewSchedule, 30000);

/* v3.0: 平台可能是在插件面板（popup）里切走的。回到设置页时如果发现 storage 里的
   platform 与本页不一致，就整页重载成那个平台的一套，避免「面板是鱼泡、设置页还是
   BOSS」这种两处打架的状态。 */
window.addEventListener('focus', function () {
  if (switchingPlatform) return;
  BAA.getConfig().then(function (cfg) {
    if (!current || cfg.platform === current.platform) return;
    current = BAA.clone(cfg);
    populatePlatforms();
    fill(cfg);
    renderSwitchState();
    previewSchedule();
    toast('平台已在别处切换到 ' + BAA.platformName(cfg.platform) + '，已同步本页设置');
  }).catch(function () { /* ignore */ });
});
