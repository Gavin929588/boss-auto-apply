'use strict';

var $ = function (id) { return document.getElementById(id); };

var LOGIN_TEXT = { ok: '已登录', required: '未登录', expired: '已过期', unknown: '未自检' };

var lastStatus = null;
var checking = false;
var lastCheckAt = 0;
var loginPoll = null;

function toast(msg) {
  var el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(function () { el.remove(); }, 2800);
}

/* v2.6: talk to the WORKER, not the page. The panel must stay usable when the
   current tab has no content script (after a platform switch / extension
   reload / on a non-platform page). */
function bg(msg) {
  return chrome.runtime.sendMessage(msg).then(function (r) {
    return r || { ok: false, msg: '后台无响应' };
  }).catch(function (e) {
    return { ok: false, msg: String(e && e.message || e) };
  });
}

function sendToPage(msg) {
  return chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    if (!tabs.length) return { ok: false, msg: '没有活动标签页' };
    return chrome.tabs.sendMessage(tabs[0].id, msg).catch(function () {
      return { ok: false, pageGone: true, msg: '当前页面脚本未就绪' };
    });
  });
}

function effectiveLogin(data) {
  var snap = data.login;
  var st = (data.state && data.state.loginStatus) || 'unknown';
  // A snapshot taken on another platform is meaningless here.
  if (snap && snap.platform && snap.platform !== data.platform) return { status: 'unknown', reason: '' };
  if (snap && snap.status) return { status: snap.status, reason: snap.reason || '' };
  return { status: st, reason: (data.state && data.state.loginReason) || '' };
}

function renderState(data) {
  if (!data || !data.ok) {
    $('statusBadge').textContent = '后台未响应';
    $('statusBadge').className = 'badge paused';
    return;
  }
  lastStatus = data;
  var s = data.state || {};
  $('platformBadge').textContent = data.platformName || '平台';
  $('statusBadge').textContent = BAA.STATUS_TEXT[s.status] || s.status;
  $('statusBadge').className = 'badge ' + (s.status === 'running' ? 'running'
    : (s.status === 'paused' || s.status === 'blocked' || s.status === 'need-login') ? s.status : '');

  Array.prototype.forEach.call(document.querySelectorAll('#platformSwitch button'), function (b) {
    b.classList.toggle('on', b.dataset.pf === data.platform);
  });

  var lg = effectiveLogin(data);
  $('loginBadge').textContent = LOGIN_TEXT[lg.status] || lg.status;
  $('loginBadge').className = 'badge' + (lg.status === 'ok' ? ' running'
    : (lg.status === 'required' || lg.status === 'expired') ? ' paused' : '');
  var snap = data.login;
  $('loginTime').textContent = snap && snap.checkedAt ? '自检于 ' + BAA.formatTime(snap.checkedAt) : '尚未自检';
  $('loginReason').textContent = lg.reason ||
    ('点击「去登录」会直接打开' + (data.platformName || '') + '登录页，登录完成后自动自检。');
  $('loginSnap').textContent = data.loginSnapshotText || '';

  var limit = Number(data.dailyLimit) || 0;
  $('todayText').textContent = (s.todayCount || 0) + ' / ' + limit;
  $('todayBar').style.width = (limit ? Math.min(100, Math.round((s.todayCount || 0) / limit * 100)) : 0) + '%';
  // v3.0: 今日次数以「当前平台的投递流水」为准。state.todayCount 是两个平台共享的，
  // 切过来之后可能还挂着另一个平台的数字，看起来像「额度被莫名其妙用掉了」。
  BAA.countTodayApplied(data.platform).then(function (n) {
    $('todayText').textContent = n + ' / ' + limit;
    $('todayBar').style.width = (limit ? Math.min(100, Math.round(n / limit * 100)) : 0) + '%';
  }).catch(function () { /* 读不到就先用 state 的值 */ });

  var cur = s.current || {};
  var parts = [];
  if (cur.query) parts.push('关键词：' + cur.query);
  if (cur.cityName) parts.push('城市：' + cur.cityName);
  if (s.queue && s.queue[s.queueIndex]) parts.push('任务 ' + (s.queueIndex + 1) + '/' + s.queue.length + ' · 第 ' + (s.page || 1) + ' 页');
  if (cur.jobTitle) parts.push('正在看：' + cur.jobTitle);
  $('taskText').textContent = parts.length ? parts.join('  ·  ') : '当前：无任务';

  var PHASE_TEXT = {
    idle: '空闲', start: '启动', scan: '扫描岗位', 'wait-page-ready': '等待页面就绪',
    apply: '发起沟通', cooldown: '限速等待', 'observe-after-click': '等待沟通页',
    handoff: '交接落地页', 'chat-landing': '发送招呼语', returning: '返回搜索页',
    'landing-done': '投递完成', paused: '已暂停'
  };
  var hb = $('heartbeatText');
  var ri = data.run;
  if (s.status === 'running') {
    var age = ri && ri.ts ? Math.round((Date.now() - ri.ts) / 1000) : null;
    var alive = age !== null && age < 12;
    hb.textContent = '运行状态：' + (PHASE_TEXT[ri && ri.phase] || (ri && ri.phase) || '未知') +
      ' · 心跳 ' + (age === null ? '无记录' : age + ' 秒前') +
      (alive ? ' · 正常' : ' · ⚠ 停滞，自愈守卫将自动恢复');
    hb.style.color = alive ? '' : 'var(--err)';
  } else {
    hb.textContent = '';
  }

  var stt = s.stats || {};
  $('sScanned').textContent = stt.scanned || 0;
  $('sMatched').textContent = stt.matched || 0;
  $('sApplied').textContent = stt.applied || 0;
  $('sSkipped').textContent = stt.skipped || 0;
  $('sDuplicated').textContent = stt.duplicated || 0;
  $('sFailed').textContent = stt.failed || 0;

  var role = data.pageRole || 'other';
  var roleNote = $('pageRoleNote');
  if (role === 'chat') {
    roleNote.style.display = '';
    roleNote.textContent = '⚠ 当前在「沟通列表页」：插件不会在这里执行投递任务。点「返回搜索页」即可继续。';
  } else if (role === 'detail') {
    roleNote.style.display = '';
    roleNote.textContent = '当前是岗位详情页：符合条件时会在这里完成打招呼。';
  } else if (role === 'other') {
    roleNote.style.display = '';
    roleNote.textContent = '当前不是' + (data.platformName || '平台') + '搜索页。登录不受影响；点「开始」会自动打开搜索页。';
  } else {
    roleNote.style.display = 'none';
  }
  $('btnBackSearch').disabled = (role === 'search');

  var running = s.status === 'running';
  $('btnStart').disabled = running;
  $('btnPause').disabled = !running;
  $('btnResume').disabled = running;
  $('btnStop').disabled = (s.status === 'idle' || s.status === 'stopped');

  var notice = $('notice');
  if (s.status === 'need-login') {
    notice.style.display = '';
    notice.textContent = '需要登录：' + (s.loginReason || lg.reason || '未检测到登录态') +
      '。点「去登录」完成登录后会自动继续。';
  } else if (s.status === 'blocked' && s.blockedReason) {
    notice.style.display = '';
    notice.textContent = '已自动暂停：' + s.blockedReason + '。请在页面里手动完成验证，再点「继续」。';
  } else if (data.dryRun) {
    notice.style.display = '';
    notice.textContent = '当前为「模拟运行」：只筛选和记录，不会真的投递。确认规则无误后到设置里关闭模拟运行。';
  } else if (s.summary && s.status === 'stopped') {
    notice.style.display = '';
    notice.textContent = s.summary;
  } else {
    notice.style.display = 'none';
  }
}

async function renderSchedule() {
  var cfg = await BAA.getConfig();
  var rt = await BAA.getScheduleRuntime();
  var st = BAA.scheduleStatus(cfg.schedule, Date.now());
  var badge = $('scheduleBadge');
  var lines = [BAA.scheduleSummary(cfg.schedule)];
  if (!st.enabled) {
    badge.textContent = '未启用'; badge.className = 'badge';
    lines.push('在「设置 → 定时执行」里开启并配置固定时间段。');
  } else if (st.reason === 'no-windows' || st.reason === 'no-weekdays') {
    badge.textContent = '配置不全'; badge.className = 'badge paused';
    lines.push('缺少有效执行日或时间段，不会自动执行。');
  } else if (st.active) {
    badge.textContent = '时段内'; badge.className = 'badge running';
    lines.push('当前时段 ' + st.windowLabel + '，' + BAA.formatClock(st.windowEnd) +
      ' 自动' + (cfg.schedule.onWindowEnd === 'stop' ? '停止' : '暂停') + '。');
  } else {
    badge.textContent = '等待时段'; badge.className = 'badge paused';
    lines.push('当前不在执行时段，' +
      (st.nextStartAt ? BAA.formatDateTime(st.nextStartAt) : '请检查执行日设置') + ' 自动开始。');
  }
  if (rt.overrideUntil > Date.now()) {
    lines.push('本次时段已手动停止，' + BAA.formatClock(rt.overrideUntil) + ' 后按新时段自动恢复。');
  } else if (rt.message) {
    lines.push('后台：' + rt.message);
  }
  $('scheduleText').innerHTML = lines.map(function (l) {
    return String(l).replace(/</g, '&lt;');
  }).join('<br>');
  $('btnScheduleSkip').disabled = !st.enabled;
}

async function refreshLogs() {
  var logs = await BAA.getLogs();
  var recent = logs.slice(-60).reverse();
  $('logCount').textContent = '最近 ' + recent.length + ' 条';
  $('logs').innerHTML = recent.length
    ? recent.map(function (l) {
        return '<div class="' + l.level + '"><span class="t">' + BAA.formatTime(l.ts) + '</span>' +
          String(l.msg).replace(/</g, '&lt;') + '</div>';
      }).join('')
    : '<div class="debug">暂无日志</div>';
}

async function refresh() {
  var status = await bg({ type: 'BAA_POPUP_STATUS' });
  renderState(status);
  try { await renderSchedule(); } catch (e) { /* storage busy */ }
  try { await refreshLogs(); } catch (e) { /* storage busy */ }
  try { await appendCompanyCount(); } catch (e) { /* storage busy */ }
  return status;
}

// v2.9: 让「同一家公司只打一次招呼」这件事在面板上看得见
async function appendCompanyCount() {
  var el = $('taskText');
  if (!el) return;
  // v3.1: 按平台统计 —— 两个平台的投递记录互不相干，混在一起显示会让人
  // 以为切到鱼泡还带着 BOSS 的 84 家。
  var cur = (lastStatus && lastStatus.platform) || (await BAA.getConfig()).platform;
  var hist = await BAA.getHistory();
  var seen = {};
  Object.keys(hist).forEach(function (k) {
    var r = hist[k];
    if (!r || !r.company) return;
    var pf = r.platform || 'boss';           // v2.9 之前的记录没有 platform，按 boss 算
    if (cur && pf !== cur) return;
    // 与去重口径保持一致：只要本地有这家公司的记录（沟通已建立）就算数。
    // greetingSent === false 表示「沟通建立了但招呼语没发出去」，这些公司
    // 同样会被 findCompanyHistory 拦住，所以这里不能把它们排除掉。
    seen[r.companyKey || BAA.companyKey(r.company)] = 1;
  });
  var n = Object.keys(seen).length;
  el.textContent = el.textContent.replace(/\s*·\s*已记录 \d+ 家公司$/, '');
  if (n) el.textContent += '  ·  已记录 ' + n + ' 家公司';
}

/* ---------------- login ---------------- */
async function checkLogin(showToast) {
  if (checking) return null;
  checking = true;
  var r = null;
  try {
    r = await bg({ type: 'BAA_CHECK_LOGIN' });
  } finally {
    checking = false;
    lastCheckAt = Date.now();
  }
  if (showToast) {
    if (r && r.status === 'ok') toast('自检成功：' + (r.reason || '已登录') + '，可以开始自动化');
    else toast('自检未通过：' + ((r && r.reason) || '未检测到登录态') + '。请刷新页面后重试。');
  }
  await refresh();
  return r;
}

function stopLoginPoll() {
  if (loginPoll) { clearInterval(loginPoll); loginPoll = null; }
}

function startLoginPoll() {
  stopLoginPoll();
  var started = Date.now();
  loginPoll = setInterval(async function () {
    if (Date.now() - started > 5 * 60 * 1000) { stopLoginPoll(); return; }
    var r = await bg({ type: 'BAA_CHECK_LOGIN' });
    if (r && r.status === 'ok') {
      stopLoginPoll();
      toast('自检成功，可以开始自动化投递');
      await refresh();
    }
  }, 3000);
}

function setLoginHint(text) {
  var el = $('loginReason');
  if (el) el.textContent = text;
}

$('btnCheckLogin').onclick = function () { checkLogin(true); };

$('btnGoLogin').onclick = async function () {
  var r = await bg({ type: 'BAA_OPEN_LOGIN' });
  if (!r || !r.ok) { toast((r && r.msg) || '打开登录页失败'); return; }
  toast(r.msg || ('已打开' + ((lastStatus && lastStatus.platformName) || '平台') + '登录入口，请完成登录'));
  setLoginHint('登录入口已打开，完成登录后会自动自检（无需手动刷新）。');
  startLoginPoll();
};

$('btnRefreshPage').onclick = async function () {
  var r = await bg({ type: 'BAA_REFRESH_PLATFORM_TAB' });
  if (!r || !r.ok) { toast((r && r.msg) || '刷新失败'); return; }
  toast('已刷新页面，正在重新自检');
  setLoginHint('页面已刷新，正在重新自检…');
  setTimeout(function () { checkLogin(true); }, 2500);
};

Array.prototype.forEach.call(document.querySelectorAll('#platformSwitch button'), function (btn) {
  btn.onclick = async function () {
    if (lastStatus && lastStatus.platform === btn.dataset.pf) return;
    // v3.0: 切平台不再清 cookie —— 两个平台可以同时保持登录，切来切去不用重扫码
    // v3.1: 切完由后台把浏览器带到该平台页面（没有就新开），随后立刻自检，
    //       面板上直接给出「已登录 / 需要登录」，不再让人对着旧页面猜。
    var r = await bg({ type: 'BAA_SET_PLATFORM', platform: btn.dataset.pf, clearOldCookies: false });
    toast((r && r.msg) || '已切换平台');
    lastCheckAt = 0;
    await refresh();
    await checkLogin(true);
  };
});

/* ---------------- actions ---------------- */
async function act(type) {
  // v3.1: 启动/继续之前先确认浏览器停在「当前选的平台」上。
  // 以前不校验：切到鱼泡后页面还是 BOSS，点开始就把鱼泡的规则发给 BOSS 的
  // 内容脚本，翻页立刻被域名校验拒掉，日志停在一行报错 —— 看起来就是卡死。
  if (type === 'START' || type === 'RESUME') {
    var data = lastStatus || await bg({ type: 'BAA_POPUP_STATUS' });
    if (data && data.ok && data.onPlatform === false) {
      var f = await bg({ type: 'BAA_FOCUS_PLATFORM', platform: data.platform });
      var pn = data.platformName || '平台';
      if (f && f.ok) {
        toast('已打开' + pn + '页面，登录完成后点「开始」即可');
        setLoginHint('已为你打开' + pn + '页面。若提示未登录，请先完成登录，登录成功后会自动自检。');
        startLoginPoll();
        await refresh();
        return;
      }
      toast((f && f.msg) || ('打开' + pn + '页面失败'));
      return;
    }
  }

  var r = await sendToPage({ type: type });
  if (r && r.wrongPlatform) {
    toast(r.msg || '当前页面与所选平台不一致，已阻止启动');
    setLoginHint(r.msg || '');
    await refresh();
    return;
  }
  if (r && r.pageGone) {
    // No content script on this tab (non-platform page / stale page). For
    // start/resume, open the login page of the selected platform first so the
    // user can sign in and the flow continues there.
    if (type === 'START' || type === 'RESUME') {
      var o = await bg({ type: 'BAA_OPEN_LOGIN' });
      toast(o && o.ok ? (o.msg || '已打开平台登录入口，登录后点「开始」') :
        ((o && o.msg) || '请先打开平台网页'));
      return;
    }
    toast('当前页面未加载插件，请刷新页面或打开平台网页后重试');
    return;
  }
  toast(r && r.msg ? r.msg : (r && r.ok ? '已执行' : '操作失败'));
  await refresh();
}

$('btnStart').onclick = function () { act('START'); };
$('btnPause').onclick = function () { act('PAUSE'); };
$('btnResume').onclick = function () { act('RESUME'); };
$('btnStop').onclick = function () { act('STOP'); };
$('btnOptions').onclick = function () { chrome.runtime.openOptionsPage(); };
$('btnBackSearch').onclick = function () { act('BACK_TO_SEARCH'); };

$('btnScheduleSkip').onclick = async function () {
  var cfg = await BAA.getConfig();
  await BAA.setScheduleOverride(cfg);
  try { await BAA.log('info', '手动设置：本次执行时段不再自动运行'); } catch (e) { /* ignore */ }
  toast('本次时段不再自动启动');
  await refresh();
};
$('btnScheduleReset').onclick = async function () {
  await BAA.clearScheduleOverride();
  toast('已恢复自动执行');
  await refresh();
};

$('btnClearLog').onclick = async function () {
  await BAA.clearLogs();
  await refreshLogs();
  toast('日志已清空');
};

$('btnCalibrate').onclick = async function () {
  var box = $('calibResult');
  box.style.display = '';
  box.textContent = '正在识别…';
  var r = await sendToPage({ type: 'CALIBRATE' });
  if (!r || !r.ok) { box.textContent = (r && r.msg) || '识别失败（请先打开平台页面并刷新）'; return; }
  if (r.pageRole === 'chat' && r.chat) {
    box.innerHTML = [
      '当前页面：沟通列表页（不会执行投递任务）',
      '会话条目：' + r.chat.sessionItems + ' 个 · iframe：' + r.chat.iframes + ' 个',
      '聊天输入框：' + (r.chat.composerFound ? '已找到 ' + (r.chat.composerTag || '') : (r.chat.composerInFrames ? '在 iframe 内找到' : '未出现（需先选中会话）')),
      '发送按钮：' + (r.chat.sendFound ? '已找到 · ' + (r.chat.sendReady ? '可用' : '当前 disabled（输入后自动启用）') : '未出现'),
      '当前会话：' + (r.chat.conversationHead || '未打开'),
      '自定义招呼语：' + (r.chat.greetingEnabled ? '已开启' : '已关闭（不会发送）'),
      '招呼语模板：' + (r.chat.greetingPreview || '空'),
      '沟通后动作：' + (r.chat.afterChat === 'stay' ? '停留在沟通页' : '自动返回搜索页继续'),
      '验证检测：' + r.verification
    ].map(function (l) { return String(l).replace(/</g, '&lt;'); }).join('<br>');
    return;
  }
  var lines = [
    '当前页面：搜索结果页',
    '识别到 ' + r.cardCount + ' 个岗位卡片',
    '卡片选择器：' + (r.cardSelector || '未命中，请到设置里改'),
    '「立即沟通」：' + (r.chatFound ? '已找到（' + (r.chatSelector || '') + '）' : '未命中，请到设置里改'),
    '标题/薪资/公司：' + [r.titleSelector, r.salarySelector, r.companySelector].map(function (x) { return x || '未命中'; }).join(' / '),
    '验证检测：' + r.verification
  ];
  if (r.samples && r.samples.length) {
    r.samples.forEach(function (s, i) {
      lines.push('样例' + (i + 1) + '：' + [s.company, s.title, s.salary, s.city, s.experience, s.education].filter(Boolean).join(' | '));
    });
  } else {
    lines.push('未取到样例，请把这些选择器按实际页面 class 名调整后重试');
  }
  box.innerHTML = lines.map(function (l) { return String(l).replace(/</g, '&lt;'); }).join('<br>');
};

/* Boot: always run one real self-check so the panel never shows a bare
   "未知" — that was the core complaint on 鱼泡. */
(async function boot() {
  var st = await refresh();
  var stale = !st || !st.login || !st.login.checkedAt ||
    (st.login.platform && st.login.platform !== st.platform) ||
    (Date.now() - st.login.checkedAt > 60000);
  if (stale) await checkLogin(false);
  setInterval(refresh, 2000);
  setInterval(function () {
    // keep the badge honest while the panel stays open
    if (!checking && Date.now() - lastCheckAt > 15000) checkLogin(false);
  }, 15000);
})();
