'use strict';

// The running state machine lives in the content script (MV3 workers are killed
// when idle). This worker does short-lived routing, first-run setup, and a
// last-resort watchdog that revives a stalled run (v2.3).
importScripts('config.js', 'login.js');

var WD_ALARM = 'baa-watchdog';
var SCHED_ALARM = 'baa-schedule';
var wdBusy = false;
var schedBusy = false;
var schedTimer = null;
var launchSuppressUntil = 0;

// v2.4: the worker writes its own key (never the page's baa.logs array) and
// serialises writes, so background + content logs can no longer overwrite
// each other. BAA.getLogs() merges both streams for the UI.
var bgLogChain = Promise.resolve();
function appendLog(level, msg) {
  var entry = { ts: Date.now(), level: level, msg: String(msg) };
  bgLogChain = bgLogChain.then(function () {
    return chrome.storage.local.get(BAA.KEYS.BGLOGS).then(function (d) {
      var list = d[BAA.KEYS.BGLOGS] || [];
      list.push(entry);
      if (list.length > 300) list = list.slice(-300);
      var o = {}; o[BAA.KEYS.BGLOGS] = list;
      return chrome.storage.local.set(o);
    });
  }).catch(function () { /* worker shutting down */ });
  return bgLogChain;
}

function ensureAlarm() {
  try {
    chrome.alarms.get(WD_ALARM, function (a) {
      if (!a) chrome.alarms.create(WD_ALARM, { delayInMinutes: 0.1, periodInMinutes: 0.5 });
    });
    // Dedicated 1-minute scheduler alarm. The watchdog alarm also triggers a
    // scheduler tick (30s), so a suspended worker is revived by either one.
    chrome.alarms.get(SCHED_ALARM, function (a) {
      if (!a) chrome.alarms.create(SCHED_ALARM, { delayInMinutes: 0.2, periodInMinutes: 1 });
    });
  } catch (e) { /* alarms permission missing (older manifest) */ }
}

function kickSchedule(delayMs) {
  if (schedTimer) return;
  try {
    schedTimer = setTimeout(function () { schedTimer = null; scheduleTick(); }, delayMs || 800);
  } catch (e) { schedTimer = null; scheduleTick(); }
}

chrome.runtime.onInstalled.addListener(function () { ensureAlarm(); kickSchedule(1200); });
chrome.runtime.onStartup.addListener(function () {
  ensureAlarm();
  launchSuppressUntil = Date.now() + 60000;
  kickSchedule(2000);
});
ensureAlarm();
kickSchedule(1500);

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (!alarm) return;
  if (alarm.name === WD_ALARM) { scheduleTick(); watchdog(); }
  else if (alarm.name === SCHED_ALARM) { scheduleTick(); }
});

// Also check shortly after a run starts, so a stall is caught well before the
// 30s alarm tick. The worker may be killed before this fires; the alarm covers it.
var wdScheduled = false;

// Turn a stored cookie domain (e.g. ".zhipin.com") into a <all_urls>-style
// match pattern for chrome.tabs.query. Leading dots are stripped.
function domainPattern(dom) {
  var d = (dom || '.zhipin.com').replace(/^\./, '');
  return '*://*.' + d + '/*';
}
// Whether a URL is the platform's search-result listing page.
function isSearchUrl(cfg, url) {
  if (!url) return false;
  if (cfg && cfg.platform === 'yupao') {
    return url.indexOf('/topic/') >= 0 && url.indexOf('/zhaogong/') < 0;
  }
  return /\/web\/geek\/jobs/.test(url);
}
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== 'local') return;
  // Saving the settings must take effect immediately, not up to a minute later.
  if (changes[BAA.KEYS.CONFIG]) kickSchedule(400);
  if (!changes[BAA.KEYS.STATE] || wdScheduled) return;
  var s = changes[BAA.KEYS.STATE].newValue;
  var old = changes[BAA.KEYS.STATE].oldValue;
  // Only arm once, on the idle -> running transition (state is written often).
  if (s && s.status === 'running' && (!old || old.status !== 'running')) {
    wdScheduled = true;
    try {
      setTimeout(function () { wdScheduled = false; watchdog(); }, 12000);
    } catch (e) { wdScheduled = false; }
  }
});

async function watchdog() {
  if (wdBusy) return;
  wdBusy = true;
  try {
    var d = await chrome.storage.local.get([
      BAA.KEYS.STATE, BAA.KEYS.RUN, BAA.KEYS.CONFIG, BAA.KEYS.PENDING
    ]);
    var s = d[BAA.KEYS.STATE] || {};
    if (s.status !== 'running') return;

    var cfg = d[BAA.KEYS.CONFIG] || {};
    var staleSec = Number(cfg.behavior && cfg.behavior.watchdogStaleSec) || 10;
    var r = d[BAA.KEYS.RUN];
    var age = r && r.ts ? (Date.now() - r.ts) / 1000 : 9999;
    if (age <= staleSec) return;                    // state machine is alive

    var p = d[BAA.KEYS.PENDING];
    if (p && p.job && Date.now() - p.ts < 120000) return;   // chat landing owns it

    appendLog('warn', '看门狗：状态机心跳已停 ' + Math.round(age) + ' 秒，尝试自动恢复');

    var domain = (cfg.domain || '.zhipin.com');
    var tabs = await chrome.tabs.query({ url: domainPattern(domain) });
    var searchTab = tabs.filter(function (t) { return isSearchUrl(cfg, t.url); })[0] || tabs[0];
    if (searchTab) {
      try {
        var kick = await chrome.tabs.sendMessage(searchTab.id, { type: 'BAA_KICK' });
        appendLog('info', '看门狗：已向页面发送恢复指令 · ' + JSON.stringify(kick).slice(0, 100));
        return;
      } catch (e) { /* content script gone -> force navigation below */ }
    }

    // Last resort: reload the search page so boot() re-runs.
    var tpl = (cfg.searchUrlTemplate || BAA.DEFAULT_CONFIG.searchUrlTemplate);
    var task = (s.queue || [])[s.queueIndex || 0] || BAA.DEFAULT_CONFIG.tasks[0];
    var url = BAA.buildUrl(tpl, task, s.page || 1);
    var target = tabs.filter(function (t) { return (t.url || '').indexOf(domain.replace(/^\./, '')) >= 0; })[0];
    if (target) {
      await chrome.tabs.update(target.id, { url: url });
      appendLog('warn', '看门狗：页面无响应，已强制重新加载搜索页');
    } else {
      await chrome.tabs.create({ url: url });
      appendLog('warn', '看门狗：未找到平台标签，已新开搜索页');
    }
  } catch (e) {
    appendLog('error', '看门狗异常：' + String(e && e.message || e));
  } finally {
    wdBusy = false;
  }
}

/* ------------------------------------------------------------------ *
 * v2.4 - Fixed time-window scheduler
 *
 * MV3 service workers are killed when idle, so chrome.alarms (30s watchdog
 * + 1min scheduler) is the only reliable wake-up. Every tick is a pure
 * decision based on LOCAL time: enter window -> auto START/RESUME, leave
 * window -> auto PAUSE/STOP. Decisions live in baa.schedule (runtime), never
 * in the user's config, so a reload cannot lose track.
 * ------------------------------------------------------------------ */
async function scheduleTick() {
  if (schedBusy) return;
  schedBusy = true;
  try {
    var d = await chrome.storage.local.get([
      BAA.KEYS.CONFIG, BAA.KEYS.SCHEDULE, BAA.KEYS.AUTOSTART
    ]);
    var cfg = d[BAA.KEYS.CONFIG] || {};
    // Fresh installs / pre-v2.4 configs have no schedule block in raw storage;
    // getConfig() applies the __v24 migration and merges the defaults.
    if (!cfg.schedule) cfg = await BAA.getConfig();
    var sch = cfg.schedule || {};
    var st = BAA.scheduleStatus(sch, Date.now());
    var rt = await BAA.getScheduleRuntime();
    var state = await BAA.getState();
    var decision = !st.enabled ? 'off' : (st.active ? 'in' : 'out');
    var changed = rt.lastDecision !== decision;
    var wasActive = !!rt.wasActive;
    rt.wasActive = !!st.active;
    rt.lastDecision = decision;
    rt.updatedAt = Date.now();

    if (decision === 'off') {
      if (changed) appendLog('info', '定时执行已关闭，任务完全由手动控制');
      rt.message = '定时执行未启用';
      await BAA.saveScheduleRuntime(rt);
      return;
    }

    if (st.active) {
      rt.pauseGuardUntil = 0;
      var launchBlocked = Date.now() < launchSuppressUntil && sch.startOnBrowserLaunch === false;
      var blockedByUser = Date.now() < (rt.overrideUntil || 0);
      var alreadyStarted = st.windowStart > 0 && rt.activeWindowStart === st.windowStart;
      var dailyLimit = Number(cfg.behavior && cfg.behavior.dailyLimit) || 40;
      var limitReached = state.today === BAA.today() && Number(state.todayCount || 0) >= dailyLimit;
      var canStart = ['idle', 'stopped', 'paused'].indexOf(state.status) >= 0 ||
        (!!sch.retryBlocked && ['blocked', 'need-login'].indexOf(state.status) >= 0);
      var handoff = d[BAA.KEYS.AUTOSTART];
      // A hand-off that never got consumed (page never became a search page,
      // browser was closed, ...) must not block this window forever.
      if (handoff && handoff.pending && Date.now() - (handoff.ts || 0) > 5 * 60000) {
        await BAA.setAutoStart(null);
        handoff = null;
        rt.activeWindowStart = 0;
        alreadyStarted = false;
        appendLog('warn', '定时执行：启动交接超时，本时段重新尝试');
      }

      if (canStart && !blockedByUser && !alreadyStarted && !limitReached &&
          !launchBlocked && !(handoff && handoff.pending)) {
        rt.activeWindowStart = st.windowStart;
        rt.lastAutoStart = Date.now();
        rt.autoManaged = true;
        rt.message = '已进入执行时段 ' + st.windowLabel + '，正在自动启动';
        await BAA.saveScheduleRuntime(rt);
        appendLog('ok', '定时执行：进入时段 ' + st.windowLabel + '，自动' +
          (state.status === 'paused' ? '继续上次进度' : '开始新任务'));
        if (sch.notify !== false) notify('定时执行：已进入 ' + st.windowLabel + '，自动开始投递');
        await triggerScheduledStart(cfg, state, st, sch);
      } else {
        rt.message = blockedByUser ? '本次时段已手动停止，下个时段自动恢复'
          : alreadyStarted ? '当前时段已自动启动过，任务结束或手动停止后不再重复启动'
          : limitReached ? '今日已达投递上限，不再自动启动'
          : launchBlocked ? '浏览器启动时正处于时段，已按设置跳过本次自动开始'
          : st.windowLabel + ' 执行中';
        await BAA.saveScheduleRuntime(rt);
      }
      return;
    }

    // Outside a window: stop the auto-managed run. pauseGuard covers the race
    // where the chat landing page re-writes "running" just as we pause.
    var guard = Date.now() < (rt.pauseGuardUntil || 0);
    if (state.status === 'running' && (wasActive || rt.autoManaged || guard)) {
      var endStatus = sch.onWindowEnd === 'stop' ? 'stopped' : 'paused';
      var fresh = await BAA.getState();
      fresh.status = endStatus;
      fresh.summary = endStatus === 'stopped'
        ? '定时时段结束，已自动停止'
        : '定时时段结束，已自动暂停；下个执行时段会自动继续';
      fresh.finishedAt = Date.now();
      fresh.phase = 'schedule-idle';
      await BAA.saveState(fresh);          // re-read just before write: keep todayCount
      rt.autoManaged = false;
      rt.pauseGuardUntil = Date.now() + 120000;
      rt.lastAutoPause = Date.now();
      rt.message = fresh.summary;
      appendLog('info', '定时执行：' + fresh.summary +
        (st.nextStartAt ? '（下次 ' + BAA.formatDateTime(st.nextStartAt) + '）' : ''));
      if (sch.notify !== false) notify(fresh.summary);
    } else {
      rt.message = st.nextStartAt
        ? '当前不在执行时段，' + BAA.formatDateTime(st.nextStartAt) + ' 自动开始'
        : '当前不在执行时段';
      if (Date.now() >= (rt.pauseGuardUntil || 0)) rt.pauseGuardUntil = 0;
    }
    await BAA.saveScheduleRuntime(rt);
  } catch (e) {
    appendLog('error', '定时器异常：' + String(e && e.message || e));
  } finally {
    schedBusy = false;
  }
}

async function triggerScheduledStart(cfg, state, st, sch) {
  var tasks = (cfg.tasks || []).filter(function (t) {
    return t && t.enabled !== false && String(t.query || '').trim();
  });
  if (!tasks.length) {
    appendLog('warn', '定时执行：没有启用的搜索任务，已跳过自动启动');
    await BAA.setAutoStart(null);
    return;
  }
  var wantsResume = state.status === 'paused' && state.queue && state.queue.length &&
    (state.queueIndex || 0) < state.queue.length;
  var cmd = wantsResume ? 'RESUME' : 'START';
  var task = wantsResume ? (state.queue[state.queueIndex || 0] || tasks[0]) : tasks[0];
  var page = wantsResume ? (state.page || 1) : 1;
  var url = BAA.buildUrl(cfg.searchUrlTemplate || BAA.DEFAULT_CONFIG.searchUrlTemplate, task, page);
  var navUrl = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_baa=' + Date.now();

  // One-shot hand-off: the content script consumes it and calls START/RESUME,
  // so login self-check, queue building and the real run all stay in one place.
  await BAA.setAutoStart({
    pending: true, ts: Date.now(), command: cmd,
    windowStart: st.windowStart, label: st.windowLabel, url: url
  });

  var tabs = [];
  try { tabs = await chrome.tabs.query({ url: domainPattern(cfg.domain || '.zhipin.com') }); } catch (e) { /* no tabs API */ }
  var searchTab = tabs.filter(function (t) { return isSearchUrl(cfg, t.url); })[0];
  if (searchTab) {
    try {
      var r = await chrome.tabs.sendMessage(searchTab.id, { type: 'BAA_SCHEDULE_START' });
      appendLog('info', '定时执行：已向现有搜索页下发启动指令 · ' +
        JSON.stringify(r).slice(0, 120));
      return;
    } catch (e) {
      appendLog('info', '定时执行：页面脚本未就绪，重载搜索页后由新文档接管');
      try { await chrome.tabs.update(searchTab.id, { url: navUrl }); }
      catch (e2) { appendLog('warn', '定时执行：搜索页重载失败'); }
      return;
    }
  }
  if (sch.autoOpenTab === false) {
    appendLog('info', '定时执行：未找到搜索页且未开启自动开标签，等你打开搜索页后会自动启动');
    return;
  }
  try {
    await chrome.tabs.create({ url: navUrl, active: sch.openInBackground === false });
    appendLog('info', '定时执行：已新开后台搜索页，加载完成后自动启动');
  } catch (e) {
    appendLog('error', '定时执行：新开标签失败 ' + String(e && e.message || e));
  }
}

chrome.runtime.onInstalled.addListener(function (details) {
  BAA.getConfig().then(function (cfg) {
    return BAA.saveConfig(cfg);
  }).then(function () {
    if (details.reason === 'install') chrome.runtime.openOptionsPage();
  });
});

function notify(message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '智能投递助手',
      message: String(message || ''),
      priority: 1
    }, function () { if (chrome.runtime.lastError) { /* ignore */ } });
  } catch (e) { /* notifications unavailable */ }
}

// Read-only cookie metadata. Cookie VALUES are never returned or persisted.
function cookieProbe(sendResponse) {
  BAA.getConfig().then(function (cfg) {
    var domain = (cfg && cfg.domain) || '.zhipin.com';
    try {
      chrome.cookies.getAll({ domain: domain }).then(function (list) {
        sendResponse({
          ok: true,
          domain: domain,
          cookies: (list || []).map(function (c) {
            return {
              name: c.name, domain: c.domain, secure: c.secure,
              httpOnly: c.httpOnly, expirationDate: c.expirationDate || 0
            };
          })
        });
      }).catch(function (e) {
        sendResponse({ ok: false, cookies: [], error: String(e && e.message || e) });
      });
    } catch (e) {
      sendResponse({ ok: false, cookies: [], error: String(e && e.message || e) });
    }
  }).catch(function (e) {
    sendResponse({ ok: false, cookies: [], error: String(e && e.message || e) });
  });
}

function goLogin(sender, sendResponse) {
  openLogin(null).then(function (r) { sendResponse(r); })
    .catch(function (e) { sendResponse({ ok: false, msg: String(e && e.message || e) }); });
}

/* ------------------------------------------------------------------ *
 * v2.6 — login flow owned by the worker
 *
 * The popup must be able to answer "am I logged in?" and "take me to the
 * login page" no matter which page the user is on. Previously both were
 * routed through the content script, so on a page where it had not been
 * injected (right after a platform switch / extension reload) the panel
 * showed "未连接 / 未知" even on a signed-in account.
 * ------------------------------------------------------------------ */

function sleepMs(ms) {
  return new Promise(function (r) { setTimeout(r, Math.max(0, ms || 0)); });
}

function platformHost(id) {
  var p = BAA.PLATFORM_DEFAULTS[id] || BAA.PLATFORM_DEFAULTS.boss;
  return String(p.domain || '.zhipin.com').replace(/^\./, '');
}
function platformLoginUrl(id) {
  var p = BAA.PLATFORM_DEFAULTS[id] || BAA.PLATFORM_DEFAULTS.boss;
  return p.loginUrl || ('https://www.' + platformHost(id) + '/');
}
function platformOrigin(id) {
  var p = BAA.PLATFORM_DEFAULTS[id] || BAA.PLATFORM_DEFAULTS.boss;
  return p.loginOrigin || ('https://www.' + platformHost(id) + '/');
}
function withCacheBust(url, tag) {
  return url + (url.indexOf('?') >= 0 ? '&' : '?') + '_baa=' + tag + Date.now();
}

// Remove every cookie a platform has ever set. Used when the user switches
// platform: the previous account's session must not linger and impersonate a
// signed-in state on the newly selected platform.
//
// Two passes on purpose. chrome.cookies.getAll() cannot enumerate some domain
// cookies on certain Chrome profiles (verified: getAll('.zhipin.com') returns 0
// while cookies.get({url,name}) still sees zp_at), so the second pass removes
// the known credential names directly — cookies.remove(url,name) works in that
// exact situation. A final verification pass reports anything still alive.
async function clearPlatformCookies(id) {
  var pdef = BAA.PLATFORM_DEFAULTS[id];
  if (!pdef) return { removed: 0, failed: 0, total: 0, remaining: [] };
  var host = platformHost(id);
  var cfg = await BAA.getConfig();
  var spec = (BAA.getPlatformView(cfg, id).login) || {};

  var origins = [
    'https://www.' + host + '/',
    'https://' + host + '/',
    'https://m.' + host + '/',
    'http://www.' + host + '/'
  ];

  var removed = 0, failed = 0, seen = {}, list = [];

  // --- pass 1: whatever the cookie API can enumerate ---------------------
  try { list = await chrome.cookies.getAll({ domain: pdef.domain || ('.' + host) }); } catch (e) { /* ignore */ }
  if (!list.length) {
    for (var d = 0; d < 2 && !list.length; d++) {
      try { list = await chrome.cookies.getAll({ domain: d ? host : ('.' + host) }); } catch (e) { /* ignore */ }
    }
  }
  if (!list.length) {
    for (var u = 0; u < origins.length && !list.length; u++) {
      try { list = await chrome.cookies.getAll({ url: origins[u] }); } catch (e) { /* ignore */ }
    }
  }
  for (var i = 0; i < list.length; i++) {
    var c = list[i];
    seen[c.name] = 1;
    var chost = String(c.domain || host).replace(/^\./, '');
    var url = (c.secure ? 'https://' : 'http://') + chost + (c.path || '/');
    try {
      await chrome.cookies.remove({ url: url, name: c.name, storeId: c.storeId });
      removed++;
    } catch (e) { failed++; }
  }

  // --- pass 2: known credential names (rename-proof fallback) ------------
  var known = (spec.sessionCookies || []).concat(spec.cookieNames || []);
  var uniq = [];
  for (var k = 0; k < known.length; k++) {
    if (known[k] && uniq.indexOf(known[k]) < 0) uniq.push(known[k]);
  }
  for (var n = 0; n < uniq.length; n++) {
    if (seen[uniq[n]]) continue;             // already handled in pass 1
    for (var o = 0; o < origins.length; o++) {
      try {
        var r = await chrome.cookies.remove({ url: origins[o], name: uniq[n] });
        if (r) { removed++; seen[uniq[n]] = 1; break; }
      } catch (e) { failed++; }
    }
  }

  // --- pass 3: verify the session cookies are really gone ----------------
  var remaining = [];
  var sessions = spec.sessionCookies || [];
  for (var s = 0; s < sessions.length; s++) {
    for (var p = 0; p < origins.length; p++) {
      try {
        var c2 = await chrome.cookies.get({ url: origins[p], name: sessions[s] });
        if (c2) { remaining.push(sessions[s]); break; }
      } catch (e) { /* ignore */ }
    }
  }

  return { removed: removed, failed: failed, total: list.length, remaining: remaining };
}

// Inject the self-contained DOM probe into any open tab of this platform.
// Returns the FIRST tab that answered plus its probe result.
// v2.7.1: 只取"第一个响应的标签页"会误判 —— 鱼泡详情页（/zhaogong/）的页头和列表页
// 布局不同，可能渲染出「登录丨注册」，于是整条会话被当成失效（假阴性，正是用户
// 最初抱怨的问题）。现在扫多个标签页：任意一个出现已登录菜单就算已登录；只有在
// 所有标签页都显示游客态时，才把"游客"当作结论。
async function probePlatformDom(id, spec) {
  var host = platformHost(id);
  var tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: ['*://*.' + host + '/*', '*://' + host + '/*'] });
  } catch (e) { /* tabs permission */ }
  tabs.sort(function (a, b) { return (b.active ? 1 : 0) - (a.active ? 1 : 0); });
  var guestHit = null, answered = 0;
  for (var i = 0; i < tabs.length && i < 5; i++) {
    try {
      var res = await chrome.scripting.executeScript({
        target: { tabId: tabs[i].id },
        func: BAA.loginDomProbe,
        args: [spec]
      });
      var out = res && res[0] && res[0].result;
      if (!out) continue;
      answered++;
      if (out.logged) return { tab: tabs[i], dom: out, scanned: answered };   // 强证据，立即采信
      var isLogin = /\/login|login\?|signin|passport/i.test(out.url || '');
      if (!guestHit && !isLogin) guestHit = { tab: tabs[i], dom: out };
    } catch (e) { /* cannot inject (loading / restricted) -> try next */ }
  }
  return guestHit ? { tab: guestHit.tab, dom: guestHit.dom, scanned: answered } : null;
}

async function checkLoginFor(platformId) {
  var cfg = await BAA.getConfig();
  var id = BAA.PLATFORM_DEFAULTS[platformId] ? platformId : cfg.platform;
  var pdef = BAA.PLATFORM_DEFAULTS[id];
  var view = BAA.getPlatformView(cfg, id);
  var spec = view.login || {};
  var origin = platformOrigin(id);

  // A. session cookies — the only signal that cannot be faked by a stale page.
  var sessions = spec.sessionCookies || [];
  var cookieHits = [];
  for (var i = 0; i < sessions.length; i++) {
    try {
      var c = await chrome.cookies.get({ url: origin, name: sessions[i] });
      if (c && (!c.expirationDate || c.expirationDate * 1000 > Date.now())) cookieHits.push(c.name);
    } catch (e) { /* ignore */ }
  }
  var allCookies = [];
  try { allCookies = await chrome.cookies.getAll({ url: origin }); } catch (e) { /* ignore */ }

  // B. DOM probe on any open tab of this platform.
  var probe = await probePlatformDom(id, spec);
  var dom = probe && probe.dom;

  // v2.7: a cookie whose NAME still exists is NOT proof of a live session. A
  // half-restored / server-invalidated token keeps the name (USERID etc.) while
  // every page renders "登录丨注册" — that produced a false "已登录" and let the
  // automation run without a single greeting being sent. So when a same-platform
  // tab is available and it clearly shows a guest header (and no logged-in menu),
  // trust the page over the cookie. Login pages are excluded: they always show
  // the guest form even for a signed-in user.
  var onLoginPage = !!(dom && /\/login|login\?|signin|passport/i.test(dom.url || ''));
  var domSaysGuest = !!(dom && !dom.logged && dom.guest && !onLoginPage);

  var status, reason, source;
  if (cookieHits.length && domSaysGuest) {
    status = 'expired'; source = 'cookie+dom';
    reason = '登录 cookie 仍在，但页面显示「' + dom.guestBy + '」，会话已失效，请重新登录';
  } else if (cookieHits.length) {
    status = 'ok'; source = 'cookie';
    reason = '检测到登录会话（' + cookieHits.join(' / ') + '）' +
      (dom && dom.logged ? '，页面已确认' : '');
  } else if (dom && dom.logged) {
    status = 'ok'; source = 'dom';
    reason = '检测到已登录用户菜单（' + dom.loggedBy + '）';
  } else if (dom && dom.guest) {
    status = 'required'; source = 'dom';
    reason = '检测到登录入口（' + dom.guestBy + '），请先登录';
  } else if (dom) {
    status = 'required'; source = 'dom';
    reason = '页面未出现登录态标记，请刷新页面后重试';
  } else {
    status = 'required'; source = 'cookie';
    reason = '没有可检测的' + pdef.name + '标签页，且未发现登录会话，请点「登录平台」';
  }

  var snapshot = {
    checkedAt: Date.now(),
    platform: id,
    platformName: pdef.name,
    status: status,
    reason: reason,
    source: source,
    evidence: cookieHits,
    hasSessionCookie: cookieHits.length > 0,
    domLogged: !!(dom && dom.logged),
    domGuest: domSaysGuest,
    cookieCount: allCookies.length,
    tabUrl: (probe && probe.tab && probe.tab.url) || '',
    domUrl: (dom && dom.url) || ''
  };
  try { await BAA.saveLoginSnapshot(snapshot); } catch (e) { /* storage busy */ }

  return {
    ok: true, status: status, reason: reason, snapshot: snapshot,
    platform: id, platformName: pdef.name, dom: dom || null
  };
}

async function switchPlatform(id, opts) {
  opts = opts || {};
  if (!BAA.PLATFORM_DEFAULTS[id]) return { ok: false, msg: '未知平台：' + id };
  var cfg = await BAA.getConfig();
  var old = cfg.platform;
  var changed = old !== id;
  var cleared = null;
  if (changed && opts.clearOldCookies !== false) {
    cleared = await clearPlatformCookies(old);
  }  cfg.platform = id;
  BAA.resolvePlatform(cfg);
  await BAA.saveConfig(cfg);

  // A snapshot belongs to the platform it was taken on — never carry it over.
  try { await chrome.storage.local.remove(BAA.KEYS.LOGIN); } catch (e) { /* ignore */ }
  var st = await BAA.getState();
  st.status = 'idle';
  st.loginStatus = 'unknown';
  st.loginReason = '';
  st.lastLoginCheck = 0;
  st.summary = '';
  st.blockedReason = '';
  st.queue = [];
  st.queueIndex = 0;
  st.page = 1;
  st.current = { query: '', cityName: '', jobTitle: '' };
  st.lastFirstKey = '';
  st.finishedAt = Date.now();
  await BAA.saveState(st);
  try { await BAA.setPending(null); } catch (e) { /* ignore */ }

  var clearText = '';
  if (changed) {
    if (cleared) {
      clearText = '，已清除原平台 cookie ' + cleared.removed + ' 项';
      if (cleared.remaining && cleared.remaining.length) {
        clearText += '（仍有 ' + cleared.remaining.join('/') + ' 未清除，建议到设置里再点一次「清除当前平台 cookie」）';
      }
    }
  }
  // v3.1: 切平台 = 配置跟着切 + 浏览器也跳过去。以前只切配置不切页面，
  // 于是浏览器还停在旧平台，内容脚本拿着新平台的规则去跑旧平台的页面，
  // 日志就会停在「拒绝导航到非当前平台域名」——用户看到的就是卡死。
  var nav = null;
  if (changed && opts.goto !== false) {
    try {
      nav = await focusPlatform(id, { login: false });
    } catch (e) {
      nav = { ok: false, msg: String(e && e.message || e) };
    }
  }

  appendLog(cleared && cleared.remaining && cleared.remaining.length ? 'warn' : 'info',
    '平台切换：' + (BAA.platformName(old) || old) + ' → ' + BAA.platformName(id) +
    (changed ? clearText : '（平台未变化）') +
    (nav && nav.ok ? ('，已打开' + BAA.platformName(id) + '页面') : ''));
  return {
    ok: true, platform: id, platformName: BAA.platformName(id),
    changed: changed, cleared: cleared, tabId: nav && nav.tabId, tabUrl: nav && nav.url,
    msg: changed
      ? ('已切换到 ' + BAA.platformName(id) +
         (cleared ? ('，并清除原平台 cookie ' + cleared.removed + ' 项') : '') +
         (nav && nav.ok ? '，已打开该平台页面' : '') +
         '。该平台的内置规则已生效，登录后即可开始。')
      : ('当前已是 ' + BAA.platformName(id))
  };
}

// Open the platform's login page directly. Works from ANY current page: it
// reuses an existing tab of that platform when there is one, otherwise opens a
// new one. No dependency on the user being on a search page.
/* v2.7: some platforms have no standalone login PAGE — 鱼泡的 /login/ 是 404 页，
   登录其实是首页弹出的扫码/验证码弹窗。这个自包含探针负责在任意平台页面上
   把登录入口点开（已经弹出表单就直接返回成功）。它必须在 executeScript 里
   序列化执行，所以不能引用外部变量。 */
BAA.openLoginEntry = function (spec) {
  spec = spec || {};
  function vis(e) {
    if (!e) return false;
    var r = e.getBoundingClientRect();
    var cs = getComputedStyle(e);
    return r.width > 2 && r.height > 2 && cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
  }
  function flat(e) { return (e.textContent || '').replace(/\s+/g, ''); }

  // 1) already showing a login form (phone / code / QR)
  var inputs = document.querySelectorAll('input[placeholder*="手机号"],input[placeholder*="验证码"]');
  for (var i = 0; i < inputs.length; i++) {
    if (vis(inputs[i])) return { opened: true, via: 'form-already' };
  }

  // 2) click the header entry (登录丨注册 / 登录/注册 / 登录)
  var labels = spec.loginEntryTexts || ['登录丨注册', '登录/注册', '登录', '立即登录'];
  var cands = document.querySelectorAll('a,button,[role="button"],span,div');
  var hit = null, hitText = '';
  for (var j = 0; j < cands.length; j++) {
    var t = flat(cands[j]);
    if (!t || t.length > 10) continue;
    for (var k = 0; k < labels.length; k++) {
      if (t === labels[k] || t.indexOf(labels[k]) === 0) {
        if (!vis(cands[j])) continue;
        // 优先 a / button，其次角色的可点击元素
        var tag = cands[j].tagName.toLowerCase();
        if (tag === 'a' || tag === 'button' || cands[j].getAttribute('role') === 'button') { hit = cands[j]; hitText = t; break; }
        if (!hit) { hit = cands[j]; hitText = t; }
      }
    }
    if (hit && (hit.tagName.toLowerCase() === 'a' || hit.tagName.toLowerCase() === 'button')) break;
  }
  if (hit) {
    try {
      var r2 = hit.getBoundingClientRect();
      var opt = { bubbles: true, cancelable: true, clientX: r2.left + r2.width / 2, clientY: r2.top + r2.height / 2 };
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (type) {
        var Ev = /pointer/.test(type) ? (window.PointerEvent || MouseEvent) : MouseEvent;
        hit.dispatchEvent(new Ev(type, opt));
      });
      return { opened: true, via: 'click:' + hitText };
    } catch (e) {
      try { hit.click(); return { opened: true, via: 'js-click:' + hitText }; } catch (e2) { /* ignore */ }
    }
  }
  return { opened: false };
};

/* v3.1: 把「浏览上下文」带到指定平台。
   用户的要求是：在前端选好平台后，点登录/开始就应该跳到对应平台的主页，
   而不是让浏览器停在另一个平台的页面上拿错配置硬跑。
   这里只操作「本平台自己的标签页」：有就激活（优先搜索页），没有才新建；
   永远不会把别的平台的页面导航走，所以两边的页面可以并存。 */
async function focusPlatform(platformId, opts) {
  opts = opts || {};
  var cfg = await BAA.getConfig();
  var id = BAA.PLATFORM_DEFAULTS[platformId] ? platformId : cfg.platform;
  var host = platformHost(id);
  var wanted = opts.login ? platformLoginUrl(id) : platformOrigin(id);
  if (opts.cacheBust) wanted = withCacheBust(wanted, 'v=');

  var tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch (e) { /* ignore */ }

  var best = null, bestScore = -1;
  for (var i = 0; i < tabs.length; i++) {
    var u = tabs[i].url || '';
    if (!u || u.indexOf(host) < 0) continue;
    if (/^chrome-extension:|^chrome:/.test(u)) continue;
    var score = 1;
    // 搜索页 / 列表页最值得复用 —— 切回来就能直接继续跑
    if (/\/web\/geek\/jobs|\/topic\//.test(u)) score += 4;
    if (tabs[i].active) score += 2;
    if (score > bestScore) { bestScore = score; best = tabs[i]; }
  }

  if (best) {
    try { await chrome.tabs.update(best.id, { active: true }); } catch (e) { /* ignore */ }
    var cur = best.url || '';
    // 已经在目标域名里就别乱跳（会把正在跑的搜索页弄丢）
    if (!cur || cur.indexOf(host) < 0) {
      try { await chrome.tabs.update(best.id, { url: wanted }); } catch (e) { /* ignore */ }
    }
    try {
      var w = await chrome.windows.get(best.windowId);
      if (w && w.state === 'minimized') await chrome.windows.update(best.windowId, { state: 'normal' });
      await chrome.windows.update(best.windowId, { focused: true });
    } catch (e) { /* ignore */ }
    return { ok: true, platform: id, tabId: best.id, url: wanted, reused: true, navigated: false };
  }

  var created = null;
  try { created = await chrome.tabs.create({ url: wanted, active: true }); } catch (e) {
    return { ok: false, platform: id, msg: String(e && e.message || e) };
  }
  return { ok: true, platform: id, tabId: created && created.id, url: wanted, reused: false, navigated: true };
}
BAA.focusPlatform = focusPlatform;

async function openLogin(platformId) {
  var cfg = await BAA.getConfig();
  var id = BAA.PLATFORM_DEFAULTS[platformId] ? platformId : cfg.platform;
  var spec = BAA.getPlatformView(cfg, id).login || {};
  var loginUrl = platformLoginUrl(id);
  var url = withCacheBust(loginUrl, 'login=');
  var host = platformHost(id);
  var home = platformOrigin(id);

  var tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch (e) { /* ignore */ }
  var active = null, samePlatform = null;
  for (var i = 0; i < tabs.length; i++) {
    var u = tabs[i].url || '';
    if (u.indexOf(host) < 0) continue;
    if (/chrome-extension:|chrome:\/\//.test(u)) continue;
    if (!samePlatform) samePlatform = tabs[i];
    if (tabs[i].active) { active = tabs[i]; break; }
  }
  var target = active || samePlatform;
  var tabId, reused = false, navigated = false;

  if (target) {
    tabId = target.id;
    reused = true;
    var cur = target.url || '';
    // 已经是平台页面：不再跳转（跳走会把正在跑的搜索页弄丢），直接点开登录弹窗。
    var onPlatform = cur.indexOf(host) >= 0 && !/\/login|404|error/i.test(cur);
    if (!onPlatform) {
      await chrome.tabs.update(tabId, { url: url });
      navigated = true;
      await sleepMs(1200);
    }
    try { await chrome.tabs.update(tabId, { active: true }); } catch (e) { /* ignore */ }
  } else {
    var created = await chrome.tabs.create({ url: url, active: true });
    tabId = created.id;
    navigated = true;
  }

  // 等页面就绪后把登录入口点开；鱼泡这类没有登录页的平台全靠这一步。
  var entry = null;
  for (var k = 0; k < 14; k++) {
    try {
      var res = await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: BAA.openLoginEntry,
        args: [spec]
      });
      var out = res && res[0] && res[0].result;
      if (out && out.opened) { entry = out; break; }
    } catch (e) { /* page still loading / restricted */ }
    await sleepMs(700);
  }

  var finalTab = null;
  try { finalTab = await chrome.tabs.get(tabId); } catch (e) { /* ignore */ }
  return {
    ok: true, tabId: tabId, url: (finalTab && finalTab.url) || url,
    loginUrl: loginUrl, home: home, reused: reused, navigated: navigated,
    entry: entry, platform: id,
    msg: entry ? '已打开' + BAA.platformName(id) + '登录入口，请完成登录'
      : '已打开' + BAA.platformName(id) + '，请点右上角「登录」完成登录'
  };
}

async function refreshPlatformTab(platformId) {
  var cfg = await BAA.getConfig();
  var id = BAA.PLATFORM_DEFAULTS[platformId] ? platformId : cfg.platform;
  var host = platformHost(id);
  var tabs = [];
  try { tabs = await chrome.tabs.query({ url: ['*://*.' + host + '/*', '*://' + host + '/*'] }); } catch (e) { /* ignore */ }
  if (!tabs.length) {
    try { tabs = await chrome.tabs.query({ active: true, currentWindow: true }); } catch (e) { /* ignore */ }
    tabs = tabs.filter(function (t) { return (t.url || '').indexOf(host) >= 0; });
  }
  if (!tabs.length) return { ok: false, msg: '没有找到' + BAA.platformName(id) + '标签页，请先点「登录平台」' };
  tabs.sort(function (a, b) { return (b.active ? 1 : 0) - (a.active ? 1 : 0); });
  await chrome.tabs.reload(tabs[0].id, { bypassCache: true });
  return { ok: true, tabId: tabs[0].id, msg: '已刷新页面' };
}

function pageRoleFor(id, url) {
  var pdef = BAA.PLATFORM_DEFAULTS[id] || {};
  var rules = pdef.pageRules || {};
  var u = String(url || '');
  if (!u) return 'other';
  if (rules.chatUrlPattern && u.indexOf(rules.chatUrlPattern) >= 0) return 'chat';
  if (rules.detailUrlPattern && u.indexOf(rules.detailUrlPattern) >= 0) return 'detail';
  if (rules.searchUrlPattern && u.indexOf(rules.searchUrlPattern) >= 0) return 'search';
  if (id === 'boss') {
    if (/\/web\/geek\/chat/.test(u)) return 'chat';
    if (/job_detail/.test(u)) return 'detail';
    if (/\/web\/geek\/jobs/.test(u)) return 'search';
  }
  if (id === 'yupao') {
    if (/\/zhaogong\//.test(u)) return 'detail';
    if (/\/topic\//.test(u)) return 'search';
  }
  return 'other';
}

// Everything the popup needs, answered by the worker so the panel can never
// show "未连接" just because the current tab has no content script.
async function popupStatus() {
  var cfg = await BAA.getConfig();
  var id = cfg.platform;
  var state = await BAA.getState();
  var snap = null;
  try { snap = await BAA.getLoginSnapshot(); } catch (e) { /* ignore */ }
  var run = null;
  try { run = await BAA.getRun(); } catch (e) { /* ignore */ }
  var tab = null;
  try {
    var ts = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = ts[0] || null;
  } catch (e) { /* ignore */ }
  var host = platformHost(id);
  var url = (tab && tab.url) || '';
  return {
    ok: true,
    platform: id,
    platformName: cfg.platformName,
    domain: cfg.domain,
    state: state,
    run: run,
    dailyLimit: cfg.behavior.dailyLimit,
    dryRun: cfg.behavior.dryRun,
    login: snap,
    loginSnapshotText: BAA.loginSnapshotText(snap),
    pageRole: pageRoleFor(id, url),
    url: url,
    tabId: tab && tab.id,
    onPlatform: url.indexOf(host) >= 0,
    platforms: BAA.PLATFORM_IDS.map(function (pid) {
      return { id: pid, name: BAA.platformName(pid), loginUrl: platformLoginUrl(pid) };
    })
  };
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;

  // Options page "立即检查一次定时状态" button.
  if (msg.type === 'BAA_SCHEDULE_TICK') {
    scheduleTick();
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'BAA_NAVIGATE') {
    var url = String(msg.url || '');
    var senderHost = '';
    try { senderHost = new URL(String((sender.tab && sender.tab.url) || '')).hostname; } catch (e) { senderHost = ''; }
    BAA.getConfig().then(function (cfg) {
      // v3.1: 用「发起请求的这个页面属于哪个平台」来校验目标域名，而不是用
      // 「配置里当前选的平台」。否则切平台的瞬间（配置已是鱼泡、页面还是 BOSS）
      // 内容脚本的任何翻页/跳转都会被判成非法导航 —— 那正是「卡死」的表象。
      var ownId = BAA.detectPlatformByHost(senderHost) || cfg.platform;
      var allowedHost = String(BAA.getPlatformView(cfg, ownId).domain || '.zhipin.com').replace(/^\./, '');
      var host;
      try { host = new URL(url).hostname; } catch (e) { host = ''; }
      if (!host || (host !== 'www.' + allowedHost && host !== 'm.' + allowedHost && host.indexOf(allowedHost) < 0)) {
        sendResponse({ ok: false, msg: '拒绝导航到非「' + BAA.platformName(ownId) + '」域名：' + (host || url) });
        return;
      }
      var tabId = sender.tab && sender.tab.id;
      var promise = tabId
        ? chrome.tabs.update(tabId, { url: url })
        : chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
            return tabs.length ? chrome.tabs.update(tabs[0].id, { url: url }) : Promise.reject(new Error('未找到标签页'));
          });
      promise.then(function () { sendResponse({ ok: true }); })
        .catch(function (e) { sendResponse({ ok: false, msg: String(e.message || e) }); });
    }).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  }

  if (msg.type === 'BAA_COOKIE_PROBE') {
    cookieProbe(sendResponse);
    return true;
  }

  // v2.6: page-independent status (popup no longer needs a content script).
  if (msg.type === 'BAA_POPUP_STATUS') {
    popupStatus().then(sendResponse).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  }

  // v2.6: the single login self-check used by popup AND content script.
  if (msg.type === 'BAA_CHECK_LOGIN') {
    checkLoginFor(msg.platform).then(sendResponse).catch(function (e) {
      sendResponse({ ok: false, status: 'unknown', reason: String(e && e.message || e) });
    });
    return true;
  }

  // v2.6: switch platform = persist + clear the previous platform's cookies +
  // drop the stale login snapshot + reset the run state.
  if (msg.type === 'BAA_SET_PLATFORM') {
    switchPlatform(msg.platform, {
      clearOldCookies: msg.clearOldCookies !== false,
      goto: msg.goto !== false
    })
      .then(sendResponse).catch(function (e) {
        sendResponse({ ok: false, msg: String(e && e.message || e) });
      });
    return true;
  }

  // v3.1: 只把浏览器带到指定平台的页面（不动配置），面板「打开平台页面」用。
  if (msg.type === 'BAA_FOCUS_PLATFORM') {
    focusPlatform(msg.platform, { login: !!msg.login }).then(sendResponse)
      .catch(function (e) { sendResponse({ ok: false, msg: String(e && e.message || e) }); });
    return true;
  }

  // v2.6: go straight to the selected platform's login page from anywhere.
  if (msg.type === 'BAA_OPEN_LOGIN') {
    openLogin(msg.platform).then(sendResponse).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  }

  if (msg.type === 'BAA_REFRESH_PLATFORM_TAB') {
    refreshPlatformTab(msg.platform).then(sendResponse).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  }

  if (msg.type === 'BAA_CLEAR_COOKIES') {
    BAA.getConfig().then(function (cfg) {
      return clearPlatformCookies(msg.platform || cfg.platform);
    }).then(async function (r) {
      try { await chrome.storage.local.remove(BAA.KEYS.LOGIN); } catch (e) { /* ignore */ }
      appendLog(r.remaining && r.remaining.length ? 'warn' : 'info',
        '已手动清除平台 cookie ' + r.removed + ' 项' +
        (r.remaining && r.remaining.length ? ('，未清除：' + r.remaining.join('/')) : ''));
      sendResponse({ ok: true, cleared: r });
    }).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  }

  if (msg.type === 'BAA_GO_LOGIN') {
    goLogin(sender, sendResponse);
    return true;
  }

  // Lets a content script tell whether it is the original search tab or a
  // chat tab opened by BOSS via window.open().
  if (msg.type === 'BAA_WHOAMI') {
    sendResponse({ ok: true, tabId: sender.tab && sender.tab.id });
    return;
  }

  if (msg.type === 'BAA_CLOSE_TAB') {
    if (!sender.tab || !sender.tab.id) { sendResponse({ ok: false }); return; }
    chrome.tabs.remove(sender.tab.id).then(function () { sendResponse({ ok: true }); })
      .catch(function (e) { sendResponse({ ok: false, msg: String(e.message || e) }); });
    return true;
  }

  if (msg.type === 'BAA_NOTIFY') {
    notify(msg.message);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'BAA_OPEN_PANEL_HINT') {
    notify('请点击浏览器工具栏上的扩展图标打开控制面板');
    sendResponse({ ok: true });
    return true;
  }

  return;
});
