(function (root) {
  'use strict';

  var BAA = (root.BAA = root.BAA || {});
  var K = {
    CONFIG: 'baa.config',
    STATE: 'baa.state',
    HISTORY: 'baa.history',
    LOGS: 'baa.logs',
    BGLOGS: 'baa.bglogs',
    PENDING: 'baa.pending',
    RUN: 'baa.run',
    SCHEDULE: 'baa.schedule',
    AUTOSTART: 'baa.autostart'
  };

  BAA.VERSION = '3.1.0';
  BAA.KEYS = K;

  /* ------------------------------------------------------------------ *
   * City option lists (per platform; the yupao codes come from its URL scheme)
   * ------------------------------------------------------------------ */
  BAA.CITY_OPTIONS_BOSS = [
    { code: '100010000', name: '全国' },
    { code: '101010100', name: '北京' },
    { code: '101020100', name: '上海' },
    { code: '101280100', name: '广州' },
    { code: '101280600', name: '深圳' },
    { code: '101210100', name: '杭州' },
    { code: '101190400', name: '苏州' },
    { code: '101200100', name: '武汉' },
    { code: '101270100', name: '成都' },
    { code: '101110100', name: '西安' },
    { code: '101250100', name: '长沙' },
    { code: '101230100', name: '厦门' },
    { code: '101030100', name: '天津' },
    { code: '101260100', name: '重庆' },
    { code: '101290100', name: '昆明' },
    { code: '101220100', name: '合肥' },
    { code: '101240100', name: '郑州' },
    { code: '101060100', name: '南京' },
    { code: '101070100', name: '济南' },
    { code: '101150100', name: '青岛' },
    { code: '101160100', name: '大连' },
    { code: '101170100', name: '沈阳' },
    { code: '101040100', name: '石家庄' },
    { code: '101050100', name: '太原' },
    { code: '101130100', name: '福州' },
    { code: '101300100', name: '海口' },
    { code: '101310100', name: '贵阳' },
    { code: '101320100', name: '南昌' },
    { code: '101140100', name: '哈尔滨' },
    { code: '101180100', name: '长春' }
  ];

  // yupao city codes are taken from its URL scheme (e.g. https://www.yupao.com/topic/a77c0/).
  // a77 = 深圳 is confirmed from the user's link. Others are the common ones; add more
  // by watching the URL when you switch cities on yupao.com.
  BAA.CITY_OPTIONS_YUPAO = [
    { code: 'a77', name: '深圳' },
    { code: 'a78', name: '广州' },
    { code: 'a1', name: '北京' },
    { code: 'a2', name: '上海' },
    { code: 'a57', name: '成都' },
    { code: 'a93', name: '武汉' },
    { code: 'a73', name: '杭州' },
    { code: 'a61', name: '重庆' },
    { code: 'a52', name: '西安' },
    { code: 'a30', name: '东莞' },
    { code: 'a31', name: '佛山' },
    { code: 'a45', name: '长沙' },
    { code: 'a20', name: '南京' }
  ];

  /* ------------------------------------------------------------------ *
   * PER-PLATFORM DEFAULTS. Each platform carries its own URL template,
   * selectors, login hints, page-role rules and apply behaviour. The active
   * platform is chosen by config.platform and its defaults are merged with the
   * user's per-platform overrides at getConfig() time.
   * ------------------------------------------------------------------ */
  BAA.PLATFORM_DEFAULTS = {
    boss: {
      id: 'boss',
      name: 'BOSS直聘',
      domain: '.zhipin.com',
      // v2.7: /web/geek/login 会被前端路由渲染成 404 页；真实的登录/注册入口是
      // /web/user/（首页页头「登录」链接指向这里）。
      loginUrl: 'https://www.zhipin.com/web/user/?ka=header-login',
      loginEntryTexts: ['登录/注册', '登录', '立即登录'],
      searchUrlTemplate: 'https://www.zhipin.com/web/geek/jobs?query={query}&city={city}&page={page}',
      cities: BAA.CITY_OPTIONS_BOSS,
      pageRules: {
        searchUrlPattern: '/web/geek/jobs',
        chatUrlPattern: '/web/geek/chat',
        detailUrlPattern: '',
        allowRunOnOtherPages: false
      },
      applyBehavior: { type: 'chat' },
      // v2.6: the login self-check is owned by the background worker and works
      // on ANY page of the platform (login page included), never only on the
      // search page. sessionCookies are the strong signal: they are only ever
      // set after a real sign-in, so a stale page can no longer report
      // "unknown" on an account that is in fact logged in.
      loginOrigin: 'https://www.zhipin.com/',
      login: {
        sessionCookies: ['zp_at', 'geek_zp_token', 'tgt'],
        guestSelectors: ['.header-login-btn', '.guide-login-btn', 'a[href*="/web/geek/login"]'],
        guestTexts: ['登录/注册', '立即登录', '登录账号，查看更多好职位', '登录BOSS直聘'],
        loggedSelectors: ['.nav-figure', '.user-nav', '.header-user-nav', '[class*="user-avatar"]',
                          '[class*="geek-info"]', '[class*="header-user"]'],
        loggedTexts: ['退出登录', '我的简历', '求职者中心'],
        cookieNames: ['zp_at', '__zp_stoken__', 'wt2', 'sid', 'geek_zp_token', 'tgt', 'uid']
      },
      // All selectors verified against the LIVE BOSS search page on 2026-11-04.
      selectors: {
        jobCard: ['li.job-card-box', '.job-card-wrap', 'ul.job-list-box > li', 'li[class*="job-card"]'],
        title: ['a.job-name', '.job-name', '[class*="job-name"]'],
        salary: ['.job-salary', 'span.job-salary', '[class*="job-salary"]', '.salary'],
        company: ['.boss-name', '.company-name', '[class*="company-name"]'],
        link: ['a.job-name[href*="job_detail"]', 'a[href*="job_detail"]'],
        infoBlock: ['.tag-list', '.job-info', '.job-card-footer'],
        tagList: ['.tag-list li', '[class*="tag-list"] li'],
        companyInfo: ['.company-location', '.boss-info', '.job-card-footer'],
        chatButton: ['a.op-btn-chat', '[class*="op-btn-chat"]', 'a[ka^="cpc_job_list_chat"]',
                     'a[ka*="job_list_chat"]', '.btn-startchat'],
        detailBox: ['.job-detail-box', '.job-detail-container', '[class*="job-detail-box"]'],
        detailName: ['.job-detail-box .job-name', '.job-detail-header .job-name'],
        applyButton: ['a.op-btn-chat', '.btn-apply', 'a[class*="apply"]'],
        nextPage: ['a.next', '.options-pages a:last-child', 'a[ka*="page-next"]', '[class*="page-next"]'],
        loadMore: ['.load-more', '[class*="load-more"]', '.more-btn'],
        dialog: ['.dialog-wrap', '.boss-chat-dialog', '[class*="greet-dialog"]',
                 '[class*="dialog-container"]', '[role="dialog"]'],
        dialogInput: ['.dialog-wrap textarea', '[class*="greet-dialog"] textarea',
                      '.dialog-wrap [contenteditable="true"]', '[class*="greet"] [contenteditable]', 'textarea'],
        dialogSend: ['.dialog-wrap .btn-send', '.dialog-wrap .btn-primary', '.btn-send', 'button[class*="send"]'],
        verification: ['[class*="verify-wrap"]', 'iframe[src*="verify"]', '#nc_wrapper', '[class*="captcha"]', '[class*="slider-verify"]'],
        chatSessionItem: ['li:has(.friend-content-warp)', 'li[role="listitem"]',
                          '.friend-content-warp', '[class*="friend-content"]'],
        chatComposer: ['#chat-input', '.chat-input[contenteditable="true"]',
                       '.chat-editor [contenteditable="true"]', '.editor-container [contenteditable]',
                       'textarea[class*="chat"]', 'textarea'],
        chatSend: ['button.btn-send', '.chat-op .btn-send', '.btn-send',
                   'button[type="send"]', '[class*="send-btn"]'],
        chatConversationHead: ['.chat-conversation', '[class*="chat-conversation"]',
                               '[class*="chat-header"]', '.chat-title'],
        chatMessage: ['.message-content', '.chat-message', '[class*="message-text"]', '[class*="text-content"]'],
        chatFrame: ['iframe[src*="chat"]', 'iframe[src*="im"]', 'iframe']
      },
      alreadyChattedTexts: ['继续沟通', '已沟通', '已投递', '已沟通过', '查看沟通'],
      verificationKeywords: ['请完成安全验证', '滑动验证', '安全验证', '操作过于频繁', '登录已失效', '异常操作', '访问受限', '请进行身份验证']
    },

    yupao: {
      id: 'yupao',
      name: '鱼泡直聘',
      domain: '.yupao.com',
      // v2.7: 鱼泡没有独立的登录页面 —— /login/ 是 404 页（会跳回首页）。登录是
      // 首页右上角「登录丨注册」弹出的扫码/验证码弹窗，所以这里指向首页，
      // 由后台的 openLoginEntry 探针把弹窗点开。
      loginUrl: 'https://www.yupao.com/',
      loginEntryTexts: ['登录丨注册', '登录/注册', '立即登录', '登录'],
      // a77 = 深圳 ; city code + "c0" forms the search bucket. Confirmed from the
      // user's link https://www.yupao.com/a77/ and /topic/a77c0/?keywords=...
      searchUrlTemplate: 'https://www.yupao.com/topic/{city}c0/?keywords={query}',
      cities: BAA.CITY_OPTIONS_YUPAO,
      pageRules: {
        // Listing pages match /topic/ ; the job detail page (opened in a new tab)
        // matches /zhaogong/ and is where 聊一聊 + the in-page IM widget live.
        searchUrlPattern: '/topic/',
        chatUrlPattern: '',
        detailUrlPattern: '/zhaogong/',
        allowRunOnOtherPages: false
      },
      // The listing card is itself the job link (target=_blank). Clicking it opens
      // the detail page in a NEW tab; that tab handles 聊一聊 + greeting, then closes.
      applyBehavior: {
        type: 'detail',
        openInNewTab: true,
        // Live-verified (2026-11-05): the yupao detail page contact button reads
        // "免费聊" and sits on a <span class="addag"> (NOT "聊一聊").
        chatButtonText: '免费聊',
        resumeAfter: 'closeTab',
        detailWaitMs: 6000
      },
      // VERIFIED on the real logged-in account (阳志伟) via CDP on 2026-11-05:
      //   chrome.cookies.getAll({domain:'.yupao.com'}) returns exactly
      //   areaInfo / rp_c / DEVICEID / ROLE / USERID / current_identity
      //   header = <header id="YPHeader" data-testid="top-nav">
      //   user dropdown = a[href="/user/resume-info"] + "退出登录"
      // Minified class names (aeaac / adjjj / ...) change every build, so NONE
      // of these markers depend on them.
      // v2.7.1 CORRECTION (measured 2026-11-06): USERID / current_identity DO
      // survive a server-side session invalidation. After the auth cookies
      // TOKEN / ROLE disappeared, both names were still present while EVERY
      // page (incl. /zhaogong/) rendered "登录丨注册" and /chat/ redirected to
      // /a77/. The real auth cookies are TOKEN (.yupao.com) and ROLE
      // (.www.yupao.com). A cookie NAME is therefore never sufficient proof —
      // background.checkLoginFor() must keep the cookie + DOM cross-check.
      loginOrigin: 'https://www.yupao.com/',
      login: {
        // Weak signal on purpose. Kept as the trigger for the cross-check, NOT
        // as proof of a live session: if these hit while a same-platform tab
        // shows a visible guest header, checkLoginFor() reports "expired".
        // TOKEN / ROLE stay in cookieNames below so "清除本平台 Cookie" also
        // wipes the real credentials.
        sessionCookies: ['USERID', 'current_identity'],
        // Guest entries must be VISIBLE: yupao keeps a hidden
        // <div style="display:none"> with "登录丨注册" even while signed in.
        // Kept narrow on purpose: a broad "#YPHeader button" matches ordinary
        // icon buttons and produced false "需要登录" verdicts.
        guestSelectors: ['#YPHeader a[href*="login"]', '#YPHeader [class*="login"]',
                         'a[href="/login"]'],
        guestTexts: ['登录丨注册', '登录|注册', '立即登录', '登录注册后可以'],
        // Stable URL / attribute markers. The user dropdown opens on hover only,
        // so DOM presence (not visibility) is the right signal here.
        loggedSelectors: ['#YPHeader a[href="/user/resume-info"]',
                          '#YPHeader a[href^="/user/"]',
                          'header#YPHeader[data-testid="top-nav"] a[href^="/user/"]'],
        loggedTexts: ['退出登录', '个人中心', '账号与安全中心', '切换为招聘者'],
        cookieNames: ['USERID', 'current_identity', 'TOKEN', 'ROLE', 'rp_c', 'DEVICEID', 'areaInfo']
      },
      // yupao uses minified/auto-generated class names (acdgg, accbd...), so the
      // parsing relies on DOM STRUCTURE (anchors, indices), not class names.
      selectors: {
        jobCard: ['a[href^="/zhaogong/"][href$=".html"]'],
        title: ['div div div', 'a[href^="/zhaogong/"] div div div'],
        salary: ['span'],
        company: ['a[href^="/qiye/"]'],
        link: ['a[href^="/zhaogong/"][href$=".html"]'],
        area: ['span'],
        tagList: ['span'],
        companyInfo: ['a[href^="/qiye/"]'],
        chatButton: ['span.addag', '[class*="liao"]', '[class*="apply"]', 'button', 'a'],
        detailBox: ['[class*="job"]', 'main'],
        detailName: ['h1', '[class*="title"]'],
        applyButton: ['span.addag', '[class*="liao"]', 'button', 'a'],
        nextPage: ['a.next', '.page a:last-child', '[class*="page-next"]', '[class*="next"]'],
        loadMore: ['[class*="load-more"]', '[class*="more"]', '.more-btn'],
        dialog: ['[class*="dialog"]', '[class*="modal"]', '[role="dialog"]'],
        dialogInput: ['textarea', '[contenteditable="true"]'],
        dialogSend: ['[class*="send"]', 'button'],
        verification: ['[class*="verify"]', 'iframe[src*="verify"]', '[class*="captcha"]', '[class*="slider"]'],
        chatSessionItem: ['[class*="chat"]', '[class*="im"]', '[class*="session"]'],
        // Live-verified (2026-11-05): the yupao in-page IM composer is a
        // contenteditable <div class="fb-editor" data-fish-editor="true"> (fish-editor),
        // not a <textarea>. Prefer those before the generic fallbacks.
        chatComposer: ['.fb-editor', '[data-fish-editor="true"]', '[contenteditable="true"]', 'textarea', '[class*="chat"] textarea', '[class*="im"] textarea'],
        // Live-verified (2026-11-05): the yupao IM send button is <button class="btn-send">.
        // Prefer the specific class before the generic fallbacks so we never mis-click
        // a page-level "send code" / "send SMS" button.
        chatSend: ['button.btn-send', '.btn-send', '[class*="btn-send"]', '[class*="send"]', 'button[type="button"]', 'button'],
        chatConversationHead: ['[class*="chat"] [class*="head"]', '[class*="im"] [class*="head"]', '[class*="title"]'],
        chatMessage: ['[class*="message"]', '[class*="chat"] [class*="text"]'],
        chatFrame: ['iframe']
      },
      // Live-verified (2026-11-05): after you click 免费聊 and the conversation is
      // established, the button text becomes "继续聊" (NOT "继续沟通"). Both must be
      // treated as "already chatted" so the tool skips re-contacting that recruiter.
      alreadyChattedTexts: ['继续聊', '继续沟通', '已沟通', '已聊过', '已投递', '聊过了', '发送成功', '已发送', '查看沟通'],
      verificationKeywords: ['请完成安全验证', '滑动验证', '安全验证', '操作过于频繁', '登录已失效', '异常操作', '访问受限', '请进行身份验证', '请先登录', '点击登录']
    }
  };

  BAA.PLATFORM_IDS = Object.keys(BAA.PLATFORM_DEFAULTS);
  BAA.platformName = function (id) {
    var p = BAA.PLATFORM_DEFAULTS[id];
    return p ? p.name : id;
  };

  // Shared (platform-agnostic) defaults.
  BAA.DEFAULT_STATE = {
    status: 'idle',
    queue: [],
    queueIndex: 0,
    page: 1,
    today: '',
    todayCount: 0,
    stats: { scanned: 0, matched: 0, applied: 0, skipped: 0, duplicated: 0, failed: 0 },
    current: { query: '', cityName: '', jobTitle: '' },
    blockedReason: '',
    loginStatus: 'unknown',
    loginReason: '',
    lastLoginCheck: 0,
    lastFirstKey: '',
    summary: '',
    startedAt: 0,
    finishedAt: 0,
    updatedAt: 0,
    phase: '',
    heartbeat: 0,
    runOwner: ''
  };

  BAA.DEFAULT_BEHAVIOR = {
    dryRun: true,
    dailyLimit: 40,
    minDelaySec: 12,
    maxDelaySec: 28,
    pageDelaySec: 4,
    maxPagesPerTask: 5,
    maxJobsPerPage: 0,
    action: 'chat',
    greetingEnabled: true,
    greetingTemplate: '您好，我看到贵司的「{岗位}」岗位，与我的经历比较匹配，方便进一步沟通吗？',
    autoSend: true,
    skipIfAlreadyChatted: true,
    dedupeDays: 30,
    // v2.9: 公司级去重。BOSS 一家公司常同时挂多个岗位（job id 不同，公司名相同），
    // 只按 job id 去重会把同一家公司反复骚扰。开启后按「公司名归一化」匹配本地
    // 记录，命中即跳过，不管岗位是否不同。
    dedupeByCompany: true,
    stopOnVerification: true,
    retryPerJob: 1,
    showFloatingBadge: true,
    openDetailBeforeChat: true,
    detailWaitMs: 1000,
    pageReadyTimeoutMs: 15000,
    chatWaitMs: 2500,
    strictDetailMatch: true,
    actionTimeoutMs: 20000,
    afterChat: 'return',
    afterChatDelayMs: 1200,
    chatGreetingEnabled: true,
    chatComposerWaitMs: 9000,
    chatSendWaitMs: 3000,
    chatVerifyRecipient: true,
    chatStrictRecipient: false,
    chatSendKeyFallback: true,
    chatCloseNewTab: true,
    chatLandingTimeoutMs: 12000,
    resumeGuardMs: 1200,
    watchdogStaleSec: 10,
    loginCheckEnabled: true,
    autoWaitForLogin: true,
    loginWaitSec: 300,
    loginPollSec: 3
  };

  BAA.DEFAULT_FILTER = {
    titleIncludeAny: [],
    titleIncludeAll: [],
    titleExclude: ['销售', '客服', '电话销售', '地推', '保险'],
    companyInclude: [],
    companyExclude: [],
    tagIncludeAny: [],
    tagExclude: [],
    cities: [],
    salaryMin: 0,
    salaryMax: 0,
    experienceAllow: [],
    educationAllow: [],
    companySizeAllow: [],
    companyStageAllow: [],
    excludeOutsource: true,
    hrActiveOnly: false,
    maxPublishDays: 0,
    titleRegex: '',
    companyRegex: ''
  };

  // v2.5: fixed time windows for the scheduler (platform-agnostic).
  BAA.DEFAULT_SCHEDULE = {
    enabled: false,
    weekdays: [0, 1, 2, 3, 4, 5, 6],
    windows: [
      { start: '09:00', end: '12:00', enabled: true },
      { start: '14:00', end: '18:00', enabled: true }
    ],
    onWindowEnd: 'pause',
    autoOpenTab: true,
    openInBackground: true,
    notify: true,
    retryBlocked: false,
    startOnBrowserLaunch: true
  };

  BAA.DEFAULT_CONFIG = {
    version: 1,
    platform: 'boss',
    overrides: {},
    tasksByPlatform: {
      boss: [{ query: '新媒体运营', city: '101280600', cityName: '深圳', enabled: true }],
      yupao: [{ query: '新媒体运营', city: 'a77', cityName: '深圳', enabled: true }]
    },
    filter: clone(BAA.DEFAULT_FILTER),
    advancedRules: [],
    advancedMode: 'all',
    behavior: clone(BAA.DEFAULT_BEHAVIOR),
    schedule: clone(BAA.DEFAULT_SCHEDULE)
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function isPlain(v) { return v && typeof v === 'object' && !Array.isArray(v); }

  /* ================================================================== *
   * v3.1 — 每个平台内置一套「写死」的规则表（PRESET）。
   *
   * 之前只有选择器/登录是按平台分开的，搜索任务、筛选条件、投递行为、
   * 定时时段全靠用户手动填、而且两平台共用一份，切平台后经常「用鱼泡的
   * 规则去跑 BOSS 页面」。这里把每个平台该跑什么固化成常量列表：
   *
   *   boss  : 深圳(101280600) · 新媒体运营 · 排除销售/客服类 · 每日 50 · 5 页
   *   yupao : 深圳(a77)      · 新媒体运营 · 排除销售/客服类 · 每日 50 · 5 页
   *
   * 切换到某个平台 → 该平台这套立刻生效；设置页「恢复本平台默认规则」
   * 一键把该平台的所有段落还原成这里的值，另一个平台的设置不受影响。
   * ================================================================== */
  BAA.PLATFORM_PRESETS = {
    boss: {
      name: 'BOSS直聘',
      tasks: [
        { query: '新媒体运营', city: '101280600', cityName: '深圳', enabled: true }
      ],
      filter: merge(BAA.DEFAULT_FILTER, {
        titleExclude: ['销售', '客服', '电话销售', '地推', '保险',
                       '居家', '日结', '线上', '代发', '医疗'],
        excludeOutsource: true,
        salaryMin: 6.5,
        salaryMax: 12
      }),
      behavior: merge(BAA.DEFAULT_BEHAVIOR, {
        dryRun: false,
        dailyLimit: 50,
        maxPagesPerTask: 5,
        maxJobsPerPage: 0,
        action: 'chat',
        greetingEnabled: true,
        chatGreetingEnabled: true,
        skipIfAlreadyChatted: true,
        dedupeByCompany: true,
        dedupeDays: 30
      }),
      schedule: clone(BAA.DEFAULT_SCHEDULE)
    },

    yupao: {
      name: '鱼泡直聘',
      tasks: [
        { query: '新媒体运营', city: 'a77', cityName: '深圳', enabled: true }
      ],
      filter: merge(BAA.DEFAULT_FILTER, {
        titleExclude: ['销售', '客服', '电话销售', '地推', '保险',
                       '居家', '日结', '线上', '代发', '医疗'],
        excludeOutsource: true,
        salaryMin: 6.5,
        salaryMax: 12
      }),
      behavior: merge(BAA.DEFAULT_BEHAVIOR, {
        dryRun: false,
        dailyLimit: 100,
        maxPagesPerTask: 5,
        maxJobsPerPage: 0,
        action: 'chat',
        greetingEnabled: true,
        chatGreetingEnabled: true,
        skipIfAlreadyChatted: true,
        dedupeByCompany: true,
        dedupeDays: 30,
        // 鱼泡没有搜索页内沟通，必须进详情页点「免费聊」
        openDetailBeforeChat: true,
        afterChat: 'closeTab'
      }),
      schedule: clone(BAA.DEFAULT_SCHEDULE)
    }
  };

  // 取某平台的内置规则（深拷贝，调用方可随意改）。
  BAA.getPlatformPreset = function (id) {
    var p = BAA.PLATFORM_PRESETS[BAA.PLATFORM_DEFAULTS[id] ? id : 'boss'];
    return clone(p);
  };

  // 把某平台的内置规则整套写进配置（另一平台不动）。
  BAA.applyPlatformPreset = function (cfg, id) {
    var pid = BAA.PLATFORM_DEFAULTS[id] ? id : 'boss';
    var p = BAA.getPlatformPreset(pid);
    cfg.overrides = isPlain(cfg.overrides) ? cfg.overrides : {};
    var slot = cfg.overrides[pid] = isPlain(cfg.overrides[pid]) ? cfg.overrides[pid] : {};
    slot.filter = clone(p.filter);
    slot.behavior = clone(p.behavior);
    slot.schedule = clone(p.schedule);
    slot.advancedRules = [];
    slot.advancedMode = 'all';
    cfg.tasksByPlatform = isPlain(cfg.tasksByPlatform) ? cfg.tasksByPlatform : {};
    cfg.tasksByPlatform[pid] = clone(p.tasks);
    // 顶层字段同步一份 —— saveConfig 会按 cfg[sec] 回写槽位，两处必须一致，
    // 否则「恢复默认」保存下去的还是旧值。
    cfg.filter = clone(p.filter);
    cfg.behavior = clone(p.behavior);
    cfg.schedule = clone(p.schedule);
    cfg.advancedRules = [];
    cfg.advancedMode = 'all';
    cfg.tasks = clone(p.tasks);
    return cfg;
  };

  // 由域名反推平台 —— content script 用它确认「我这个页面属于哪个平台」，
  // 避免 BOSS 页面拿着鱼泡配置去跑。
  BAA.detectPlatformByHost = function (host) {
    var h = String(host || '').toLowerCase();
    if (!h) return '';
    for (var i = 0; i < BAA.PLATFORM_IDS.length; i++) {
      var id = BAA.PLATFORM_IDS[i];
      var d = String((BAA.PLATFORM_DEFAULTS[id] || {}).domain || '').replace(/^\./, '').toLowerCase();
      if (d && h.indexOf(d) >= 0) return id;
    }
    return '';
  };

  /* ------------------------------------------------------------------ *
   * v3.0: 每个平台各自一整套配置。
   * v2.x 只把 tasks / selectors / login 按平台分开，filter（筛选规则）、
   * behavior（投递行为）、schedule（定时执行）、advancedRules（高级规则）都留在
   * 配置顶层，被两个平台共用 —— 于是在 BOSS 下改的排除词、每日上限、时段会原样
   * 出现在鱼泡下，用户看到的就是「切了平台，下面几个页签一点变化都没有」。
   * 现在这些段落统一存在 overrides[platform] 里，resolvePlatform 时覆盖到顶层，
   * 对 content.js / background.js 保持「读 cfg.filter」这套接口不变。
   * ------------------------------------------------------------------ */
  BAA.PLATFORM_SECTIONS = ['filter', 'behavior', 'schedule', 'advancedRules', 'advancedMode'];

  // v3.1: 缺省值取「该平台自己的内置规则」，不再取全局共享默认值。
  // 某个平台从没被保存过设置时，直接跑它那套写死的规则。
  function sectionDefault(sec, platformId) {
    var p = BAA.PLATFORM_PRESETS[BAA.PLATFORM_DEFAULTS[platformId] ? platformId : 'boss']
      || BAA.PLATFORM_PRESETS.boss;
    if (sec === 'filter') return p.filter;
    if (sec === 'behavior') return p.behavior;
    if (sec === 'schedule') return p.schedule;
    if (sec === 'advancedRules') return [];
    return 'all';
  }

  function merge(base, patch) {
    var out = clone(base);
    if (!isPlain(patch)) return out;
    Object.keys(patch).forEach(function (k) {
      if (isPlain(patch[k]) && isPlain(out[k])) out[k] = merge(out[k], patch[k]);
      else if (patch[k] !== undefined) out[k] = clone(patch[k]);
    });
    return out;
  }
  BAA.clone = clone;
  BAA.merge = merge;

  function db() { return chrome.storage.local; }

  // Resolve the active platform's fields onto the config object the rest of the
  // code reads (searchUrlTemplate / selectors / login / pageRules / ...). Keeps
  // the rest of the codebase platform-agnostic.
  function resolvePlatform(cfg) {
    var id = cfg.platform && BAA.PLATFORM_DEFAULTS[cfg.platform] ? cfg.platform : 'boss';
    var pdef = BAA.PLATFORM_DEFAULTS[id];
    var ov = (isPlain(cfg.overrides) && isPlain(cfg.overrides[id])) ? cfg.overrides[id] : {};
    var merged = merge(pdef, ov);

    // --- login hardening --------------------------------------------------
    // Older builds persisted a GUESSED login config (wrong cookie names / DOM
    // markers) into overrides[platform]. Because merge() replaces arrays, that
    // stale override would otherwise silently beat the corrected defaults.
    // v2.6: every list is now the UNION of the verified default and whatever the
    // user added in 设置 → 页面选择器. Defaults can therefore never be silently
    // lost, while user additions still take effect (the lists are separate per
    // platform, so switching platforms cannot overwrite the other one).
    if (pdef.login) {
      var dl = pdef.login, ol = isPlain(ov.login) ? ov.login : {};
      var union = function (a, b) {
        var base = a || [], extra = b || [];
        return base.concat(extra.filter(function (x) { return base.indexOf(x) < 0; }));
      };
      merged.login = merge(dl, ol);
      merged.login.guestSelectors = union(dl.guestSelectors, ol.guestSelectors);
      merged.login.guestTexts = union(dl.guestTexts, ol.guestTexts);
      merged.login.loggedTexts = union(dl.loggedTexts, ol.loggedTexts);
      merged.login.cookieNames = union(dl.cookieNames, ol.cookieNames);
      merged.login.sessionCookies = union(dl.sessionCookies, ol.sessionCookies);
      merged.login.loggedSelectors = union(dl.loggedSelectors, ol.loggedSelectors);
    }
    cfg.platform = id;
    cfg.platformName = merged.name;
    cfg.domain = merged.domain;
    cfg.loginUrl = merged.loginUrl;
    cfg.loginOrigin = merged.loginOrigin || ('https://' + String(merged.domain || '').replace(/^\./, '') + '/');
    cfg.searchUrlTemplate = merged.searchUrlTemplate;
    cfg.cities = merged.cities;
    cfg.pageRules = merged.pageRules;
    cfg.applyBehavior = merged.applyBehavior;
    cfg.login = merged.login;
    cfg.selectors = merged.selectors;
    // v2.5.1: "already chatted" markers are platform-corrected values that a
    // stale user override must NEVER shadow (e.g. yupao's button reads "继续聊"
    // after chatting, not "继续沟通"). Older builds persisted a guessed list into
    // overrides[platform], which would otherwise silently beat the corrected
    // default. Always take this field from the code default; any user addition is
    // preserved via union so custom markers still work.
    var ovAlready = (isPlain(ov) && Array.isArray(ov.alreadyChattedTexts)) ? ov.alreadyChattedTexts : [];
    cfg.alreadyChattedTexts = clone(pdef.alreadyChattedTexts || []).concat(
      ovAlready.filter(function (x) { return (pdef.alreadyChattedTexts || []).indexOf(x) < 0; })
    );
    cfg.verificationKeywords = merged.verificationKeywords;

    // v3.0: 筛选规则 / 投递行为 / 定时执行 / 高级规则 —— 每个平台一套。
    // 只认 overrides[platform] 里自己那份，缺失时用代码默认值，绝不继承另一个平台。
    BAA.PLATFORM_SECTIONS.forEach(function (sec) {
      var own = isPlain(ov) ? ov[sec] : undefined;
      if (sec === 'advancedRules') {
        cfg.advancedRules = Array.isArray(own) ? clone(own) : [];
      } else if (sec === 'advancedMode') {
        cfg.advancedMode = (own === 'any') ? 'any' : 'all';
      } else {
        cfg[sec] = merge(sectionDefault(sec, id), isPlain(own) ? own : {});
      }
    });

    // v3.1: 该平台从未保存过任务时，直接用它内置规则里的搜索任务；
    // 用户主动删空（保存成 []）则尊重空列表，不强行塞回来。
    var ownTasks = (isPlain(cfg.tasksByPlatform) && cfg.tasksByPlatform[id] !== undefined)
      ? cfg.tasksByPlatform[id] : undefined;
    cfg.tasks = Array.isArray(ownTasks) ? ownTasks
      : clone((BAA.PLATFORM_PRESETS[id] || BAA.PLATFORM_PRESETS.boss).tasks);
    return cfg;
  }
  BAA.resolvePlatform = resolvePlatform;

  // v2.6: resolve any platform (not just the active one) against the same base
  // config. The options page uses this to render two INDEPENDENT selector /
  // login lists (BOSS and 鱼泡), so editing one can never overwrite the other.
  BAA.getPlatformView = function (baseCfg, id) {
    var c = merge(BAA.DEFAULT_CONFIG, baseCfg || {});
    if (!isPlain(c.overrides)) c.overrides = {};
    c.platform = BAA.PLATFORM_DEFAULTS[id] ? id : 'boss';
    resolvePlatform(c);
    if (isPlain(c.tasksByPlatform) && Array.isArray(c.tasksByPlatform[id])) c.tasks = c.tasksByPlatform[id];
    return c;
  };

  BAA.getConfig = function () {
    return db().get(K.CONFIG).then(function (d) {
      var saved = d[K.CONFIG] || {};
      var out = merge(BAA.DEFAULT_CONFIG, saved);

      // --- migration: older single-platform configs ----------------------
      if (!isPlain(out.tasksByPlatform)) {
        out.tasksByPlatform = { boss: [], yupao: [] };
        if (Array.isArray(saved.tasks)) out.tasksByPlatform.boss = saved.tasks;
        if (Array.isArray(saved.yupaoTasks)) out.tasksByPlatform.yupao = saved.yupaoTasks;
      }
      if (!isPlain(out.overrides)) out.overrides = {};
      // Pull any legacy top-level platform fields into overrides.boss so they survive.
      if (saved.selectors || saved.login || saved.pageRules || saved.searchUrlTemplate) {
        out.overrides.boss = out.overrides.boss || {};
        ['searchUrlTemplate', 'selectors', 'login', 'pageRules', 'alreadyChattedTexts',
         'verificationKeywords', 'applyBehavior', 'cities', 'domain', 'loginUrl'].forEach(function (k) {
          if (saved[k] !== undefined && out.overrides.boss[k] === undefined) out.overrides.boss[k] = saved[k];
        });
      }
      if (!out.platform || !BAA.PLATFORM_DEFAULTS[out.platform]) out.platform = 'boss';

      // --- v3.0 migration: 平台无关配置沉到 overrides[platform] -------------
      // v2.x 的 filter / behavior / schedule / advancedRules 存在顶层，两个平台
      // 共用一份。这里把用户此刻看到的这份配置同时种进两个平台各自的槽（一次性，
      // 升级后行为不变），之后两边独立演进、互不覆盖。
      if (!saved.__v30) {
        out.overrides = out.overrides || {};
        BAA.PLATFORM_IDS.forEach(function (pid) {
          var slot = out.overrides[pid] = out.overrides[pid] || {};
          BAA.PLATFORM_SECTIONS.forEach(function (sec) {
            if (slot[sec] === undefined && out[sec] !== undefined) slot[sec] = clone(out[sec]);
          });
        });
        out.__v30 = true;
      }

      // --- v2.7 migration: 失效的登录地址 --------------------------------
      // BOSS 的 /web/geek/login 和鱼泡的 /login/ 都会被渲染成 404 页（鱼泡会
      // 5 秒后跳回首页），用户点「去登录」等于什么都没打开。旧版本把这些地址
      // 写进了 overrides，必须丢掉，否则代码里的新默认值永远赢不了。
      var BAD_LOGIN = { boss: 'zhipin.com/web/geek/login', yupao: 'yupao.com/login' };
      Object.keys(BAD_LOGIN).forEach(function (pid) {
        var ov = out.overrides[pid];
        if (isPlain(ov) && typeof ov.loginUrl === 'string' && ov.loginUrl.indexOf(BAD_LOGIN[pid]) >= 0) {
          delete ov.loginUrl;
        }
      });
      if (!saved.__v27) out.__v27 = true;

      resolvePlatform(out);

      // --- v2.4 migration (scheduler block) ------------------------------
      if (!saved.__v24) {
        if (!isPlain(out.schedule)) out.schedule = clone(BAA.DEFAULT_SCHEDULE);
        out.__v24 = true;
      }
      if (!saved.__v22) out.__v22 = true;
      if (!saved.__v23) out.__v23 = true;
      if (!saved.__v22 || !saved.__v23 || !saved.__v24 || !saved.__v27 || !saved.__v30) {
        var o = {}; o[K.CONFIG] = out; db().set(o);
      }
      return out;
    });
  };

  // Persist: platform-agnostic fields are stored at the top level; per-platform
// fields live in overrides[platform]. v2.6: the caller (options page) is
// responsible for writing overrides[platform], so this function must NOT reset
// it — resetting made every save copy the resolved defaults back into overrides,
// which is exactly what froze the two platforms' selector lists together.
  BAA.saveConfig = function (cfg) {
    var id = cfg.platform || 'boss';
    var saved = {};
    ['version', 'platform', 'filter', 'advancedRules', 'advancedMode', 'behavior',
     'schedule', 'overrides', 'tasksByPlatform', '__v22', '__v23', '__v24', '__v27', '__v30'].forEach(function (k) {
      if (cfg[k] !== undefined) saved[k] = clone(cfg[k]);
    });
    saved.platform = id;
    saved.overrides = clone(cfg.overrides || {});
    // v3.0: 当前平台的整套配置写回它自己的槽。切换平台时 options 页会先保存
    // 旧平台这份，再加载新平台那份，因此两边永不互相覆盖。
    saved.overrides[id] = saved.overrides[id] || {};
    BAA.PLATFORM_SECTIONS.forEach(function (sec) {
      if (cfg[sec] !== undefined) saved.overrides[id][sec] = clone(cfg[sec]);
    });
    saved.tasksByPlatform = clone(cfg.tasksByPlatform || {});
    saved.tasksByPlatform[id] = clone(cfg.tasks || []);
    saved.__v30 = true;
    var o = {}; o[K.CONFIG] = saved;
    return db().set(o);
  };

  BAA.getState = function () {
    return db().get(K.STATE).then(function (d) { return merge(BAA.DEFAULT_STATE, d[K.STATE] || {}); });
  };
  BAA.saveState = function (s) {
    s.updatedAt = Date.now();
    var o = {}; o[K.STATE] = s; return db().set(o);
  };
  BAA.getHistory = function () {
    return db().get(K.HISTORY).then(function (d) { return d[K.HISTORY] || {}; });
  };
  BAA.addHistory = function (key, record) {
    return BAA.getHistory().then(function (h) {
      h[key] = Object.assign({ ts: Date.now() }, record);
      var o = {}; o[K.HISTORY] = h; return db().set(o);
    });
  };
  BAA.cleanHistory = function (days) {
    if (!days || days <= 0) return Promise.resolve(0);
    var cutoff = Date.now() - days * 86400000;
    return BAA.getHistory().then(function (h) {
      var before = Object.keys(h).length;
      Object.keys(h).forEach(function (k) { if (h[k].ts < cutoff) delete h[k]; });
      var o = {}; o[K.HISTORY] = h;
      return db().set(o).then(function () { return before - Object.keys(h).length; });
    });
  };
  BAA.clearHistory = function () { var o = {}; o[K.HISTORY] = {}; return db().set(o); };

  /* ------------------------------------------------------------------ *
   * v2.9 - 公司级去重（本地记录）
   * 目标：同一家公司只打一次招呼。BOSS 一家公司会同时挂很多个岗位，job id
   * 各不相同，只按 job id 去重会反复骚扰同一个 HR。
   * 匹配用「归一化公司名」，只抹掉写法差异（全半角、空白、括号分部、法人后缀），
   * 不抹掉行业词（科技/网络/传媒…），否则「深圳A科技」和「深圳A网络」会被认成一家。
   * ------------------------------------------------------------------ */
  BAA.companyKey = function (name) {
    var s = String(name || '').toLowerCase();
    s = s.replace(/（/g, '(').replace(/）/g, ')');
    s = s.replace(/[【】\[\]]/g, '');
    s = s.replace(/\([^)]*\)/g, '');                 // 去掉「(深圳)」「(分公司)」这类分部后缀
    s = s.replace(/[\s\u3000\u00a0·.,，。、\-—_/\\|]+/g, '');
    s = s.replace(/(有限责任公司|股份有限公司|有限公司|分公司)$/g, '');
    return s;
  };

  // 在历史记录里按公司查重。days<=0 表示不限时间。返回命中的记录或 null。
  // 同一家公司可能有多条记录（不同岗位、不同时间），返回 ts 最新的那条，
  // 这样日志里「该公司已于 M-D HH:MM 打过招呼（当时岗位：…）」才是最近一次。
  // v3.0: 传 platform 时只在同一平台内比对 —— 在鱼泡打过的招呼不该挡住 BOSS。
  // （老记录没有 platform 字段，一律视为 boss，因为它们都是 BOSS 跑出来的。）
  BAA.findCompanyHistory = function (history, company, days, platform) {
    if (!history || !company) return null;
    var key = BAA.companyKey(company);
    if (!key) return null;
    var cutoff = Number(days) > 0 ? Date.now() - Number(days) * 86400000 : 0;
    var keys = Object.keys(history);
    var best = null;
    var bestTs = -1;
    for (var i = 0; i < keys.length; i++) {
      var r = history[keys[i]];
      if (!r || !r.company) continue;
      if (platform && (r.platform || 'boss') !== platform) continue;
      var ts = Number(r.ts || 0);
      if (cutoff && ts && ts < cutoff) continue;
      var k = r.companyKey || BAA.companyKey(r.company);
      if (!k || k !== key) continue;
      if (ts >= bestTs) { bestTs = ts; best = r; }
    }
    return best;
  };

  // 按公司聚合的打招呼清单（最近一次在前），供设置页展示。
  // v3.0: 传 platform 时只统计该平台的记录（老记录无 platform 视为 boss）。
  BAA.listCompanies = function (days, platform) {
    return BAA.getHistory().then(function (h) {
      var cutoff = Number(days) > 0 ? Date.now() - Number(days) * 86400000 : 0;
      var map = {};
      Object.keys(h).forEach(function (jid) {
        var r = h[jid];
        if (!r || !r.company) return;
        if (platform && (r.platform || 'boss') !== platform) return;
        var ts = Number(r.ts || 0);
        if (cutoff && ts && ts < cutoff) return;
        var ck = r.companyKey || BAA.companyKey(r.company);
        if (!ck) return;
        var e = map[ck];
        if (!e) {
          e = map[ck] = {
            key: ck, company: r.company, jobs: 0, greetingSent: 0,
            first: ts, last: ts, platforms: {}, jobTitles: []
          };
        }
        e.jobs++;
        if (r.greetingSent !== false) e.greetingSent++;
        if (ts) { e.first = Math.min(e.first || ts, ts); e.last = Math.max(e.last, ts); }
        if (r.platform) e.platforms[r.platform] = 1;
        if (r.title && e.jobTitles.length < 3) e.jobTitles.push(r.title);
      });
      return Object.keys(map).map(function (k) { return map[k]; })
        .sort(function (a, b) { return (b.last || 0) - (a.last || 0); });
    });
  };

  // 删除某家公司的全部本地记录（下次可以重新给它打招呼）。
  BAA.removeCompany = function (companyKey) {
    var key = String(companyKey || '');
    return BAA.getHistory().then(function (h) {
      var n = 0;
      Object.keys(h).forEach(function (jid) {
        var r = h[jid];
        if (!r) return;
        var k = r.companyKey || BAA.companyKey(r.company);
        if (k && k === key) { delete h[jid]; n++; }
      });
      var o = {}; o[K.HISTORY] = h;
      return db().set(o).then(function () { return n; });
    });
  };

  BAA.formatDay = function (ts) {
    if (!ts) return '-';
    var d = new Date(ts);
    return (d.getMonth() + 1) + '-' + d.getDate() + ' ' +
      String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  };

  BAA.getPending = function () {
    return db().get(K.PENDING).then(function (d) { return d[K.PENDING] || null; });
  };
  BAA.setPending = function (v) {
    var o = {}; o[K.PENDING] = v; return db().set(o);
  };

  BAA.getRun = function () {
    return db().get(K.RUN).then(function (d) { return d[K.RUN] || null; });
  };
  BAA.beat = function (owner, phase, role, url) {
    var o = {};
    o[K.RUN] = { owner: owner, ts: Date.now(), phase: phase || '', role: role || '', url: url || '' };
    return db().set(o);
  };
  BAA.releaseRun = function (owner) {
    return db().get(K.RUN).then(function (d) {
      if (!d[K.RUN] || d[K.RUN].owner !== owner) return;
      var o = {}; o[K.RUN] = { owner: '', ts: Date.now(), phase: 'idle', role: '', url: '' };
      return db().set(o);
    });
  };

  BAA.getLogs = function () {
    return db().get([K.LOGS, K.BGLOGS]).then(function (d) {
      var a = d[K.LOGS] || [], b = d[K.BGLOGS] || [];
      return a.concat(b).sort(function (x, y) { return (x.ts || 0) - (y.ts || 0); }).slice(-300);
    });
  };
  BAA.clearLogs = function () {
    var o = {}; o[K.LOGS] = []; o[K.BGLOGS] = []; return db().set(o);
  };

  BAA.log = function (level, msg) {
    var entry = { ts: Date.now(), level: level, msg: String(msg) };
    try {
      var p = chrome.runtime.sendMessage({ type: 'BAA_LOG', entry: entry });
      if (p && p.catch) p.catch(function () {});
    } catch (e) { /* no receiver */ }
    return db().get(K.LOGS).then(function (d) {
      var list = d[K.LOGS] || [];
      list.push(entry);
      if (list.length > 300) list = list.slice(-300);
      var o = {}; o[K.LOGS] = list; return db().set(o);
    });
  };

  BAA.today = function () {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };

  // v3.0: 今日已投数按「平台」从投递流水推导。
  // 为什么不用 state.todayCount：state 是两个平台共享的，而且会被 content script
  // 的心跳整份写回，切换平台时无论怎么存转都会被覆盖 —— 结果就是鱼泡继承了 BOSS
  // 的次数，一切过去就提示「已达到每日投递上限」。历史记录每条都带 platform + ts，
  // 才是单一数据源。（老记录没有 platform，视为 boss。）
  BAA.countTodayApplied = function (platform) {
    var pf = platform || 'boss';
    var today = BAA.today();
    return BAA.getHistory().then(function (h) {
      var n = 0;
      Object.keys(h).forEach(function (k) {
        var r = h[k];
        if (!r || !r.ts) return;
        if ((r.platform || 'boss') !== pf) return;
        var d = new Date(Number(r.ts));
        var day = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        if (day === today) n++;
      });
      return n;
    });
  };
  BAA.rand = function (min, max) {
    min = Number(min) || 0; max = Number(max) || min;
    if (max < min) { var t = min; min = max; max = t; }
    return Math.floor(min + Math.random() * (max - min + 1));
  };
  BAA.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, Math.max(0, ms)); }); };
  BAA.hash = function (str) {
    var h = 5381, i = (str || '').length;
    while (i) h = (h * 33) ^ (str || '').charCodeAt(--i);
    return 'h' + (h >>> 0).toString(36);
  };
  BAA.buildUrl = function (tpl, task, page) {
    return String(tpl || BAA.PLATFORM_DEFAULTS.boss.searchUrlTemplate)
      .replace(/\{query\}/g, encodeURIComponent(task.query || ''))
      .replace(/\{city\}/g, encodeURIComponent(task.city || (BAA.PLATFORM_DEFAULTS.boss.cities[0] || {}).code || 'a77'))
      .replace(/\{page\}/g, encodeURIComponent(String(page || 1)));
  };
  BAA.cityName = function (cfg, code) {
    var list = (cfg && cfg.cities) || BAA.CITY_OPTIONS_BOSS;
    var hit = list.filter(function (c) { return c.code === code; })[0];
    return hit ? hit.name : (code || '');
  };
  BAA.formatTime = function (ts) {
    if (!ts) return '-';
    var d = new Date(ts);
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ':' + String(d.getSeconds()).padStart(2, '0');
  };

  /* ------------------------------------------------------------------ *
   * v2.4 - Fixed time-window scheduler (pure functions, Node-testable)
   * ------------------------------------------------------------------ */
  BAA.WEEKDAY_NAMES = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  BAA.ALL_WEEKDAYS = [0, 1, 2, 3, 4, 5, 6];

  BAA.parseClock = function (v) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(String(v == null ? '' : v).trim());
    if (!m) return -1;
    var h = Number(m[1]), mi = Number(m[2]);
    if (h < 0 || h > 23 || mi < 0 || mi > 59) return -1;
    return h * 60 + mi;
  };

  BAA.scheduleWindows = function (sch) {
    return (sch && Array.isArray(sch.windows) ? sch.windows : []).map(function (w, i) {
      var s = BAA.parseClock(w && w.start), e = BAA.parseClock(w && w.end);
      return {
        index: i, start: s, end: e, enabled: !!(w && w.enabled !== false),
        label: String((w && w.start) || '') + '-' + String((w && w.end) || '')
      };
    }).filter(function (w) {
      return w.enabled && w.start >= 0 && w.end >= 0 && w.start !== w.end;
    });
  };

  BAA.scheduleWeekdays = function (sch) {
    var raw = (sch && Array.isArray(sch.weekdays)) ? sch.weekdays : BAA.ALL_WEEKDAYS;
    return raw.map(Number).filter(function (n) { return isFinite(n) && n >= 0 && n <= 6; })
      .filter(function (n, i, a) { return a.indexOf(n) === i; })
      .sort(function (a, b) { return a - b; });
  };

  BAA.scheduleStatus = function (sch, now) {
    var t = (now instanceof Date) ? now.getTime()
      : (typeof now === 'number' && isFinite(now) ? now : Date.now());
    var d = new Date(t);
    var out = {
      enabled: !!(sch && sch.enabled), active: false, reason: 'disabled',
      now: t, weekday: d.getDay(), windowIndex: -1, windowLabel: '',
      windowStart: 0, windowEnd: 0, nextStartAt: 0, nextChangeAt: 0,
      boundaryType: ''
    };
    if (!out.enabled) return out;
    var days = BAA.scheduleWeekdays(sch);
    var wins = BAA.scheduleWindows(sch);
    if (!days.length) { out.reason = 'no-weekdays'; return out; }
    if (!wins.length) { out.reason = 'no-windows'; return out; }

    var Y = d.getFullYear(), M = d.getMonth(), D = d.getDate();
    var events = [];
    for (var off = -2; off <= 9; off++) {
      var day = new Date(Y, M, D + off, 0, 0, 0, 0);
      if (days.indexOf(day.getDay()) === -1) continue;
      var base = day.getTime();
      for (var i = 0; i < wins.length; i++) {
        var w = wins[i];
        events.push({
          start: base + w.start * 60000,
          end: base + (w.end <= w.start ? w.end + 1440 : w.end) * 60000,
          index: w.index, label: w.label
        });
      }
    }
    events.sort(function (a, b) { return a.start - b.start; });
    function activeAt(ts) {
      for (var k = 0; k < events.length; k++) {
        if (ts >= events[k].start && ts < events[k].end) return events[k];
      }
      return null;
    }
    var hit = activeAt(t);
    if (hit) {
      out.active = true; out.reason = 'inside';
      out.windowIndex = hit.index; out.windowLabel = hit.label;
      out.windowStart = hit.start; out.windowEnd = hit.end;
    } else {
      out.reason = 'outside';
    }

    var bounds = [];
    events.forEach(function (ev) {
      bounds.push({ ts: ev.start, type: 'start' });
      bounds.push({ ts: ev.end, type: 'end' });
    });
    bounds = bounds.filter(function (b) { return b.ts > t; })
      .sort(function (a, b) { return a.ts - b.ts; });
    for (var j = 0; j < bounds.length; j++) {
      var willBe = !!activeAt(bounds[j].ts);
      if (willBe !== out.active) {
        out.nextChangeAt = bounds[j].ts;
        out.boundaryType = willBe ? 'start' : 'end';
        break;
      }
    }
    for (var m = 0; m < bounds.length; m++) {
      if (bounds[m].type === 'start') { out.nextStartAt = bounds[m].ts; break; }
    }
    return out;
  };

  BAA.scheduleSummary = function (sch) {
    if (!sch || !sch.enabled) return '定时执行：未启用';
    var wins = BAA.scheduleWindows(sch), days = BAA.scheduleWeekdays(sch);
    if (!wins.length || !days.length) return '定时执行：已开启，但缺少有效的执行日或时间段';
    var joined = days.join(','), text;
    if (days.length === 7) text = '每天';
    else if (joined === '1,2,3,4,5') text = '工作日';
    else if (joined === '0,6') text = '周末';
    else text = days.map(function (n) { return BAA.WEEKDAY_NAMES[n]; }).join('、');
    return '定时执行：' + text + ' ' + wins.map(function (w) { return w.label; }).join('、');
  };

  BAA.formatClock = function (ts) {
    if (!ts) return '-';
    var d = new Date(ts);
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  };
  BAA.formatDateTime = function (ts) {
    if (!ts) return '-';
    var d = new Date(ts), n = new Date();
    var same = d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth()
      && d.getDate() === n.getDate();
    var tomorrow = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1);
    var isTmr = d.getFullYear() === tomorrow.getFullYear() && d.getMonth() === tomorrow.getMonth()
      && d.getDate() === tomorrow.getDate();
    return (same ? '今天' : isTmr ? '明天' : (d.getMonth() + 1) + '月' + d.getDate() + '日') +
      ' ' + BAA.formatClock(ts);
  };

  BAA.DEFAULT_SCHEDULE_RUNTIME = {
    lastDecision: 'off',
    activeWindowStart: 0,
    lastAutoStart: 0,
    lastAutoPause: 0,
    pauseGuardUntil: 0,
    overrideUntil: 0,
    autoManaged: false,
    wasActive: false,
    message: '',
    updatedAt: 0
  };
  BAA.getScheduleRuntime = function () {
    return db().get(K.SCHEDULE).then(function (d) {
      return Object.assign({}, BAA.DEFAULT_SCHEDULE_RUNTIME, d[K.SCHEDULE] || {});
    });
  };
  BAA.saveScheduleRuntime = function (r) {
    r.updatedAt = Date.now();
    var o = {}; o[K.SCHEDULE] = r; return db().set(o);
  };
  BAA.setScheduleOverride = function (cfg) {
    return BAA.getScheduleRuntime().then(function (rt) {
      var st = BAA.scheduleStatus(cfg && cfg.schedule, Date.now());
      rt.overrideUntil = st.active ? st.windowEnd : 0;
      rt.autoManaged = false;
      rt.message = st.active
        ? '本次时段已手动停止，' + BAA.formatClock(st.windowEnd) + ' 后按新时段自动恢复'
        : '定时开启中，等待下一个执行时段';
      return BAA.saveScheduleRuntime(rt).then(function () { return rt; });
    });
  };
  BAA.clearScheduleOverride = function () {
    return BAA.getScheduleRuntime().then(function (rt) {
      rt.overrideUntil = 0;
      rt.message = '手动覆盖已清除';
      return BAA.saveScheduleRuntime(rt).then(function () { return rt; });
    });
  };
  BAA.getAutoStart = function () {
    return db().get(K.AUTOSTART).then(function (d) { return d[K.AUTOSTART] || null; });
  };
  BAA.setAutoStart = function (v) {
    var o = {}; o[K.AUTOSTART] = v; return db().set(o);
  };
  BAA.takeAutoStart = function () {
    return db().get(K.AUTOSTART).then(function (d) {
      var v = d[K.AUTOSTART] || null;
      if (!v || !v.pending) return null;
      var o = {}; o[K.AUTOSTART] = null;
      return db().set(o).then(function () { return v; });
    });
  };

  BAA.STATUS_TEXT = {
    idle: '未开始', running: '运行中', paused: '已暂停', stopped: '已完成',
    blocked: '已拦截', 'need-login': '等待登录'
  };
})(typeof window !== 'undefined' ? window : globalThis);
