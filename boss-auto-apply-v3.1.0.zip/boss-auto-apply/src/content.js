(function () {
  'use strict';

  var BAA = window.BAA;
  if (!BAA || !BAA.dom || !BAA.checkLogin || window.__BAA_CONTENT_READY__) return;
  window.__BAA_CONTENT_READY__ = true;

  var D = BAA.dom;
  var q = D.q, qa = D.qa, txt = D.txt, visible = D.visible;

  var state = null;
  var cfg = null;
  var running = false;
  var starting = false;
  // v2.8: tally of *why* jobs were skipped during this run. Without it a run
  // that scans 15 cards and applies 0 just says "全部搜索任务已完成", which looks
  // exactly like "the automation is broken / doesn't auto-apply".
  var skipTally = {};
  var badgeHost = null;
  var loginWatcher = null;
  var landingInProgress = false;
  var lastHandledTs = 0;
  var MY_TAB_ID = null;
  // v2.3: unique id for this content-script instance. Survives bfcache restore,
  // changes on a fresh document load. Used as a cross-context run mutex.
  var OWNER = 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  var phase = 'idle';
  var lastGuardLog = 0;
  var guardStarted = false;

  function beat(p) {
    phase = p || phase;
    try { BAA.beat(OWNER, phase, pageRole(), location.href); } catch (e) { /* storage gone */ }
  }

  // Per-tab identity survives a same-tab SPA navigation; a window.open() tab
  // gets a different id, which tells us whether the chat page is a NEW tab.
  try {
    var p = chrome.runtime.sendMessage({ type: 'BAA_WHOAMI' });
    if (p && p.then) p.then(function (r) { if (r && r.ok) MY_TAB_ID = r.tabId; }).catch(function () {});
  } catch (e) { /* ignore */ }

  function BlockedError(reason) { this.name = 'BlockedError'; this.reason = reason; this.message = reason; }
  function list(x) { return Array.isArray(x) ? x : (x ? [x] : []); }
  function num(v, d) { var n = Number(v); return isFinite(n) && n > 0 ? n : d; }
  // Platform display name (e.g. "BOSS直聘" / "鱼泡直聘") used in user-facing messages.
  function PN() { return (cfg && cfg.platformName) || '平台'; }

  /* ------------------------------------------------------------------ *
   * v3.1 平台落地守卫
   *
   * 这是「切了平台就卡死」的直接成因：配置切到鱼泡后，浏览器还停在 BOSS
   * 搜索页，这个页面的内容脚本仍在跑，于是拿鱼泡的规则去操作 BOSS 的页面，
   * 翻页时被域名校验拦住 → 日志停在「拒绝导航到非当前平台域名」，看起来像死机。
   *
   * 现在每个页面先确认自己属于哪个平台（只看域名，稳定且不可伪造），
   * 与配置不一致就拒绝启动，由面板负责把浏览器带到正确的平台页面。
   * ------------------------------------------------------------------ */
  function myPlatformId() { return BAA.detectPlatformByHost(location.hostname); }
  function platformMismatch(c) {
    var mine = myPlatformId();
    if (!mine) return null;                       // 非目标平台页面（about: 等）
    var want = c && c.platform;
    if (!want || want === mine) return null;
    return { mine: mine, want: want };
  }
  function platformMismatchMsg(m) {
    return '当前页面是「' + BAA.platformName(m.mine) + '」，但插件选的是「' +
      BAA.platformName(m.want) + '」。已阻止在本页启动，以免用错规则。' +
      '点面板上的「去登录 / 打开平台」会自动跳到' + BAA.platformName(m.want) + '。';
  }

  /* ------------------------------------------------------------------ *
   * Page roles. This is the fix for the "freeze on the chat page":
   * the old build re-started the job state machine inside /web/geek/chat,
   * where it waited 15s for job cards that never appear, then wrote a
   * global `blocked` state. Now only the search page may run jobs.
   * ------------------------------------------------------------------ */
  function pathPart() { return location.pathname + location.search; }
  function isSearchPage() {
    var p = cfg && cfg.pageRules && cfg.pageRules.searchUrlPattern;
    return p ? pathPart().indexOf(p) >= 0 : /\/web\/geek\/jobs?(?:\?|\/|$)/.test(pathPart());
  }
  function isChatPage() {
    var p = cfg && cfg.pageRules && cfg.pageRules.chatUrlPattern;
    return p ? pathPart().indexOf(p) >= 0 : /\/web\/geek\/chat(?:\?|\/|$)/.test(location.pathname);
  }
  function isDetailPage() {
    var p = cfg && cfg.pageRules && cfg.pageRules.detailUrlPattern;
    return !!(p && pathPart().indexOf(p) >= 0);
  }
  function pageRole() {
    if (isChatPage()) return 'chat';
    if (isDetailPage()) return 'detail';
    if (isSearchPage()) return 'search';
    return 'other';
  }

  // Absolute ceiling for any await chain. A timed-out action is recorded as a
  // failure and the state machine moves on instead of hanging forever.
  function withTimeout(promise, ms, label) {
    return new Promise(function (resolve, reject) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        resolve({ result: 'timeout', note: label + ' 超时（' + ms + 'ms），已强制跳过避免卡死' });
      }, Math.max(1000, ms));
      Promise.resolve(promise).then(function (v) {
        if (done) return; done = true; clearTimeout(timer); resolve(v);
      }, function (e) {
        if (done) return; done = true; clearTimeout(timer); reject(e);
      });
    });
  }

  function findByText(scope, words) {
    var ws = list(words);
    var found = [];
    ['button', 'a', '[role="button"]', '[class*="btn"]', 'span', 'div'].some(function (sel) {
      var hit = Array.prototype.slice.call(scope.querySelectorAll(sel)).filter(function (el) {
        if (!visible(el)) return false;
        var t = txt(el);
        if (!t || t.length > 30) return false;
        return ws.some(function (w) { return t === w || t.indexOf(w) >= 0; });
      });
      if (hit.length) { found = hit.sort(function (a, b) { return txt(a).length - txt(b).length; }); return true; }
      return false;
    });
    return found[0] || null;
  }

  function findCards() { return BAA.findCards(cfg); }
  function firstCardKey() {
    var cards = findCards();
    if (!cards.length) return '';
    if (cfg && cfg.platform === 'yupao') {
      return cards[0].getAttribute('href') || txt(cards[0]).slice(0, 80);
    }
    var a = cards[0].querySelector('a[href*="job_detail"]');
    return a ? a.getAttribute('href') : txt(cards[0]).slice(0, 80);
  }

  /* ------------------------------------------------------------------ *
   * Login gate: self-check before every start, wait for manual login.
   * Only cookie names/expiry are persisted, never cookie values.
   * ------------------------------------------------------------------ */
  function startLoginWatcher() {
    if (loginWatcher) return;
    var deadline = Date.now() + num(cfg.behavior.loginWaitSec, 300) * 1000;
    var every = Math.max(2000, num(cfg.behavior.loginPollSec, 3) * 1000);
    loginWatcher = setInterval(async function () {
      try {
        var s = await BAA.getState();
        if (s.status !== 'need-login') { clearInterval(loginWatcher); loginWatcher = null; return; }
        if (Date.now() > deadline) {
          clearInterval(loginWatcher); loginWatcher = null;
          s.summary = '等待登录超时。请登录' + (cfg.platformName || '平台') + '后点「继续」，或重新点「开始」。';
          await BAA.saveState(s);
          BAA.log('warn', s.summary);
          return;
        }
        var r = await BAA.checkLogin(cfg);
        s.loginStatus = r.status;
        s.loginReason = r.reason;
        s.lastLoginCheck = Date.now();
        if (r.status === 'ok') {
          clearInterval(loginWatcher); loginWatcher = null;
          s.status = 'running';
          s.summary = '';
          await BAA.saveState(s);
          BAA.log('ok', '检测到登录成功，自动按规则继续执行');
          state = s; cfg = await BAA.getConfig();
          if (pageRole() === 'search') {
            run();
          } else {
            // v2.6: the login page is usually not the search page. Navigate to
            // the first task's search URL in THIS tab instead of asking the user
            // to go back manually; the new document picks the run up in boot().
            var t = s.queue[s.queueIndex] || s.queue[0];
            if (t) {
              s.status = 'running';
              s.summary = '';
              await BAA.saveState(s);
              BAA.log('info', '登录成功，正在打开搜索结果页继续执行');
              await navigateTo(BAA.buildUrl(cfg.searchUrlTemplate, t, s.page || 1));
            } else {
              s.summary = '已登录。请回到 ' + PN() + '搜索结果页，然后点「继续」。';
              s.status = 'paused';
              await BAA.saveState(s);
            }
          }
        } else {
          await BAA.saveState(s);
        }
      } catch (e) { /* tab closing */ }
    }, every);
  }

  async function loginGate(c) {
    var r = await BAA.checkLogin(c);
    state.loginStatus = r.status;
    state.loginReason = r.reason;
    state.lastLoginCheck = Date.now();
    BAA.log('info', '登录态自检：' + r.status + '（' + r.reason + '）');
    if (r.status === 'ok') return true;
    state.status = 'need-login';
    state.summary = '尚未登录 ' + PN() + '：' + r.reason +
      '。请在弹出的登录页完成登录，插件会自动检测并继续执行。';
    await BAA.saveState(state);
    ensureBadge();
    // v2.6: take the user straight to the platform's login page. This works no
    // matter which page we are on and no longer depends on the current tab
    // being a search page.
    try {
      await chrome.runtime.sendMessage({ type: 'BAA_OPEN_LOGIN', platform: c.platform });
      BAA.log('info', '已自动打开 ' + PN() + '登录页，登录完成后会自动继续');
    } catch (e) { /* ignore */ }
    if (c.behavior.autoWaitForLogin) startLoginWatcher();
    return false;
  }

  /* ------------------------------------------------------------------ *
   * Safety: detect verification / login walls. Never bypass them.
   * Strict body-text checks are search-page only: the chat page legitimately
   * contains words like "异常" inside conversation text and must not trigger.
   * ------------------------------------------------------------------ */
  function detectBlock() {
    var role = pageRole();
    var sel = D.hit(cfg.selectors.verification);
    if (sel) {
      var els = document.querySelectorAll(sel);
      for (var i = 0; i < els.length; i++) if (visible(els[i])) return '页面出现验证组件（' + sel + '）';
    }
    if (/verify|captcha|security-check/i.test(location.href)) return '当前页面为验证页';

    var dialogs = qa(document, cfg.selectors.dialog);
    for (var j = 0; j < dialogs.length; j++) {
      if (!visible(dialogs[j])) continue;
      var t = txt(dialogs[j]);
      if (t.length > 400) continue;
      for (var k = 0; k < cfg.verificationKeywords.length; k++) {
        if (t.indexOf(cfg.verificationKeywords[k]) >= 0) return '弹窗提示：' + cfg.verificationKeywords[k];
      }
    }
    if (role === 'search') {
      var strict = txt(document.body).slice(0, 400)
        .match(/请完成安全验证|滑动验证|操作过于频繁|访问受限|异常操作|登录已失效|请进行身份验证/);
      if (strict) return '页面提示：' + strict[0];
    }
    return '';
  }

  /* ------------------------------------------------------------------ *
   * Floating badge (isolated shadow DOM)
   * ------------------------------------------------------------------ */
  function ensureBadge() {
    if (!cfg || !cfg.behavior.showFloatingBadge) { if (badgeHost) badgeHost.style.display = 'none'; return; }
    if (!badgeHost) {
      badgeHost = document.createElement('div');
      badgeHost.id = '__baa_badge_host__';
      badgeHost.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483000;';
      document.body.appendChild(badgeHost);
      var sr = badgeHost.attachShadow({ mode: 'open' });
      sr.innerHTML = '<style>' +
        '.b{font:13px/1.5 -apple-system,"Microsoft YaHei",sans-serif;background:#1f2430;color:#e8ecf4;' +
        'border:1px solid #3a4459;border-radius:12px;padding:10px 12px;min-width:220px;box-shadow:0 6px 24px rgba(0,0,0,.35)}' +
        '.r1{display:flex;align-items:center;gap:8px;margin-bottom:6px}' +
        '.dot{width:8px;height:8px;border-radius:50%;background:#8a93a6;flex:none}' +
        '.dot.on{background:#3ecf8e}.dot.warn{background:#f0b429}.dot.err{background:#ef6b6b}' +
        '.tt{font-weight:600;flex:1}' +
        '.r2{color:#aab4c5;font-size:12px;margin-bottom:8px}' +
        '.btns{display:flex;gap:6px}' +
        'button{font:inherit;font-size:12px;background:#2b3446;color:#dfe7f5;border:1px solid #3d4961;' +
        'border-radius:6px;padding:4px 10px;cursor:pointer}button:hover{background:#35415a}' +
        '</style><div class="b"><div class="r1"><span class="dot" id="d"></span>' +
        '<span class="tt" id="tt">智能投递助手</span></div><div class="r2" id="s">未开始</div>' +
        '<div class="btns"><button id="p">暂停</button><button id="x">停止</button>' +
        '<button id="o">面板</button></div></div>';
      sr.getElementById('p').onclick = function () { command({ type: state && state.status === 'paused' ? 'RESUME' : 'PAUSE' }); };
      sr.getElementById('x').onclick = function () { command({ type: 'STOP' }); };
      sr.getElementById('o').onclick = function () {
        try { var p = chrome.runtime.sendMessage({ type: 'BAA_OPEN_PANEL_HINT' }); if (p && p.catch) p.catch(function () {}); } catch (e) { /* ignore */ }
      };
    }
    badgeHost.style.display = '';
    var sr = badgeHost.shadowRoot;
    sr.getElementById('d').className = 'dot' + (state && state.status === 'running' ? ' on'
      : state && (state.status === 'paused' || state.status === 'need-login') ? ' warn'
      : state && state.status === 'blocked' ? ' err' : '');
    if (state) {
      var roleText = pageRole() === 'chat' ? ' · 沟通页（不执行任务）'
        : pageRole() === 'other' ? ' · 非搜索页（不执行任务）' : '';
      sr.getElementById('s').textContent = state.status === 'need-login'
        ? '等待登录 ' + PN()
        : (BAA.STATUS_TEXT[state.status] || state.status) + ' · 今日 ' + state.todayCount + '/' +
          (cfg.behavior.dailyLimit || 0) + ' · 已投 ' + state.stats.applied + roleText;
    }
  }

  /* ------------------------------------------------------------------ *
   * Greeting + input helpers
   * ------------------------------------------------------------------ */
  function renderGreeting(job) {
    var map = {
      '岗位': job.title, 'job': job.title, '公司': job.company, 'company': job.company,
      '城市': job.city, 'city': job.city, '薪资': job.salaryText, 'salary': job.salaryText
    };
    return String(cfg.behavior.greetingTemplate || '').replace(/\{([\w\u4e00-\u9fa5]+)\}/g, function (m, k) {
      return map[k] !== undefined ? map[k] : m;
    });
  }

  function setInputValue(el, value) {
    if (!el) return false;
    if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
      // Verified on the live BOSS chat page: execCommand('insertText') produces the
      // native beforeinput/input sequence that Vue's v-model observes, which flips
      // button.btn-send from "disabled" to enabled. innerText alone is NOT enough.
      el.focus();
      var ok = false;
      try {
        document.execCommand('selectAll', false, null);
        ok = document.execCommand('insertText', false, value);
      } catch (e) { ok = false; }
      if (!ok || !String(el.innerText || '').trim()) el.innerText = value;
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true, inputType: 'insertText', data: value
      }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.focus();
    return true;
  }

  function isGreetingInput(el) {
    if (el.isContentEditable || el.tagName === 'TEXTAREA') return true;
    var hint = (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + String(el.className || '');
    return /招呼|问候|说点|输入|message|greet|content/i.test(hint);
  }

  /* ------------------------------------------------------------------ *
   * Verified BOSS search flow:
   *   event-level click on list card -> detail panel switches
   *   -> a.op-btn-chat inside .job-detail-box -> click
   * BOSS then EITHER opens a greeting dialog, OR navigates to /web/geek/chat.
   * ------------------------------------------------------------------ */
  async function ensurePageReady() {
    var deadline = Date.now() + num(cfg.behavior.pageReadyTimeoutMs, 15000);
    // yupao (detail-type) has no chat button on the listing page; the card link
    // itself is the entry and the chat button lives on the opened detail page.
    var needChat = !(cfg.applyBehavior && cfg.applyBehavior.type === 'detail');
    while (Date.now() < deadline) {
      if (pageRole() !== 'search') return false;
      beat('wait-page-ready');
      if (findCards().length && (!needChat || BAA.findChatButton(cfg))) return true;
      await BAA.sleep(300);
    }
    BAA.log('warn', '等待页面就绪超时：岗位列表' + (needChat ? '或「立即沟通」按钮' : '') + '始终未出现');
    return false;
  }

  async function waitForDetail(job, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (pageRole() !== 'search') return { ok: false, chat: null, matched: false };
      var chat = BAA.findChatButton(cfg);
      if (chat && BAA.chatMatchesJob(chat, job)) return { ok: true, chat: chat, matched: true };
      await BAA.sleep(120);
    }
    var fallback = BAA.findChatButton(cfg);
    return { ok: !!fallback, chat: fallback, matched: false };
  }

  async function observeAfterClick(job, b) {
    var windowMs = Math.min(5000, Math.max(1200, num(b.chatWaitMs, 2500)));
    var deadline = Date.now() + windowMs;
    while (Date.now() < deadline) {
      beat('observe-after-click');
      // Navigation to /web/geek/chat kills this JS context on a full page load.
      // The landing page (or the SPA role watcher) owns greeting + accounting.
      if (pageRole() === 'chat') return { result: 'handoff', note: '已进入沟通页，交给落地流程发送招呼语' };
      var block = detectBlock();
      if (block) throw new BlockedError(block);

      if (/登录账号，查看更多好职位|请先登录|登录后即可沟通|扫码登录/.test(txt(document.body).slice(0, 900))) {
        return { result: 'need-login', note: '当前浏览器未登录 ' + PN() + '，请先登录后重试' };
      }

      // Some BOSS variants show a "打招呼" dialog right on the search page.
      // Fill the custom greeting there so it replaces the platform default.
      var inputs = qa(document, cfg.selectors.dialogInput).filter(function (e) {
        return visible(e) && isGreetingInput(e) && String(e.className || '') !== 'boss-search-input';
      });
      if (inputs.length) {
        var input = inputs[0];
        if (b.greetingEnabled && b.autoSend) {
          setInputValue(input, renderGreeting(job));
          await BAA.sleep(BAA.rand(300, 600));
          var send = qa(document, cfg.selectors.dialogSend).filter(visible)[0]
            || findByText(document, ['发送招呼语', '发送', '确定', '确认']);
          if (send) {
            send.click();
            await BAA.sleep(BAA.rand(500, 900));
            var b2 = detectBlock();
            if (b2) throw new BlockedError(b2);
            await BAA.setPending(null);
            return { result: 'applied', note: '已在打招呼弹窗发送自定义招呼语' };
          }
        }
        return { result: 'applied', note: '已弹出招呼语输入框' + (b.autoSend ? '' : '（未自动发送）') };
      }

      // A new chat tab may have already consumed the hand-off record.
      if (!(await BAA.getPending())) return { result: 'handoff', note: '沟通页已接管' };

      var nowChat = BAA.findChatButton(cfg);
      if (nowChat && /继续沟通|已沟通/.test(txt(nowChat))) {
        return { result: 'applied', note: '按钮已变为「继续沟通」，沟通建立成功' };
      }
      await BAA.sleep(180);
    }
    // No dialog and no navigation in this window: keep the pending record so a
    // late landing can still send the greeting, but stop this loop immediately.
    return { result: 'handoff', note: '已点击「立即沟通」，等待沟通页落地' };
  }

  // Dispatcher: BOSS uses the "click in search -> chat page" flow; yupao uses
  // the "click card -> opens detail tab -> 聊一聊 in-page IM -> close tab" flow.
  async function applyOne(card, job) {
    var b = cfg.behavior;
    if (b.dryRun) return { result: 'applied', note: '模拟运行，未真正点击' };
    if (cfg.applyBehavior && cfg.applyBehavior.type === 'detail') return await applyYupao(card, job);
    return await applyBoss(card, job);
  }

  // BOSS flow (chat-type): click the card to open the job detail panel, then the
  // "立即沟通" button; BOSS navigates to /web/geek/chat where the greeting +
  // accounting happen (handleChatLanding).
  async function applyBoss(card, job) {
    var b = cfg.behavior;

    var detail = { ok: true, chat: null, matched: true };
    if (b.openDetailBeforeChat) {
      card.click();
      detail = await waitForDetail(job, Math.max(3000, num(b.detailWaitMs, 1000) * 5));
      if (!detail.ok) return { result: 'no-button', note: '切换详情后仍找不到「立即沟通」按钮' };
      if (!detail.matched && b.strictDetailMatch) {
        return { result: 'detail-mismatch', note: '详情面板与当前岗位不匹配，为防误投已跳过' };
      }
    }

    var btn = detail.chat || BAA.findChatButton(cfg) || findByText(document, ['立即沟通', '马上沟通', '投简历']);
    if (!btn) return { result: 'no-button', note: '未找到「立即沟通」按钮（请点「识别当前页」校准）' };

    var btnText = txt(btn);
    if ((cfg.alreadyChattedTexts || []).some(function (w) { return btnText.indexOf(w) >= 0; })) {
      return { result: 'already', note: '此前已沟通（' + btnText + '）' };
    }

    var before = detectBlock();
    if (before) throw new BlockedError(before);

    // Hand-off record for the chat landing page. Written BEFORE the click so it
    // survives a navigation / new tab.
    await BAA.setPending({
      ts: Date.now(),
      tabId: MY_TAB_ID,
      job: {
        id: job.id, title: job.title, company: job.company, city: job.city,
        salaryText: job.salaryText, link: job.link
      },
      searchUrl: location.href,
      greeting: b.greetingEnabled ? renderGreeting(job) : ''
    });

    btn.click();
    return await observeAfterClick(job, b);
  }

  // yupao flow (detail-type): the listing card is itself the job link
  // (target=_blank). Clicking it opens a NEW tab with the detail page, where the
  // "聊一聊" button opens an in-page IM widget. The new tab owns greeting +
  // accounting (handleDetailLanding), then closes itself. The search tab waits
  // for the pending record to be consumed before moving on (one open tab at a
  // time, no tab explosion).
  async function applyYupao(card, job) {
    var b = cfg.behavior;

    var cardText = txt(card);
    if ((cfg.alreadyChattedTexts || []).some(function (w) { return cardText.indexOf(w) >= 0; })) {
      return { result: 'already', note: '此前已沟通（' + cardText.slice(0, 20) + '）' };
    }

    var before = detectBlock();
    if (before) throw new BlockedError(before);

    await BAA.setPending({
      ts: Date.now(),
      tabId: MY_TAB_ID,
      job: {
        id: job.id, title: job.title, company: job.company, city: job.city,
        salaryText: job.salaryText, link: job.link
      },
      searchUrl: location.href,
      greeting: b.greetingEnabled ? renderGreeting(job) : ''
    });

    // Open the detail page in a new tab (card is an <a target=_blank>).
    var link = card.getAttribute('href') || (card.href || '');
    var abs = link.indexOf('http') === 0 ? link : ('https://www.yupao.com' + link);
    var opened = false;
    try {
      var w = window.open(abs, '_blank');
      opened = !!w;
    } catch (e) { opened = false; }
    if (!opened) {
      try { card.click(); opened = true; } catch (e) { opened = false; }
    }
    if (!opened) {
      await BAA.setPending(null);
      return { result: 'failed', note: '无法打开详情页（可能被浏览器拦截）' };
    }

    // Wait for the detail tab to consume the pending record (or time out).
    var deadline = Date.now() + num(b.actionTimeoutMs, 20000);
    while (Date.now() < deadline) {
      if (!(await BAA.getPending())) return { result: 'handoff', note: '已打开详情页，交由详情页处理' };
      await BAA.sleep(400);
    }
    return { result: 'handoff', note: '已打开详情页（等待详情页处理超时，继续下一个）' };
  }

  /* ------------------------------------------------------------------ *
   * Chat page landing: /web/geek/chat
   * Real logged-in DOM verified 2026-11-04:
   *   composer  = div#chat-input.chat-input[contenteditable=true]
   *   send      = button.btn-send  (has class "disabled" while empty)
   *   session   = li:has(.friend-content-warp)  (Vue handler sits on the <li>)
   *   head      = .chat-conversation (HR / company / job title)
   * BOSS auto-selects the just-created conversation on landing.
   * We NEVER start the job state machine here.
   * ------------------------------------------------------------------ */
  function findComposerInFrames() {
    var found = null;
    try {
      var frames = document.querySelectorAll('iframe');
      for (var i = 0; i < frames.length && !found; i++) {
        try {
          var doc = frames[i].contentDocument;
          if (!doc) continue;
          var el = q(doc, cfg.selectors.chatComposer);
          if (el && visible(el)) found = el;
        } catch (e) { /* cross-origin */ }
      }
    } catch (e) { /* ignore */ }
    return found;
  }

  function findChatComposer() {
    return qa(document, cfg.selectors.chatComposer).filter(function (e) {
      return visible(e) && String(e.className || '') !== 'boss-search-input';
    })[0] || findComposerInFrames();
  }

  function findChatSendButton() {
    var cand = qa(document, cfg.selectors.chatSend).filter(visible);
    // Two different "send" buttons can exist at once on yupao: the chat message
    // send (button.btn-send, in the IM panel) AND a modal's "发送简历" confirm
    // button. Prefer a send button that is NOT inside a dialog/modal, because
    // clicking the modal's button would send a resume (or do nothing) instead of
    // the greeting. Live-verified 2026-11-05.
    var outside = cand.filter(function (b) {
      return !b.closest || !b.closest('[role="dialog"],.ant-modal,[class*="modal"]');
    });
    return (outside[0] || cand[0]) || null;
  }

  // Generic realistic (mousedown/mouseup/click) click at the element's centre.
  // yupao's React handlers sometimes ignore a bare el.click(), but respond to a
  // real pointer sequence. Used for the 免费聊 button on the detail page.
  function clickRealistic(el) {
    try {
      var r = el.getBoundingClientRect();
      var opt = {
        bubbles: true, cancelable: true, view: window,
        clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0
      };
      el.dispatchEvent(new MouseEvent('mousedown', Object.assign({}, opt, { buttons: 1 })));
      el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, opt, { buttons: 0 })));
      el.dispatchEvent(new MouseEvent('click', Object.assign({}, opt, { buttons: 0 })));
      return true;
    } catch (e) { return false; }
  }

  function sendButtonReady(btn) {
    if (!btn) return false;
    if (btn.disabled) return false;
    return !/disabled|\bunable\b/i.test(String(btn.className || ''));
  }

  function conversationHead() {
    var el = q(document, cfg.selectors.chatConversationHead);
    return el ? txt(el).slice(0, 320) : '';
  }

  function fragmentMatch(text, value, size) {
    var clean = function (s) { return String(s || '').replace(/[\s（）()【】\[\]·、,，\/\\—\-:：]/g, ''); };
    var t = clean(text), v = clean(value);
    if (!t || !v) return false;
    if (t.indexOf(v) >= 0) return true;
    var n = size || 3;
    for (var i = 0; i + n <= v.length; i++) {
      if (t.indexOf(v.slice(i, i + n)) >= 0) return true;
    }
    return false;
  }

  function recipientMatches(pending) {
    var head = conversationHead();
    if (!head || /都会在左侧列表中显示/.test(head)) return { ok: false, head: head, why: '尚未打开任何会话' };
    var job = pending.job || {};
    var ok = fragmentMatch(head, job.company) || fragmentMatch(head, job.title);
    return { ok: ok, head: head, why: ok ? '会话头匹配目标岗位' : '会话头与目标岗位不匹配' };
  }

  // Verified on the live page: BOSS's Vue handler for switching conversations
  // is NOT on the <li> and does not respond to a bare el.click(). It needs a
  // full mousedown/mouseup/click sequence dispatched on the inner
  // .friend-content node (that is where a real pointer lands).
  function fireRealisticClick(el) {
    var target = el;
    try {
      var inner = el.querySelector && el.querySelector('.friend-content');
      if (inner && visible(inner)) target = inner;
      var r = target.getBoundingClientRect();
      var opt = {
        bubbles: true, cancelable: true, view: window,
        clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0
      };
      target.dispatchEvent(new MouseEvent('mousedown', Object.assign({}, opt, { buttons: 1 })));
      target.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, opt, { buttons: 0 })));
      target.dispatchEvent(new MouseEvent('click', Object.assign({}, opt, { buttons: 0 })));
      return true;
    } catch (e) { return false; }
  }

  function trySelectTargetSession(pending) {
    var job = pending.job || {};
    var items = qa(document, cfg.selectors.chatSessionItem);
    var keys = [job.company, job.title].filter(Boolean);
    for (var i = 0; i < items.length; i++) {
      var t = txt(items[i]);
      if (!t) continue;
      for (var k = 0; k < keys.length; k++) {
        var frag = String(keys[k]).replace(/[（(].*$/, '').slice(0, 4);
        if (frag && t.indexOf(frag) >= 0) {
          if (fireRealisticClick(items[i])) return t.slice(0, 60);
        }
      }
    }
    return '';
  }

  async function waitForChatComposer(pending, timeoutMs) {
    var start = Date.now();
    var tries = 0;
    var nextTryAt = 1200;
    while (Date.now() - start < timeoutMs) {
      if (pageRole() !== 'chat') return { el: null, why: '已离开沟通页' };
      var el = findChatComposer();
      if (el) return { el: el, why: '聊天输入框已就绪' };
      var elapsed = Date.now() - start;
      if (tries < 3 && elapsed >= nextTryAt) {
        tries++;
        nextTryAt = elapsed + 2200;
        var hit = trySelectTargetSession(pending);
        BAA.log('info', hit ? '已切换到目标会话：' + hit : '会话列表未找到目标公司，继续等待 BOSS 自动选中');
      }
      await BAA.sleep(250);
    }
    return { el: null, why: '等待聊天输入框超时（' + timeoutMs + 'ms）' };
  }

  async function sendChatGreeting(pending) {
    var b = cfg.behavior;
    if (!b.chatGreetingEnabled) return { ok: false, why: '设置中关闭了「沟通页发送招呼语」' };
    if (!pending.greeting) return { ok: false, why: '招呼语为空（请检查设置里的招呼语模板）' };

    var ready = await waitForChatComposer(pending, num(b.chatComposerWaitMs, 9000));
    if (!ready.el) {
      BAA.log('warn', '招呼语未发送：' + ready.why);
      return { ok: false, why: ready.why };
    }

    if (b.chatVerifyRecipient) {
      var r = recipientMatches(pending);
      BAA.log('info', '会话校验：' + r.why + '｜' + r.head.slice(0, 70));
      if (!r.ok && b.chatStrictRecipient) {
        return { ok: false, why: '收件人校验未通过，严格模式下已跳过发送' };
      }
      if (!r.ok) BAA.log('warn', '收件人未匹配但按设置继续发送；如需阻止请开启「严格校验收件人」');
    }

    setInputValue(ready.el, pending.greeting);
    await BAA.sleep(200);

    var send = findChatSendButton();
    var deadline = Date.now() + num(b.chatSendWaitMs, 3000);
    while (Date.now() < deadline && !sendButtonReady(send)) {
      await BAA.sleep(150);
      send = findChatSendButton();
    }

    if (sendButtonReady(send)) {
      send.click();
      await BAA.sleep(500);
      BAA.log('ok', '已发送自定义招呼语 → ' + (pending.job.company || '') + ' / ' + (pending.job.title || ''));
      return { ok: true, why: '点击发送按钮' };
    }

    if (b.chatSendKeyFallback) {
      try {
        ready.el.focus();
        ['keydown', 'keypress', 'keyup'].forEach(function (type) {
          ready.el.dispatchEvent(new KeyboardEvent(type, {
            bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
          }));
        });
        await BAA.sleep(500);
        BAA.log('ok', '已用 Enter 兜底发送自定义招呼语');
        return { ok: true, why: 'Enter 兜底' };
      } catch (e) { /* ignore */ }
    }
    BAA.log('warn', '招呼语已填入但未能发送：发送按钮始终不可用');
    return { ok: false, why: '发送按钮不可用' };
  }

  async function handleChatLanding() {
    if (landingInProgress) return;
    var pending = await BAA.getPending();
    if (!pending || !pending.job) return;
    if (pending.ts === lastHandledTs) return;
    if (Date.now() - pending.ts > num(cfg.behavior.chatLandingTimeoutMs, 12000) * 10) {
      await BAA.setPending(null);
      return;
    }
    landingInProgress = true;
    lastHandledTs = pending.ts;
    await BAA.setPending(null);
    beat('chat-landing');

    try {
      var isNewTab = (pending.tabId != null && MY_TAB_ID != null && pending.tabId !== MY_TAB_ID)
        || !!window.opener;
      BAA.log('info', '落地沟通页：' + (isNewTab ? 'BOSS 新开标签' : '当前标签跳转') +
        ' · ' + (pending.job.company || '') + ' / ' + (pending.job.title || ''));

      var st0 = await BAA.getState();
      if (st0.status === 'stopped') {
        BAA.log('info', '任务已停止，跳过招呼语与记账');
        return;
      }

      // 1. Send the user's custom greeting in the freshly opened conversation.
      var greet = await withTimeout(
        sendChatGreeting(pending),
        num(cfg.behavior.actionTimeoutMs, 20000) + num(cfg.behavior.chatComposerWaitMs, 9000),
        '招呼语发送'
      );
      if (!greet || !greet.ok) BAA.log('warn', '招呼语未发出：' + (greet && greet.why || greet && greet.note || '未知原因'));

      // 2. Accounting lives HERE, not on the search page: a full-page navigation
      //    destroys that context before applyOne() can ever return. Re-read the
      //    state right before writing so nothing is overwritten.
      var s = await BAA.getState();
      await BAA.addHistory(pending.job.id, {
        company: pending.job.company, title: pending.job.title, city: pending.job.city,
        salary: pending.job.salaryText, link: pending.job.link,
        companyKey: BAA.companyKey(pending.job.company), platform: cfg && cfg.platform || '',
        greetingSent: !!(greet && greet.ok), sentAt: new Date().toISOString()
      });
      s = await BAA.getState();
      s.stats.applied = (s.stats.applied || 0) + 1;
      s.todayCount = (s.todayCount || 0) + 1;
      s.summary = greet && greet.ok
        ? '沟通已建立，自定义招呼语已发送'
        : '沟通已建立（招呼语未发出）';
      s.phase = 'landing-done';
      s.heartbeat = Date.now();
      await BAA.saveState(s);
      BAA.log('ok', '投递 ' + (pending.job.company || '') + ' · ' + (pending.job.title || '') + '（' + s.summary + '）');

      if (isNewTab) {
        // The ORIGINAL search tab keeps running; release the run lock so it can.
        await BAA.beat('', 'returning', 'chat', location.href);
        if (cfg.behavior.chatCloseNewTab) {
          await BAA.sleep(Math.max(500, num(cfg.behavior.afterChatDelayMs, 1200)));
          try { await chrome.runtime.sendMessage({ type: 'BAA_CLOSE_TAB' }); } catch (e) { /* ignore */ }
        }
        return;
      }

      if (s.status !== 'running') { ensureBadge(); return; }

      if (cfg.behavior.afterChat === 'stay') {
        s.status = 'paused';
        s.summary = '已停在沟通页（设置：沟通后停留）。手动回到搜索结果页后点「继续」。';
        await BAA.saveState(s);
        await BAA.beat('', 'paused', 'chat', location.href);
        ensureBadge();
        return;
      }

      // v2.3 ROOT-CAUSE FIX: history.back() restores the search page from the
      // back/forward cache. The content script there is still alive but run()
      // has already returned, so the task sat at "running" forever after the
      // FIRST job. Force a fresh document load => boot() runs again => run().
      s = await BAA.getState();
      s.lastFirstKey = '';
      s.phase = 'returning';
      s.heartbeat = Date.now();
      s.summary = '沟通完成，正在返回搜索页继续任务';
      await BAA.saveState(s);
      await BAA.beat('', 'returning', 'chat', location.href);
      await BAA.sleep(Math.max(500, num(cfg.behavior.afterChatDelayMs, 1200)));

      var back = pending.searchUrl;
      if (!back) {
        var t = (await BAA.getState()).queue[(await BAA.getState()).queueIndex];
        back = t ? BAA.buildUrl(cfg.searchUrlTemplate, t, 1) : '';
      }
      if (back) {
        BAA.log('info', '强制重新加载搜索页以恢复任务（避免 bfcache 卡死）');
        location.replace(back);
      } else {
        history.back();
      }
    } finally {
      landingInProgress = false;
    }
  }

  /* ------------------------------------------------------------------ *
   * yupao detail-page landing (/zhaogong/...)
   * The search tab opened this tab via window.open(); here we click "聊一聊",
   * send the custom greeting inside the in-page IM widget, do the accounting,
   * then close the tab so the search tab keeps cycling jobs.
   * ------------------------------------------------------------------ */
  // 仅当元素真实落在视口内才视为可点。鱼泡详情页存在「屏幕外」的重复沟通按钮
  // （例如顶部"查看所有职位"区里的另一份「免费聊」），旧的布局级可见性判断会把
  // 坐标点击落到屏幕外那个副本上，导致点击落空、聊天窗弹不出来。
  function inViewport(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var vh = window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || 0;
    var vw = window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || 0;
    return r.top >= -r.height && r.bottom <= vh + r.height &&
           r.left >= -r.width && r.right <= vw + r.width;
  }

  // 鱼泡详情页沟通按钮是 <span class="addag">免费聊</span>（同页还有「发送简历」
  // 「拨打电话」以及屏幕外的重复副本）。直接锁定 .addag 并过滤视口，避免点错副本。
  function findAddagChatButton(labels, alreadyW) {
    var els = document.querySelectorAll('.addag');
    var alreadyBtn = null;
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (!inViewport(e)) continue;
      var t = (e.innerText || '').replace(/\s+/g, ' ').trim();
      if (alreadyW.some(function (w) { return t.indexOf(w) >= 0; })) { alreadyBtn = e; continue; }
      if (labels.some(function (w) { return t === w || t.indexOf(w) >= 0; })) return { el: e, already: false };
    }
    return alreadyBtn ? { el: alreadyBtn, already: true } : null;
  }

  async function waitForDetailChatButton(job, timeoutMs) {
    var start = Date.now();
    // 用户明确规则（2026-11-05）：页面出现「免费聊」就点击它去打招呼；出现「继续聊」
    // 说明之前已沟通过，直接跳过、按顺序执行下一个。绝不点击「发送简历」（那是发简历，
    // 不是免费打招呼）。故可点击标签只包含「免费聊」系；已聊标签交给 alreadyW 处理。
    var labels = [
      cfg.applyBehavior && cfg.applyBehavior.chatButtonText,
      '免费聊', '聊一聊', '免费沟通', '立即沟通', '在线沟通'
    ].filter(Boolean);
    var alreadyW = cfg.alreadyChattedTexts || ['继续聊', '继续沟通'];
    while (Date.now() - start < timeoutMs) {
      if (pageRole() !== 'detail') return { btn: null, note: '已离开详情页' };
      var hit = findAddagChatButton(labels, alreadyW);
      if (hit && hit.el) {
        // 滚入视口，确保真实点击落在该按钮上（而非屏幕外副本）
        try { hit.el.scrollIntoView({ block: 'center' }); } catch (e) { /* ignore */ }
        await BAA.sleep(180);
        if (!inViewport(hit.el)) { await BAA.sleep(200); continue; }
        return { btn: hit.el, already: hit.already };
      }
      await BAA.sleep(200);
    }
    return { btn: null, note: '等待「免费聊」按钮超时' };
  }

  async function sendDetailGreeting(pending) {
    var b = cfg.behavior;
    if (!b.chatGreetingEnabled) return { ok: false, established: false, disabled: true, why: '设置中关闭了「沟通页发送招呼语」' };
    if (!pending.greeting) return { ok: false, established: false, why: '招呼语为空（请检查设置里的招呼语模板）' };

    // Poll for the in-page IM composer. yupao pops a "发送简历" / confirm dialog
    // ~1-3s after clicking 免费聊; dismiss it as it appears so it never blocks
    // the composer or the message send. (Live-verified 2026-11-05.)
    var composer = null;
    var start = Date.now();
    var timeout = num(b.chatComposerWaitMs, 12000);
    while (Date.now() - start < timeout) {
      if (pageRole() !== 'detail') return { ok: false, established: false, why: '已离开详情页' };
      await dismissYupaoModal(1);
      composer = findChatComposer();
      if (composer) break;
      await BAA.sleep(300);
    }
    if (!composer) {
      // v2.7: 会话失效时点「免费聊」什么都不会发生，页面上只会冒出「登录/注册」
      // 手机号+验证码弹窗。以前这种情况被记成「沟通已建立」，白白虚增投递数。
      if (loginWallVisible()) {
        return { ok: false, established: false, needLogin: true, why: '页面要求重新登录（手机号/验证码弹窗），会话已失效' };
      }
      return { ok: false, established: false, why: '未找到 IM 输入框（聊天窗没有弹出）' };
    }

    // Make sure any residual modal is gone before we type / send.
    await dismissYupaoModal(2);

    setInputValue(composer, pending.greeting);
    await BAA.sleep(350);

    var send = findChatSendButton();
    var dline = Date.now() + num(b.chatSendWaitMs, 4000);
    while (Date.now() < dline && !sendButtonReady(send)) {
      await BAA.sleep(150);
      // Re-check for a late modal that might have re-appeared and re-dismiss.
      await dismissYupaoModal(1);
      send = findChatSendButton();
    }
    if (sendButtonReady(send)) {
      send.click();
      await BAA.sleep(600);
      return { ok: true, established: true, why: '点击发送按钮' };
    }
    if (b.chatSendKeyFallback) {
      try {
        composer.focus();
        ['keydown', 'keypress', 'keyup'].forEach(function (type) {
          composer.dispatchEvent(new KeyboardEvent(type, {
            bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
          }));
        });
        await BAA.sleep(600);
        return { ok: true, established: true, why: 'Enter 兜底' };
      } catch (e) { /* ignore */ }
    }
    return { ok: false, established: true, why: '发送按钮不可用' };
  }

  // A real login wall: a visible phone/验证码 input (or 微信扫码 block) sitting in
  // a popup. Used to tell "chat window never opened because the session died"
  // apart from "chat window is just slow".
  function loginWallVisible() {
    var inputs = qa(document, 'input[placeholder*="手机号"],input[placeholder*="验证码"]');
    for (var i = 0; i < inputs.length; i++) if (visible(inputs[i])) return true;
    var nodes = qa(document, 'div[class*="dialog"],div[class*="modal"],div[class*="login"]');
    for (var j = 0; j < nodes.length; j++) {
      if (!visible(nodes[j])) continue;
      var t = txt(nodes[j]);
      if (t.length < 400 && /登录\s*\/\s*注册|请输入手机号|扫码.*登录|验证码登录/.test(t)) return true;
    }
    return false;
  }

  // Shared accounting: history + applied/todayCount. Used by both BOSS chat
  // landing and yupao detail landing. Re-reads state right before writing so a
  // concurrent writer (the search tab) never loses its counts.
  async function accountApplied(pending, sent, summary) {
    var s = await BAA.getState();
    await BAA.addHistory(pending.job.id, {
      company: pending.job.company, title: pending.job.title, city: pending.job.city,
      salary: pending.job.salaryText, link: pending.job.link,
      companyKey: BAA.companyKey(pending.job.company), platform: cfg && cfg.platform || '',
      greetingSent: sent, sentAt: new Date().toISOString()
    });
    s = await BAA.getState();
    s.stats.applied = (s.stats.applied || 0) + 1;
    s.todayCount = (s.todayCount || 0) + 1;
    s.summary = summary;
    s.phase = 'landing-done';
    s.heartbeat = Date.now();
    await BAA.saveState(s);
    BAA.log('ok', '投递 ' + pending.job.company + ' · ' + pending.job.title + '（' + summary + '）');
  }

  async function closeThisTab() {
    try { await chrome.runtime.sendMessage({ type: 'BAA_CLOSE_TAB' }); } catch (e) { /* ignore */ }
  }

  // Reusable yupao modal dismisser. We scope the search to modal containers so
  // we never mis-click a stray "确定" that belongs to a normal page widget.
  // Two kinds of pop-ups appear on yupao:
  //   1. a fraud/risk warning ("禁止脱离平台… 知道了") the first time you chat
  //   2. a "发送简历" confirm after clicking 免费聊
  // We click the confirm/发送/确定 button and NEVER 取消/关闭/暂不. Idempotent:
  // if no visible modal is found it returns immediately (no-op).
  async function dismissYupaoModal(passes) {
    passes = passes || 1;
    var confirmWords = ['确定', '知道了', '确认', '同意', '好的', 'OK', '发送', '立即发送', '是'];
    var blockWords = ['取消', '关闭', '暂不', '稍后', '关闭弹窗'];
    for (var attempt = 0; attempt < passes; attempt++) {
      var modal = document.querySelector(
        '[role="dialog"]:not([style*="display: none"]),' +
        '.ant-modal-root .ant-modal:not(.ant-modal-hidden),' +
        '.ant-modal-wrap:not([style*="display: none"]),' +
        '[class*="modal"][class*="wrap"]'
      );
      if (!modal || modal.offsetParent === null) return true;
      var btns = Array.prototype.slice.call(
        modal.querySelectorAll('button, .ant-btn, span[role="button"], [role="button"]')
      ).filter(function (e) { return e.offsetParent !== null; });
      var hit = null;
      for (var i = 0; i < btns.length; i++) {
        var t = (btns[i].innerText || '').trim();
        if (blockWords.some(function (w) { return t.indexOf(w) >= 0; })) continue;
        if (confirmWords.some(function (w) { return t.indexOf(w) >= 0; })) { hit = btns[i]; break; }
      }
      if (hit) {
        BAA.log('info', '鱼泡弹窗出现，点击「' + (hit.innerText || '').trim() + '」关闭');
        hit.click();
        await BAA.sleep(700);
      } else {
        await BAA.sleep(300);
      }
    }
    return true;
  }

  async function handleDetailLanding() {
    if (landingInProgress) return;
    var pending = await BAA.getPending();
    if (!pending || !pending.job) return;
    if (pending.ts === lastHandledTs) return;
    if (Date.now() - pending.ts > num(cfg.behavior.chatLandingTimeoutMs, 12000) * 10) {
      await BAA.setPending(null);
      return;
    }
    // The detail tab was opened specifically for this pending job, so it is safe
    // to act. We only bail if the page is no longer a detail page (e.g. the user
    // navigated away). The previous strict URL-substring match could wrongly skip
    // jobs whose detail URL normalises differently.
    if (pageRole() !== 'detail') {
      BAA.log('warn', '详情页已离开（非 /zhaogong/ 页面），跳过岗位：' + (pending.job.title || ''));
      return;
    }
    landingInProgress = true;
    lastHandledTs = pending.ts;
    beat('detail-landing');

    try {
      var b = cfg.behavior;
      var isNewTab = (pending.tabId != null && MY_TAB_ID != null && pending.tabId !== MY_TAB_ID)
        || !!window.opener;
      BAA.log('info', '鱼泡详情页落地：' + (isNewTab ? '新开标签' : '当前标签跳转') +
        ' · ' + (pending.job.company || '') + ' / ' + (pending.job.title || ''));

      var st0 = await BAA.getState();
      if (st0.status === 'stopped') {
        BAA.log('info', '任务已停止，跳过招呼语与记账');
        return;
      }

      var chat = await waitForDetailChatButton(pending.job, num(b.detailWaitMs, 6000));
      if (!chat.btn) {
        BAA.log('warn', '详情页未找到「免费聊」按钮：' + chat.note);
        return;
      }
      if (chat.already) {
        await accountApplied(pending, false, '此前已沟通');
        return;
      }

      // Click 免费聊. yupao's React handler answers a realistic pointer sequence;
      // sendDetailGreeting then polls (up to ~12s) for the in-page IM composer
      // that pops a few seconds later. Do NOT fire a second el.click() right away
      // (the panel is still rendering) — a premature double-click toggles/closes
      // the window that is just opening, which is exactly why the composer never
      // appeared before. Live-verified 2026-11-05.
      clickRealistic(chat.btn);
      await BAA.sleep(500);
      if (!document.querySelector('.fb-editor') && !document.querySelector('button.btn-send')) {
        // 仅当 500ms 后仍无任何聊天输入框，才补一次真实点击；避免重复补刀
        try { chat.btn.click(); } catch (e) { /* ignore */ }
        BAA.log('debug', '免费聊 单次点击后 500ms 仍无聊天窗，补一次 el.click()');
      }
      var greet = await withTimeout(
        sendDetailGreeting(pending),
        num(b.actionTimeoutMs, 20000) + num(b.chatComposerWaitMs, 12000),
        '鱼泡招呼语发送'
      );

      // v2.7: 会话失效 -> 立刻暂停并提示重新登录，绝不记账。
      if (greet && greet.needLogin) {
        var sN = await BAA.getState();
        sN.loginStatus = 'expired';
        sN.loginReason = greet.why;
        sN.status = 'need-login';
        sN.summary = '鱼泡登录会话已失效：' + greet.why + '。请重新登录后点「继续」。';
        await BAA.saveState(sN);
        BAA.log('warn', '停止投递：' + greet.why);
        try { await chrome.runtime.sendMessage({ type: 'BAA_OPEN_LOGIN', platform: cfg.platform }); } catch (e) { /* ignore */ }
        return;
      }

      if (!greet || !greet.ok) {
        BAA.log('warn', '鱼泡招呼语未发出：' + (greet && (greet.why || greet.note) || '未知原因'));
        // v2.7: 聊天窗都没建立起来 -> 不算投递成功，也不写历史，下次还会重试。
        if (b.chatGreetingEnabled && !(greet && greet.established)) {
          BAA.log('warn', '聊天窗口未建立，本次不计入投递（已跳过，不占今日名额）');
          return;
        }
      }

      await accountApplied(pending, !!(greet && greet.ok),
        greet && greet.ok ? '沟通已建立，自定义招呼语已发送'
          : (greet && greet.disabled ? '沟通已建立（招呼语已关闭）' : '沟通已建立（招呼语未发出）'));
    } finally {
      landingInProgress = false;
      // Clear the hand-off record only after the detail tab is done, so the
      // search tab (which polls getPending) waits for full accounting before
      // opening the next detail tab. Also closes this tab so it never piles up.
      await BAA.setPending(null);
      if (cfg.behavior.chatCloseNewTab) {
        await BAA.sleep(Math.max(400, num(cfg.behavior.afterChatDelayMs, 1200)));
        await closeThisTab();
      }
    }
  }

  /* ------------------------------------------------------------------ *
   * Paging / navigation
   * ------------------------------------------------------------------ */
  async function nextPage() {
    var before = firstCardKey();
    var next = q(document, cfg.selectors.nextPage) || findByText(document, ['下一页', '下页']);
    var cls = next ? String(next.className || '') : '';
    var usable = next && visible(next) && !/disabled|no-next|unable/i.test(cls) && next.getAttribute('aria-disabled') !== 'true';
    if (usable) next.click();
    else {
      var more = q(document, cfg.selectors.loadMore) || findByText(document, ['加载更多', '查看更多职位']);
      if (more && visible(more)) more.click();
      else return 'no-next';
    }
    for (var i = 0; i < 12; i++) {
      await BAA.sleep(400);
      if (firstCardKey() !== before) return 'ok';
    }
    return 'ok-timeout';
  }

  async function navigateTo(url) {
    var origin = location.href;
    try {
      var r = await chrome.runtime.sendMessage({ type: 'BAA_NAVIGATE', url: url });
      if (r && r.ok === false) BAA.log('error', '页面导航被拒绝：' + r.msg);
    } catch (e) {
      BAA.log('error', '页面导航失败：' + (e && e.message || e));
    }
    setTimeout(async function () {
      try {
        var s = await BAA.getState();
        if (s.status !== 'running') return;
        if (location.href !== origin || pageRole() === 'search') return; // navigation worked
        s.status = 'blocked';
        s.blockedReason = '自动跳转未生效';
        s.summary = '自动跳转未生效：请手动打开 ' + PN() + '搜索页，然后在面板点「继续」';
        await BAA.saveState(s);
        BAA.log('error', s.summary);
      } catch (e) { /* tab closing */ }
    }, 15000);
    return 'navigating';
  }

  /* ------------------------------------------------------------------ *
   * State machine
   * ------------------------------------------------------------------ */
  // Re-read the latest state before writing so a concurrent landing tab (BOSS
  // chat / yupao detail) never loses its applied/todayCount increments (v2.2 bug
  // class). We take the MAX per counter rather than blindly overwriting.
  async function commit() {
    if (!state) return;
    try {
      var fresh = await BAA.getState();
      var keys = ['applied', 'todayCount', 'scanned', 'matched', 'skipped', 'duplicated', 'failed'];
      keys.forEach(function (k) {
        var fv = fresh.stats ? fresh.stats[k] : undefined;
        if (typeof fv === 'number') state.stats[k] = Math.max(state.stats[k] || 0, fv);
      });
      state.todayCount = Math.max(state.todayCount || 0, fresh.todayCount || 0);
    } catch (e) { /* storage busy */ }
    await BAA.saveState(state);
  }

  async function interruptibleSleep(ms) {
    var left = Number(ms) || 0;
    var ticks = 0;
    while (left > 0) {
      await BAA.sleep(Math.min(400, left));
      left -= 400;
      // Cooldowns can be 12-28s. Keep the heartbeat alive so the background
      // watchdog never mistakes a legitimate delay for a frozen state machine.
      if (++ticks % 3 === 0) beat('cooldown');
      var s = await BAA.getState();
      if (s.status !== 'running') return false;
      if (pageRole() !== 'search') return false;
    }
    return true;
  }

  function resetDailyIfNeeded() {
    var today = BAA.today();
    if (state.today !== today) {
      state.today = today;
      state.todayCount = 0;
      /* v3.0: 今日次数在任务启动时按平台从历史重算 */
    }
  }

  async function finish(summary, status) {
    state.status = status || 'stopped';
    state.summary = summary;
    state.finishedAt = Date.now();
    await commit();
    await BAA.log('info', summary);
    // v2.8: never end a run silently when nothing was delivered. The most
    // common real cause is not a bug — it is 每页最多处理数 / 每个任务最多页数 被
    // 设成 1，于是整轮只评估一个岗位；其次是筛选条件过严。Say it out loud.
    try {
      var st = state.stats || {};
      var scanned = Number(st.scanned) || 0;
      var applied = Number(st.applied) || 0;
      if (scanned > 0 && applied === 0) {
        var keys = Object.keys(skipTally).sort(function (a, b) { return skipTally[b] - skipTally[a]; });
        var top = keys.slice(0, 3).map(function (k) { return k + ' ×' + skipTally[k]; }).join('；');
        await BAA.log('warn', '本轮 0 投递：评估 ' + scanned + ' 个岗位，跳过 ' + (Number(st.skipped) || 0) +
          ' 个' + (top ? '（主要命中：' + top + '）' : '') +
          '。先看「设置 → 行为」里的「每页最多处理数」（0=不限）与「每个任务最多页数」是否被设成 1，' +
          '再看「设置 → 筛选条件」是否过严。');
      } else if (applied > 0) {
        await BAA.log('ok', '本轮投递 ' + applied + ' 个，今天累计 ' + (Number(state.todayCount) || 0) + ' 个');
      }
    } catch (e) { /* diagnostics must never break the run */ }
    ensureBadge();
  }

  async function pauseOnWrongPage() {
    state.status = 'paused';
    state.summary = '当前不在搜索结果页（' + location.pathname + '），任务已暂停以免误操作。' +
      '请回到搜索结果页后点「继续」。';
    await commit();
    BAA.log('warn', state.summary);
    ensureBadge();
  }

  async function switchTask(reason) {
    BAA.log('info', reason);
    state.queueIndex++;
    state.page = 1;
    state.lastFirstKey = '';
    await commit();
    var t = state.queue[state.queueIndex];
    if (t) {
      BAA.log('info', '切换任务：' + t.query + ' / ' + (t.cityName || ''));
      await navigateTo(BAA.buildUrl(cfg.searchUrlTemplate, t, 1));
      return true;
    }
    await finish('全部搜索任务已完成');
    return true;
  }

  async function run() {
    if (running || starting) return;
    if (pageRole() !== 'search') {
      state = await BAA.getState();
      if (state.status === 'running') await pauseOnWrongPage();
      return;
    }
    // Cross-context mutex: a bfcache-restored search page and a freshly loaded
    // search page must never both run the state machine (double deliveries).
    starting = true;
    var live = null;
    try { live = await BAA.getRun(); } catch (e) { /* storage gone */ }
    finally { starting = false; }
    if (live && live.owner && live.owner !== OWNER && Date.now() - live.ts < 9000) return;
    running = true;
    beat('start');
    try {
      for (var guard = 0; guard < 2000; guard++) {
        beat('scan');
        state = await BAA.getState();
        cfg = await BAA.getConfig();
        ensureBadge();
        if (state.status !== 'running') break;
        if (pageRole() !== 'search') { await pauseOnWrongPage(); break; }
        resetDailyIfNeeded();
        await commit();

        if (state.todayCount >= num(cfg.behavior.dailyLimit, 40)) {
          await finish('已达到每日投递上限 ' + cfg.behavior.dailyLimit + '，任务结束');
          break;
        }

        var task = state.queue[state.queueIndex];
        if (!task) { await finish('全部搜索任务已完成'); break; }

        var block = detectBlock();
        if (block && cfg.behavior.stopOnVerification) {
          state.blockedReason = block;
          await finish('已暂停：' + block + '。请在浏览器中手动处理后再点「继续」', 'blocked');
          break;
        }

        var fk = firstCardKey();
        if (fk && state.lastFirstKey && fk === state.lastFirstKey && state.page > 1) {
          if (await switchTask('翻页后岗位列表未变化，判定已到末页')) break;
          return;
        }
        state.lastFirstKey = fk;

        if (!(await ensurePageReady())) {
          await finish('页面未就绪：未等到岗位列表和「立即沟通」按钮，请确认已登录并停留在搜索结果页', 'blocked');
          break;
        }

        var cards = findCards();
        BAA.log('info', '第 ' + state.page + ' 页识别到 ' + cards.length + ' 个岗位卡片');
        if (!cards.length) BAA.log('warn', '未识别到岗位卡片，请点「识别当前页」校准选择器');

        var limit = Number(cfg.behavior.maxJobsPerPage) > 0
          ? Math.min(cards.length, Number(cfg.behavior.maxJobsPerPage)) : cards.length;
        if (limit < cards.length) {
          BAA.log('info', '设置「每页最多处理数 = ' + cfg.behavior.maxJobsPerPage +
            '」，本页只评估前 ' + limit + ' 个（共 ' + cards.length + ' 个）。改成 0 即不限。');
        }

        for (var i = 0; i < limit; i++) {
          state = await BAA.getState();
          if (state.status !== 'running') break;
          if (pageRole() !== 'search') { await pauseOnWrongPage(); return; }
          var job = BAA.parseCard(cards[i], cfg, i);
          state.stats.scanned++;
          state.current = { query: task.query, cityName: task.cityName || '', jobTitle: job.title };

          var verdict = BAA.matchJob(job, cfg);
          if (!verdict.pass) {
            state.stats.skipped++;
            var kr = String(verdict.reason || '未匹配').slice(0, 40);
            skipTally[kr] = (Number(skipTally[kr]) || 0) + 1;
            BAA.log('debug', '跳过 ' + job.company + ' / ' + job.title + '：' + verdict.reason);
            await commit();
            continue;
          }
          state.stats.matched++;
          await commit();

          var history = await BAA.getHistory();
          if (history[job.id]) { state.stats.duplicated++; await commit(); continue; }

          // v2.9: 公司级去重。同一家公司在 BOSS 上常同时挂多个岗位（job id 不同，
          // 公司名相同），只按 job id 去重会反复给同一个 HR 打招呼。命中本地记录
          // 就直接跳过，不看岗位。可在「设置 → 行为」里关闭。
          if (cfg.behavior.dedupeByCompany !== false) {
            // v3.0: 只在同一平台内比对 —— 鱼泡打过招呼的公司不影响 BOSS。
            var coHit = BAA.findCompanyHistory(history, job.company, Number(cfg.behavior.dedupeDays) || 0, cfg.platform);
            if (coHit) {
              state.stats.duplicated++;
              skipTally['该公司已打过招呼'] = (Number(skipTally['该公司已打过招呼']) || 0) + 1;
              BAA.log('info', '跳过 ' + job.company + ' / ' + job.title + '：该公司已于 ' +
                BAA.formatDay(coHit.ts) + ' 打过招呼（当时岗位：' + (coHit.title || '—') + '），本地已有记录');
              await commit();
              continue;
            }
          }

          var attempt = 0, outcome = null;
          while (attempt <= Number(cfg.behavior.retryPerJob || 0)) {
            attempt++;
            try {
              outcome = await withTimeout(
                applyOne(cards[i], job),
                num(cfg.behavior.actionTimeoutMs, 20000),
                '岗位动作'
              );
              break;
            } catch (e) {
              if (e instanceof BlockedError) {
                state.blockedReason = e.reason;
                await finish('已暂停：' + e.reason + '。请手动处理后点「继续」', 'blocked');
                return;
              }
              outcome = { result: 'failed', note: String(e && e.message || e) };
              await BAA.sleep(BAA.rand(700, 1300));
            }
          }

          if (outcome.result === 'handoff') {
            // The landing page (BOSS chat / yupao detail) owns greeting +
            // accounting. DO NOT write history or commit() here: this context is
            // a stale snapshot and would overwrite the landing page's
            // applied/todayCount (v2.2 bug).
            beat('handoff');
            BAA.log('info', job.company + ' / ' + job.title + '：' + outcome.note);
            if (cfg.applyBehavior && cfg.applyBehavior.type === 'detail') {
              // yupao: the detail tab handles accounting then closes itself; the
              // search tab must keep cycling instead of stopping.
              await commit();
              var d2 = BAA.rand(num(cfg.behavior.minDelaySec, 12) * 1000, num(cfg.behavior.maxDelaySec, 28) * 1000);
              if (!(await interruptibleSleep(d2))) return;
              continue;
            }
            return;
          }
          if (outcome.result === 'applied') {
            state.stats.applied++;
            state.todayCount++;
            await BAA.addHistory(job.id, {
              company: job.company, title: job.title, city: job.city,
              salary: job.salaryText, link: job.link,
              companyKey: BAA.companyKey(job.company), platform: cfg.platform || '',
              greetingSent: true, sentAt: new Date().toISOString()
            });
            BAA.log('ok', '投递 ' + job.company + ' · ' + job.title +
              (job.salaryHidden ? ' · 薪资未显示' : ' · ' + job.salaryText) + '（' + outcome.note + '）');
          } else if (outcome.result === 'already' || outcome.result === 'filled-only') {
            state.stats.skipped++;
            BAA.log('info', job.company + ' / ' + job.title + '：' + outcome.note);
          } else if (outcome.result === 'need-login') {
            state.loginStatus = 'required';
            state.loginReason = outcome.note;
            await finish('已暂停：' + outcome.note + '。登录后点「继续」', 'need-login');
            return;
          } else {
            state.stats.failed++;
            BAA.log('warn', job.company + ' / ' + job.title + '：' + outcome.note);
            if (outcome.result === 'timeout') await BAA.setPending(null);
          }
          await commit();
          ensureBadge();

          var delay = BAA.rand(num(cfg.behavior.minDelaySec, 12) * 1000, num(cfg.behavior.maxDelaySec, 28) * 1000);
          if (!(await interruptibleSleep(delay))) return;
        }

        state = await BAA.getState();
        if (state.status !== 'running') break;
        if (pageRole() !== 'search') { await pauseOnWrongPage(); break; }

        if (Number(state.page) >= Number(cfg.behavior.maxPagesPerTask)) {
          if (await switchTask('本任务已达到最大页数')) break;
          return;
        }

        var nav = await nextPage();
        state.page++;
        state.lastFirstKey = firstCardKey();
        await commit();
        if (nav === 'no-next') {
          var t2 = state.queue[state.queueIndex];
          BAA.log('info', '未找到翻页按钮，改用 URL 分页到 page=' + state.page);
          await navigateTo(BAA.buildUrl(cfg.searchUrlTemplate, t2, state.page));
          return;
        }
        await interruptibleSleep(num(cfg.behavior.pageDelaySec, 4) * 1000);
      }
    } catch (err) {
      BAA.log('error', '运行异常：' + (err && err.message || err));
      await finish('运行异常中止：' + (err && err.message || err), 'blocked');
    } finally {
      running = false;
      beat('idle');
      try { await BAA.releaseRun(OWNER); } catch (e) { /* ignore */ }
    }
  }

  /* ------------------------------------------------------------------ *
   * Commands
   * ------------------------------------------------------------------ */
  function taskMatchesCurrentPage(task) {
    var u = new URL(location.href);
    if (cfg && cfg.platform === 'yupao') {
      // yupao search URL: /topic/{city}c0/?keywords={query}
      return pathPart().indexOf('/topic/') >= 0 &&
        pathPart().indexOf((task.city || '') + 'c0') >= 0 &&
        (u.searchParams.get('keywords') || '').trim() === task.query;
    }
    var qv = (u.searchParams.get('query') || '').trim();
    var cv = (u.searchParams.get('city') || '').trim();
    return decodeURIComponent(qv) === task.query && (!task.city || cv === task.city || cv === '');
  }

  async function command(msg) {
    switch (msg.type) {
      case 'STATUS': {
        var s = await BAA.getState();
        var c = await BAA.getConfig();
        state = s; cfg = c; ensureBadge();
        var snap = await BAA.getLoginSnapshot();
        var runInfo = await BAA.getRun().catch(function () { return null; });
        return {
          ok: true, state: s, dailyLimit: c.behavior.dailyLimit, dryRun: c.behavior.dryRun,
          pageRole: pageRole(), url: location.href, run: runInfo,
          machineRunning: running, platformName: c.platformName || PN(),
          loginSnapshotText: BAA.loginSnapshotText(snap)
        };
      }
      case 'CHECK_LOGIN': {
        var c0 = await BAA.getConfig();
        cfg = c0;
        var lr = await BAA.checkLogin(c0);
        var st = await BAA.getState();
        st.loginStatus = lr.status; st.loginReason = lr.reason; st.lastLoginCheck = Date.now();
        // A successful re-check must clear the stale "need-login" banner that an
        // earlier failed check left in state (the popup renders it from status).
        if (lr.status === 'ok' && st.status === 'need-login') {
          st.status = 'stopped';
          st.summary = '';
          st.blockedReason = '';
          if (loginWatcher) { clearInterval(loginWatcher); loginWatcher = null; }
          BAA.log('ok', '登录态恢复正常，已清除之前的登录提示');
        }
        await BAA.saveState(st);
        state = st; ensureBadge();
        var snap0 = await BAA.getLoginSnapshot();
        return { ok: true, status: lr.status, reason: lr.reason, snapshotText: BAA.loginSnapshotText(snap0) };
      }
      case 'GO_LOGIN': {
        try {
          var gl = await chrome.runtime.sendMessage({
            type: 'BAA_OPEN_LOGIN', platform: (await BAA.getConfig()).platform
          });
          return gl && gl.ok
            ? { ok: true, msg: '已打开登录页，登录完成后会自动检测' }
            : { ok: false, msg: (gl && gl.msg) || '打开登录页失败' };
        } catch (e) { return { ok: false, msg: String(e.message || e) }; }
      }
      case 'REFRESH_PAGE': {
        try {
          var rf = await chrome.runtime.sendMessage({
            type: 'BAA_REFRESH_PLATFORM_TAB', platform: (await BAA.getConfig()).platform
          });
          return rf && rf.ok ? { ok: true, msg: '已刷新页面，正在重新自检' }
            : { ok: false, msg: (rf && rf.msg) || '刷新失败' };
        } catch (e) { return { ok: false, msg: String(e.message || e) }; }
      }
      case 'BACK_TO_SEARCH': {
        try {
          var st9 = await BAA.getState();
          var t9 = st9.queue[st9.queueIndex];
          var url9 = t9 ? BAA.buildUrl(cfg.searchUrlTemplate, t9, st9.page || 1) : '';
          if (!url9) return { ok: false, msg: '没有进行中的搜索任务' };
          await chrome.runtime.sendMessage({ type: 'BAA_NAVIGATE', url: url9 });
          return { ok: true, msg: '正在返回搜索页' };
        } catch (e) { return { ok: false, msg: String(e.message || e) }; }
      }
      case 'START': {
        var c1 = await BAA.getConfig();
        // v3.1: 先确认本页所属平台 == 配置里选的平台。不一致直接拒绝，
        // 绝不再拿另一个平台的规则在本页硬跑（那正是「卡死」的来源）。
        var mm = platformMismatch(c1);
        if (mm) {
          var mmMsg = platformMismatchMsg(mm);
          await BAA.log('warn', '启动被阻止：' + mmMsg);
          return { ok: false, wrongPlatform: true, myPlatform: mm.mine, platform: mm.want, msg: mmMsg };
        }
        var tasks = (c1.tasks || []).filter(function (t) { return t && t.enabled !== false && String(t.query || '').trim(); });
        if (!tasks.length) return { ok: false, msg: '请先在「设置」里添加并启用至少一个搜索任务' };
        if (pageRole() === 'chat') {
          return { ok: false, msg: '当前是沟通列表页，请点「返回搜索页」或手动打开搜索结果页后再开始' };
        }
        var s1 = await BAA.getState();
        s1.status = 'running';
        s1.queue = tasks;
        s1.queueIndex = 0;
        s1.page = 1;
        s1.lastFirstKey = '';
        s1.blockedReason = '';
        s1.summary = '';
        s1.finishedAt = 0;
        s1.startedAt = Date.now();
        s1.stats = { scanned: 0, matched: 0, applied: 0, skipped: 0, duplicated: 0, failed: 0 };
        var td = BAA.today();
        if (s1.today !== td) { s1.today = td; s1.todayCount = 0; }
        // v3.0: 今日额度按「当前平台」从投递流水重算。state 是全局共享的、且会被
        // 心跳写回，靠它存转会让鱼泡继承 BOSS 的次数；历史记录才是单一数据源。
        try { s1.todayCount = await BAA.countTodayApplied(c1.platform); } catch (e) { /* keep */ }
        await BAA.setPending(null);
        // An explicit manual START clears the "skip this window" override.
        try { await BAA.clearScheduleOverride(); } catch (e) { /* ignore */ }
        cfg = c1; state = s1;
        await BAA.saveState(s1);
        BAA.log('info', '任务启动：' + BAA.platformName(c1.platform) + ' · ' + tasks.length + ' 组搜索条件' + (c1.behavior.dryRun ? '（模拟运行）' : ''));
        // v2.8: make the caps visible on every run. A silent cap is the #1
        // reason a run "only searches but never applies".
        skipTally = {};
        var b0 = c1.behavior || {};
        var perPage = Number(b0.maxJobsPerPage) > 0 ? b0.maxJobsPerPage : '不限';
        var maxPages = Number(b0.maxPagesPerTask) || 1;
        BAA.log('info', '本轮参数：' + BAA.platformName(c1.platform) + ' · 每日上限 ' + (Number(b0.dailyLimit) || 0) +
          ' / 每个任务最多 ' + maxPages + ' 页 / 每页最多 ' + perPage + ' 个 / 投递动作 ' +
          (b0.action === 'chat' ? '立即沟通' : b0.action || 'chat') +
          ' / 发送招呼语 ' + (b0.chatGreetingEnabled === false ? '关' : '开') +
          ' / 筛选：薪资 ' + (c1.filter && c1.filter.salaryMin || 0) + '-' + (c1.filter && c1.filter.salaryMax || '不限') + 'K' +
          (c1.filter && c1.filter.titleExclude && c1.filter.titleExclude.length
            ? '，岗位名排除 ' + c1.filter.titleExclude.length + ' 个词' : ''));
        if (Number(b0.maxJobsPerPage) === 1) {
          BAA.log('warn', '「每页最多处理数」= 1：每页只会评估第 1 个岗位，几乎不可能投递成功。' +
            '要批量投递请到「设置 → 行为」把它改成 0（不限）。');
        }
        if (maxPages === 1) {
          BAA.log('warn', '「每个任务最多页数」= 1：不会翻页，只处理搜索结果第一页。要覆盖更多岗位请调大。');
        }

        if (c1.behavior.loginCheckEnabled && !(await loginGate(c1))) {
          return { ok: true, msg: state.summary };
        }
        await BAA.saveState(state);

        if (pageRole() !== 'search' || !taskMatchesCurrentPage(tasks[0])) {
          await navigateTo(BAA.buildUrl(c1.searchUrlTemplate, tasks[0], 1));
          return { ok: true, msg: '正在打开搜索页，加载完成后会自动开始' };
        }
        run();
        return { ok: true, msg: '任务已启动' };
      }
      case 'PAUSE': {
        var s2 = await BAA.getState();
        if (s2.status !== 'running') return { ok: false, msg: '当前没有运行中的任务' };
        s2.status = 'paused'; await BAA.saveState(s2);
        // v2.4: a manual pause must win over the scheduler for this window.
        try { await BAA.setScheduleOverride(await BAA.getConfig()); } catch (e) { /* ignore */ }
        BAA.log('info', '已暂停');
        return { ok: true, msg: '已暂停' };
      }
      case 'RESUME': {
        var c3 = await BAA.getConfig();
        cfg = c3;
        var s3 = await BAA.getState();
        if (pageRole() === 'chat') {
          return { ok: false, msg: '当前在沟通列表页，请先点「返回搜索页」' };
        }
        if (c3.behavior.loginCheckEnabled) {
          var lr3 = await BAA.checkLogin(c3);
          s3.loginStatus = lr3.status; s3.loginReason = lr3.reason; s3.lastLoginCheck = Date.now();
          if (lr3.status !== 'ok') {
            s3.status = 'need-login';
            s3.summary = '仍需登录 ' + PN() + '：' + lr3.reason + '。登录完成后再点「继续」。';
            await BAA.saveState(s3);
            state = s3; ensureBadge();
            if (c3.behavior.autoWaitForLogin) startLoginWatcher();
            return { ok: false, msg: s3.summary };
          }
        }
        s3.status = 'running'; s3.blockedReason = ''; s3.summary = '';
        await BAA.saveState(s3);
        try { await BAA.clearScheduleOverride(); } catch (e) { /* ignore */ }
        BAA.log('info', '继续执行');
        state = s3; run();
        return { ok: true, msg: '已继续' };
      }
      case 'STOP': {
        var s4 = await BAA.getState();
        if (loginWatcher) { clearInterval(loginWatcher); loginWatcher = null; }
        s4.status = 'stopped'; s4.summary = '手动停止'; s4.finishedAt = Date.now();
        await BAA.saveState(s4);
        await BAA.setPending(null);
        // v2.4: do not let the next 30s scheduler tick undo a manual stop.
        try { await BAA.setScheduleOverride(await BAA.getConfig()); } catch (e) { /* ignore */ }
        BAA.log('info', '已手动停止');
        return { ok: true, msg: '已停止' };
      }
      case 'CALIBRATE': {
        var c2 = await BAA.getConfig();
        cfg = c2;
        var role = pageRole();
        qa(document, c2.selectors.jobCard).forEach(function (el) { delete el.__baaJob; });
        var info = BAA.calibrate(c2);
        info.pageRole = role;
        info.verification = detectBlock() || '未检测到';
        info.login = BAA.checkLoginDom ? BAA.checkLoginDom(c2) : { status: 'unknown' };
        if (role === 'chat') {
          var composer = findChatComposer();
          var sendBtn = findChatSendButton();
          info.chat = {
            sessionItems: qa(document, c2.selectors.chatSessionItem).length,
            composerFound: !!composer,
            composerTag: composer ? composer.tagName + '#' + composer.id + '.' + composer.className : '',
            composerInFrames: !!findComposerInFrames(),
            sendFound: !!sendBtn,
            sendReady: sendButtonReady(sendBtn),
            sendClass: sendBtn ? String(sendBtn.className || '') : '',
            conversationHead: conversationHead().slice(0, 120),
            iframes: document.querySelectorAll('iframe').length,
            greetingEnabled: c2.behavior.chatGreetingEnabled,
            greetingPreview: String(c2.behavior.greetingTemplate || '').slice(0, 60),
            afterChat: c2.behavior.afterChat
          };
          info.cardCount = 0;
          info.samples = [];
        }
        return Object.assign({ ok: true }, info);
      }
      case 'TOGGLE_BADGE': { ensureBadge(); return { ok: true }; }
      case 'BAA_KICK': {
        // Sent by the background watchdog when the state machine stopped
        // updating its heartbeat. Idempotent: run() refuses to start twice.
        var sk = await BAA.getState();
        state = sk;
        cfg = await BAA.getConfig();
        if (sk.status === 'running' && pageRole() === 'search' && !running) {
          BAA.log('info', '看门狗：检测到任务停滞，已自动恢复运行');
          run();
          return { ok: true, msg: '已恢复运行' };
        }
        return { ok: true, msg: '无需恢复（status=' + sk.status + ' role=' + pageRole() + ' running=' + running + '）' };
      }
      case 'BAA_SCHEDULE_START': {
        // Sent by the background scheduler when a time window opens.
        var didStart = await consumeAutoStart();
        return { ok: true, msg: didStart ? '定时启动指令已执行' : '无需启动（页面未就绪或已离开执行时段）' };
      }
      default: return { ok: false, msg: '未知指令：' + msg.type };
    }
  }

  /* v2.4 - one-shot auto-start hand-off from the background scheduler.
   * The window is re-checked immediately before acting, so a delayed message
   * can never start a run outside the configured hours. */
  async function consumeAutoStart() {
    var a = await BAA.getAutoStart();
    if (!a || !a.pending) return false;
    if (Date.now() - (a.ts || 0) > 5 * 60000) {
      await BAA.setAutoStart(null);
      return false;
    }
    var c = await BAA.getConfig();
    var ss = BAA.scheduleStatus(c.schedule, Date.now());
    if (!ss.active || ss.windowStart !== a.windowStart) {
      await BAA.setAutoStart(null);
      return false;
    }
    if (pageRole() !== 'search') return false;   // keep the hand-off for a later poll
    // v3.1: 定时任务只交给「当前配置平台」的搜索页；另一个平台的页面即使收到了
    // 也不要消费掉这个标记，留着让正确的平台页面来执行。
    if (platformMismatch(c)) return false;
    var taken = await BAA.takeAutoStart();
    if (!taken) return false;
    cfg = c;
    BAA.log('ok', '定时执行：' + (taken.label || '执行时段') + '，自动' +
      (taken.command === 'RESUME' ? '继续上次任务' : '开始任务'));
    var r = await command({ type: taken.command === 'RESUME' ? 'RESUME' : 'START' });
    BAA.log('info', '定时启动结果：' + (r && (r.msg || (r.ok ? '成功' : '失败')) || ''));
    return true;
  }

  var COMMANDS = ['STATUS', 'START', 'PAUSE', 'RESUME', 'STOP', 'CALIBRATE',
                  'CHECK_LOGIN', 'GO_LOGIN', 'BACK_TO_SEARCH', 'TOGGLE_BADGE',
                  'BAA_KICK', 'BAA_SCHEDULE_START'];
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || COMMANDS.indexOf(msg.type) === -1) return;
    command(msg).then(sendResponse).catch(function (e) {
      sendResponse({ ok: false, msg: String(e && e.message || e) });
    });
    return true;
  });

  /* ------------------------------------------------------------------ *
   * v2.3 self-healing liveness guard
   *
   * THE BUG THIS FIXES: after the first successful delivery BOSS navigated to
   * /web/geek/chat, then history.back() restored the search page from the
   * back/forward cache. The content script in that restored document was still
   * alive (STATUS answered fine) but run() had already returned on "handoff",
   * boot() does not re-run on a bfcache restore, and the role watcher saw no
   * role change. Result: status stuck at "running" forever, no more jobs.
   *
   * Defense in depth (any ONE of these is enough to resume):
   *   1. forced fresh document load instead of history.back()  -> boot() runs
   *   2. page-level guard: every 1.2s, if running task but no live state
   *      machine, restart run() (also covers bfcache / SPA / JS error)
   *   3. pageshow(persisted) + visibilitychange -> immediate guard tick
   *   4. background alarm watchdog -> BAA_KICK or re-navigate
   * ------------------------------------------------------------------ */
  async function guardTick() {
    try {
      if (starting) return;                      // another tick is starting run()
      if (running) { beat(); return; }          // keep the heartbeat alive
      if (pageRole() !== 'search') return;
      if (platformMismatch(cfg)) return;        // v3.1: 本页不是当前平台，别自愈启动
      var s = await BAA.getState();
      state = s;
      if (s.status !== 'running') return;

      // A hand-off is in progress: the chat landing page owns the next step.
      var p = await BAA.getPending();
      if (p && p.job && Date.now() - p.ts < num(cfg.behavior.chatLandingTimeoutMs, 12000) * 10) return;

      var live = await BAA.getRun().catch(function () { return null; });
      if (live && live.owner && live.owner !== OWNER && Date.now() - live.ts < 9000) return;

      if (Date.now() - lastGuardLog > 4000) {
        lastGuardLog = Date.now();
        BAA.log('info', '自愈守卫：页面重载后已自动接上任务，继续下一个岗位');
      }
      run();
    } catch (e) { /* tab closing / storage gone */ }
  }

  function startResumeGuard() {
    if (guardStarted) return;
    guardStarted = true;
    setInterval(guardTick, Math.max(600, num(cfg.behavior.resumeGuardMs, 1200)));
    setTimeout(guardTick, 300);
    // bfcache restore: boot() never runs again, but pageshow does.
    try {
      window.addEventListener('pageshow', function (e) {
        if (e.persisted) setTimeout(guardTick, 50);
      });
      document.addEventListener('visibilitychange', function () {
        if (!document.hidden) setTimeout(guardTick, 50);
      });
    } catch (e) { /* unsupported host / test harness */ }
  }

  // BOSS sometimes switches search -> chat as a same-document SPA navigation,
  // in which case the content script is NOT re-executed. Watch the URL role so
  // the landing (greeting + accounting) still runs in that case.
  var lastRole = null;
  function startRoleWatcher() {
    lastRole = pageRole();
    setInterval(async function () {
      try {
        var now = pageRole();
        if (now === lastRole) return;
        var prev = lastRole;
        lastRole = now;
        if (now === 'chat') {
          BAA.log('debug', '检测到 SPA 切换到沟通页，处理投递落地');
          await handleChatLanding();
        } else if (now === 'detail') {
          BAA.log('debug', '检测到 SPA 切换到详情页，处理投递落地');
          await handleDetailLanding();
        } else if (now === 'search' && (prev === 'chat' || prev === 'detail')) {
          await guardTick();
        }
      } catch (e) { /* tab closing */ }
    }, 400);
  }

  (async function boot() {
    try {
      cfg = await BAA.getConfig();
      state = await BAA.getState();
      ensureBadge();
      setInterval(async function () {
        try {
          state = await BAA.getState(); ensureBadge();
          // v2.4: pick up a scheduled start if the direct message was lost
          // (page still loading, BOSS blanked the document, bfcache, ...).
          var a = await BAA.getAutoStart();
          if (a && a.pending) await consumeAutoStart();
        } catch (e) { /* tab closing */ }
      }, 2500);
      startResumeGuard();
      startRoleWatcher();

      var role = pageRole();
      if (role === 'chat') {
        // CHAT PAGE IS INERT for the job state machine. Only process a landing.
        BAA.log('debug', '沟通页已加载：不启动任务，仅处理投递落地');
        if (state.status !== 'stopped') await handleChatLanding();
        return;
      }
      if (role === 'detail') {
        // yupao detail page: opened by applyYupao(); process the 聊一聊 + greeting
        // landing, then it closes itself. The search tab keeps cycling.
        BAA.log('debug', '详情页已加载：处理投递落地');
        if (state.status !== 'stopped') await handleDetailLanding();
        return;
      }
      if (role !== 'search' && !cfg.pageRules.allowRunOnOtherPages) {
        BAA.log('debug', '非搜索页：不启动任务');
        return;
      }
      // v2.4: a scheduled START/RESUME wins over the ordinary "resume running"
      // path (START rebuilds the queue and calls run() itself).
      if (await consumeAutoStart()) return;
      if (state.status === 'need-login' && cfg.behavior.autoWaitForLogin) startLoginWatcher();
      if (state.status === 'running') {
        await BAA.sleep(350);
        var fresh = await BAA.getState();
        if (fresh.status === 'running' && pageRole() === 'search') {
          BAA.log('info', '搜索页加载完成，继续执行任务');
          run();
        }
      }
    } catch (e) { /* storage unavailable */ }
  })();
})();
