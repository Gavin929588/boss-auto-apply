(function (root) {
  'use strict';

  var BAA = (root.BAA = root.BAA || {});

  BAA.FIELDS = {
    title: '岗位名称',
    company: '公司名称',
    salaryText: '薪资文本',
    salaryMin: '薪资下限(K)',
    salaryMax: '薪资上限(K)',
    city: '城市',
    area: '地区原文',
    experience: '经验要求',
    education: '学历要求',
    companySize: '公司规模',
    companyStage: '融资阶段',
    tags: '岗位标签',
    companyInfo: '公司信息',
    rawText: '卡片全文',
    hrActive: 'HR活跃',
    publishDays: '发布天数',
    link: '岗位链接'
  };

  BAA.OPS = {
    contains: '包含',
    notContains: '不包含',
    equals: '等于',
    regex: '正则匹配',
    gt: '数值大于',
    lt: '数值小于',
    notEmpty: '非空'
  };

  function toK(num, unit) {
    var n = parseFloat(num);
    if (isNaN(n)) return 0;
    if (/万/.test(unit)) return n * 10;
    if (/千/.test(unit)) return n;
    if (/元/.test(unit)) return n / 1000;
    return n;
  }

  BAA.parseSalary = function (textRaw) {
    var out = { min: 0, max: 0, months: 12, daily: false, raw: textRaw || '' };
    var t = String(textRaw || '').replace(/\s/g, '');
    if (!t || /面议|薪资不限|面议/.test(t)) return out;
    if (/\/天|元\/天|日薪|\/时|小时/.test(t)) { out.daily = true; return out; }
    var mm = t.match(/[·・](\d+)薪/);
    if (mm) out.months = parseInt(mm[1], 10);
    var m = t.match(/(\d+(?:\.\d+)?)\s*[-~～至]\s*(\d+(?:\.\d+)?)\s*(万|千|元|K|k)?/);
    if (m) {
      out.min = toK(m[1], m[3] || 'K');
      out.max = toK(m[2], m[3] || 'K');
    } else {
      var one = t.match(/(\d+(?:\.\d+)?)\s*(万|千|元|K|k)以上/);
      if (one) { out.min = toK(one[1], one[2]); out.max = out.min * 2; }
    }
    return out;
  };

  function fieldValue(job, field) {
    switch (field) {
      case 'salaryMin': return job.salary ? job.salary.min : 0;
      case 'salaryMax': return job.salary ? job.salary.max : 0;
      case 'tags': return (job.tags || []).join(' ');
      case 'hrActive': return job.hrActive ? '是' : '否';
      case 'publishDays': return typeof job.publishDays === 'number' ? job.publishDays : 0;
      default: return job[field] === undefined || job[field] === null ? '' : String(job[field]);
    }
  }

  BAA.evalRule = function (job, rule) {
    var v = fieldValue(job, rule.field);
    var target = String(rule.value === undefined ? '' : rule.value);
    switch (rule.op) {
      case 'contains': return v.toLowerCase().indexOf(target.toLowerCase()) >= 0;
      case 'notContains': return v.toLowerCase().indexOf(target.toLowerCase()) < 0;
      case 'equals': return v.trim() === target.trim();
      case 'notEmpty': return v.trim().length > 0;
      case 'gt': return Number(v) > Number(target);
      case 'lt': return Number(v) < Number(target);
      case 'regex':
        try { return new RegExp(target, 'i').test(v); } catch (e) { return false; }
      default: return true;
    }
  };

  function arr(x) { return Array.isArray(x) ? x.filter(function (i) { return String(i).trim(); }) : []; }
  function has(hay, words, mode) {
    var list = arr(words);
    if (!list.length) return true;
    var h = String(hay || '').toLowerCase();
    var hits = list.filter(function (w) { return h.indexOf(String(w).toLowerCase()) >= 0; });
    return mode === 'all' ? hits.length === list.length : hits.length > 0;
  }
  function noneOf(hay, words) {
    return !arr(words).some(function (w) { return String(hay || '').toLowerCase().indexOf(String(w).toLowerCase()) >= 0; });
  }
  function fail(reason) { return { pass: false, reason: reason, score: 0 }; }

  BAA.matchJob = function (job, cfg) {
    var f = (cfg && cfg.filter) || {};
    var title = job.title || '';
    var company = job.company || '';
    var tagsText = (job.tags || []).join(' ');
    var blob = [title, company, tagsText, job.companyInfo || '', job.rawText || ''].join(' ');

    if (!title) return fail('未能解析岗位名称');

    if (arr(f.titleIncludeAny).length && !has(title, f.titleIncludeAny, 'any')) return fail('岗位名未命中包含词');
    if (arr(f.titleIncludeAll).length && !has(title, f.titleIncludeAll, 'all')) return fail('岗位名未同时命中全部词');
    if (!noneOf(title, f.titleExclude)) return fail('岗位名命中排除词');

    if (arr(f.companyInclude).length && !has(company, f.companyInclude, 'any')) return fail('公司名未命中包含词');
    if (!noneOf(company, f.companyExclude)) return fail('公司名命中排除词');

    if (arr(f.tagIncludeAny).length && !has(tagsText + ' ' + (job.rawText || ''), f.tagIncludeAny, 'any')) return fail('未命中期望标签');
    if (!noneOf(tagsText + ' ' + (job.rawText || ''), f.tagExclude)) return fail('命中排除标签');

    if (arr(f.cities).length && !arr(f.cities).some(function (c) {
      return (job.area || job.city || '').indexOf(c) >= 0;
    })) return fail('城市不符');

    if (f.excludeOutsource && /外包|驻场|人力派遣|劳务派遣|外派|外包岗/.test(blob)) return fail('疑似外包/驻场岗位');

    var sal = job.salary || { min: 0, max: 0, daily: true };
    if (!sal.daily) {
      if (Number(f.salaryMin) > 0 && sal.max > 0 && sal.max < Number(f.salaryMin)) return fail('薪资上限低于期望下限');
      if (Number(f.salaryMax) > 0 && sal.min > 0 && sal.min > Number(f.salaryMax)) return fail('薪资下限高于设置上限');
    }

    if (arr(f.experienceAllow).length && !arr(f.experienceAllow).some(function (e) {
      return (job.experience || '经验不限').indexOf(e) >= 0 || e === '不限';
    })) return fail('经验要求不符');

    if (arr(f.educationAllow).length && !arr(f.educationAllow).some(function (e) {
      return (job.education || '学历不限').indexOf(e) >= 0 || e === '不限';
    })) return fail('学历要求不符');

    // Search-result cards do not expose company size / funding stage / publish
    // date. Only apply those rules when the field was actually parsed; otherwise
    // they would silently reject every single job.
    if (arr(f.companySizeAllow).length && job.companySize && !arr(f.companySizeAllow).some(function (e) {
      return (job.companySize || '').indexOf(e) >= 0;
    })) return fail('公司规模不符');

    if (arr(f.companyStageAllow).length && job.companyStage && !arr(f.companyStageAllow).some(function (e) {
      return (job.companyStage || '').indexOf(e) >= 0;
    })) return fail('融资阶段不符');

    if (f.hrActiveOnly && !job.hrActive) return fail('HR 不活跃');

    if (Number(f.maxPublishDays) > 0 && typeof job.publishDays === 'number' && job.publishDays > Number(f.maxPublishDays)) {
      return fail('发布过久');
    }

    if (f.titleRegex) {
      try { if (!new RegExp(f.titleRegex, 'i').test(title)) return fail('岗位名正则不匹配'); }
      catch (e) { return fail('岗位名正则写法有误'); }
    }
    if (f.companyRegex) {
      try { if (!new RegExp(f.companyRegex, 'i').test(company)) return fail('公司名正则不匹配'); }
      catch (e) { return fail('公司名正则写法有误'); }
    }

    var rules = (cfg.advancedRules || []).filter(function (r) {
      return r && r.enabled !== false && r.field && (r.op === 'notEmpty' || String(r.value || '').trim());
    });
    if (rules.length) {
      var results = rules.map(function (r) { return BAA.evalRule(job, r); });
      var ok = cfg.advancedMode === 'any' ? results.some(Boolean) : results.every(Boolean);
      if (!ok) return fail('高级规则未满足');
    }

    var score = arr(f.titleIncludeAny).filter(function (w) { return title.indexOf(w) >= 0; }).length
      + arr(f.tagIncludeAny).filter(function (w) { return tagsText.indexOf(w) >= 0; }).length;
    return { pass: true, reason: '匹配', score: score };
  };
})(typeof window !== 'undefined' ? window : globalThis);
