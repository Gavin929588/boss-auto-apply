(function (root) {
  'use strict';

  var BAA = (root.BAA = root.BAA || {});
  var D = BAA.dom;

  BAA.KEYS.LOGIN = 'baa.login';

  /* ------------------------------------------------------------------ *
   * v2.6 login self-check — single source of truth, page-independent.
   *
   * Problems this replaces:
   *  1. The old check ran ONLY in the content script, so the popup could only
   *     report "未连接 / 未知" whenever the current tab was not a page where the
   *     content script had been (re)injected (e.g. after switching platform or
   *     reloading the extension).
   *  2. It relied on DOM markers alone and on a BOSS-shaped cookie whitelist, so
   *     an already signed-in 鱼泡 account could still come back "unknown".
   *
   * Now the background worker answers BAA_CHECK_LOGIN for a given platform using
   * two independent sources:
   *   A. cookie probe — the platform's session cookie (USERID / current_identity
   *      on 鱼泡, zp_at / geek_zp_token on BOSS). A session cookie only exists
   *      after a real sign-in, so this is strong evidence and needs no page.
   *   B. DOM probe — injected into any open tab of that platform, looking for a
   *      visible guest entry vs. a signed-in user menu.
   * A positive cookie result always wins over a stale/hidden guest marker.
   * ------------------------------------------------------------------ */

  function loginCfg(cfg) {
    var base = {
      sessionCookies: [], guestSelectors: [], guestTexts: [],
      loggedSelectors: [], loggedTexts: [], cookieNames: []
    };
    return BAA.merge(base, (cfg && cfg.login) || {});
  }

  // Self-contained on purpose: this exact function body is serialised into the
  // page by background.js via chrome.scripting.executeScript, so it must not
  // reference anything outside its own arguments.
  BAA.loginDomProbe = function (spec) {
    spec = spec || {};
    function vis(e) {
      if (!e) return false;
      var r = e.getBoundingClientRect();
      if (!(r.width > 0 && r.height > 0)) return false;
      var st = getComputedStyle(e);
      return st.visibility !== 'hidden' && st.display !== 'none';
    }
    var out = {
      logged: false, guest: false, loggedBy: '', guestBy: '',
      url: location.href, title: document.title
    };
    var ls = spec.loggedSelectors || [];
    for (var i = 0; i < ls.length; i++) {
      try {
        if (document.querySelector(ls[i])) { out.logged = true; out.loggedBy = ls[i]; break; }
      } catch (e) { /* bad selector */ }
    }
    var allText = String((document.body && document.body.textContent) || '').replace(/\s+/g, ' ');
    if (!out.logged) {
      var lt = (spec.loggedTexts || []).filter(function (t) { return allText.indexOf(t) >= 0; });
      if (lt.length) { out.logged = true; out.loggedBy = '文本:' + lt[0]; }
    }
    var gs = spec.guestSelectors || [];
    for (var j = 0; j < gs.length && !out.guest; j++) {
      try {
        var els = document.querySelectorAll(gs[j]);
        for (var k = 0; k < els.length; k++) {
          var t = String(els[k].innerText || els[k].textContent || '').replace(/\s+/g, ' ').trim();
          if (!vis(els[k])) continue;
          if (t.length > 24) continue;
          out.guest = true; out.guestBy = gs[j] + ':' + t.slice(0, 12);
          break;
        }
      } catch (e) { /* bad selector */ }
    }
    if (!out.guest) {
      // innerText excludes display:none, so a hidden "登录丨注册" can't trip this.
      var bodyText = String((document.body && document.body.innerText) || '').slice(0, 1500);
      var gt = (spec.guestTexts || []).filter(function (t) { return bodyText.indexOf(t) >= 0; });
      if (gt.length) { out.guest = true; out.guestBy = '文本:' + gt[0]; }
    }
    return out;
  };

  function firstVisible(scope, selectors) {
    var ss = D.list(selectors);
    for (var i = 0; i < ss.length; i++) {
      try {
        var els = scope.querySelectorAll(ss[i]);
        for (var j = 0; j < els.length; j++) if (D.visible(els[j])) return els[j];
      } catch (e) { /* bad selector */ }
    }
    return null;
  }

  // Local DOM-only verdict. Used as the fallback when the background worker is
  // unreachable (and by the content script for extra detail).
  BAA.checkLoginDom = function (cfg, doc) {
    doc = doc || document;
    var L = loginCfg(cfg);
    var body = D.txt(doc.body).slice(0, 1800);
    var allText = String((doc.body && doc.body.textContent) || '').replace(/\s+/g, ' ');

    var guestEl = firstVisible(doc, L.guestSelectors);
    var hitText = (L.guestTexts || []).filter(function (t) { return body.indexOf(t) >= 0; });

    var loggedEl = D.q(doc, L.loggedSelectors);
    var loggedTextHits = (L.loggedTexts || []).filter(function (t) { return allText.indexOf(t) >= 0; });
    var hasLogged = !!loggedEl || loggedTextHits.length > 0;
    var evidence = loggedEl ? ('检测到已登录用户菜单（' + loggedEl.tagName + '）')
      : (loggedTextHits.length ? '检测到已登录用户菜单（' + loggedTextHits[0] + '）' : '');

    if (hasLogged) return { status: 'ok', reason: evidence };
    if (guestEl) return { status: 'required', reason: '页面出现登录入口（' + (guestEl.className || guestEl.tagName) + '）' };
    if (hitText.length) return { status: 'required', reason: '页面出现登录提示：' + hitText[0] };
    return { status: 'unknown', reason: '当前页面未找到明确的登录态标记' };
  };

  // Snapshot keeps NO cookie values — only which marker proved the session.
  BAA.getLoginSnapshot = function () {
    return chrome.storage.local.get(BAA.KEYS.LOGIN).then(function (d) {
      return d[BAA.KEYS.LOGIN] || null;
    });
  };
  BAA.saveLoginSnapshot = function (snap) {
    var o = {}; o[BAA.KEYS.LOGIN] = snap; return chrome.storage.local.set(o);
  };
  BAA.clearLoginSnapshot = function () {
    return chrome.storage.local.remove(BAA.KEYS.LOGIN);
  };

  BAA.checkLogin = async function (cfg) {
    var platform = (cfg && cfg.platform) || 'boss';
    try {
      var r = await chrome.runtime.sendMessage({ type: 'BAA_CHECK_LOGIN', platform: platform });
      if (r && r.ok) {
        if (r.snapshot) await BAA.saveLoginSnapshot(r.snapshot);
        return { status: r.status, reason: r.reason, snapshot: r.snapshot, source: 'background' };
      }
    } catch (e) { /* worker asleep / extension reloading -> local fallback */ }

    var dom = BAA.checkLoginDom(cfg);
    var snap = {
      checkedAt: Date.now(), platform: platform, status: dom.status,
      reason: dom.reason, source: 'local-dom', evidence: []
    };
    await BAA.saveLoginSnapshot(snap);
    return { status: dom.status, reason: dom.reason, snapshot: snap, source: 'local-dom' };
  };

  BAA.loginSnapshotText = function (snap) {
    if (!snap) return '尚未自检';
    var d = new Date(snap.checkedAt || Date.now());
    var src = snap.source === 'background' ? '后台判定' : (snap.source === 'local-dom' ? '本地判定' : '');
    return '平台 ' + (snap.platformName || snap.platform || '-') + ' · ' + (src ? src + ' · ' : '') +
      '自检于 ' + d.toLocaleString('zh-CN');
  };
})(typeof window !== 'undefined' ? window : globalThis);
