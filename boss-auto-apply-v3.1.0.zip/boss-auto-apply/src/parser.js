(function (root) {
  'use strict';

  var BAA = (root.BAA = root.BAA || {});
  var D = (BAA.dom = {});

  D.list = function (x) { return Array.isArray(x) ? x : (x ? [x] : []); };
  D.txt = function (el) {
    return el ? String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim() : '';
  };
  D.visible = function (el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
  };
  D.q = function (scope, selectors) {
    var ss = D.list(selectors);
    for (var i = 0; i < ss.length; i++) {
      try { var r = scope.querySelector(ss[i]); if (r) return r; } catch (e) { /* bad selector */ }
    }
    return null;
  };
  D.qa = function (scope, selectors) {
    var ss = D.list(selectors);
    for (var i = 0; i < ss.length; i++) {
      try { var r = scope.querySelectorAll(ss[i]); if (r && r.length) return Array.prototype.slice.call(r); } catch (e) { /* bad selector */ }
    }
    return [];
  };
  D.hit = function (selectors, doc) {
    doc = doc || document;
    var ss = D.list(selectors);
    for (var i = 0; i < ss.length; i++) {
      try { if (doc.querySelectorAll(ss[i]).length) return ss[i]; } catch (e) { /* bad selector */ }
    }
    return '';
  };

  BAA.findCards = function (cfg, doc) {
    doc = doc || document;
    return D.qa(doc, cfg.selectors.jobCard).filter(function (c) {
      return D.visible(c) && D.q(c, cfg.selectors.title);
    });
  };

  BAA.findChatButton = function (cfg, doc) {
    doc = doc || document;
    var box = D.q(doc, cfg.selectors.detailBox);
    return (box && D.q(box, cfg.selectors.chatButton)) || D.q(doc, cfg.selectors.chatButton) || null;
  };

  BAA.chatMatchesJob = function (chatEl, job) {
    if (!chatEl || !job || !job.id) return false;
    var ka = chatEl.getAttribute('ka') || '';
    var href = chatEl.getAttribute('href') || '';
    return ka.indexOf(job.id) >= 0 || href.indexOf(job.id) >= 0;
  };

  var EXP_RE = /^(应届生?|在校生?|经验不限|\d+年以内|\d+-\d+年|\d+年以上)$/;
  var EDU_RE = /^(学历不限|初中及以下|中专|中技|高中|大专|本科|硕士|博士)$/;

  // yupao's job cards use minified/auto-generated class names, so we parse by
  // DOM STRUCTURE rather than class names:
  //   card = a[href^="/zhaogong/{id}/{code}.html"]
  //   title = the nested <div><div><div> (accbd) inside the link
  //   salary = a <span> whose text matches a salary pattern
  //   tags = the sibling <div> (accbj) holding several <span>s
  //   company = the sibling <a href^="/qiye/"> (outside the link)
  //   area = the region span (contains "·") near the company
  BAA.parseCardYupao = function (card, cfg, index) {
    if (card.__baaJob) return card.__baaJob;
    var href = card.getAttribute('href') || (card.href || '');
    var abs = href.indexOf('http') === 0 ? href : ('https://www.yupao.com' + href);
    var m = abs.match(/\/zhaogong\/([^/]+)\/([^./?#]+)/);
    var id = m ? (m[1] + '/' + m[2]) : BAA.hash((card.innerText || '').slice(0, 40));

    var container = card.closest && card.closest('[data-index]');
    if (!container) container = card.parentElement || card;

    var titleEl = card.querySelector('div div div');
    var title = titleEl ? D.txt(titleEl) : D.txt(card).split(/\s{2,}/)[0];
    if (!title) {
      var a2 = card.querySelector('a');
      if (a2) title = D.txt(a2).split(/\s{2,}/)[0] || D.txt(a2);
    }

    var rawText = D.txt(card).replace(/\s+/g, ' ');
    var salMatch = rawText.match(/\d+(?:\.\d+)?\s*[-~]\s*\d+(?:\.\d+)?\s*(?:元|千|万|k|K)\s*(?:\/月|\/天|\/年|每月|每天|月|天)?/)
      || rawText.match(/\d+(?:\.\d+)?\s*(?:元|千|万|k|K)\s*(?:\/月|\/天|\/年|每月|每天|月|天)/);
    var salaryText = salMatch ? salMatch[0] : '';

    var companyEl = container.querySelector('a[href^="/qiye/"]');
    var company = companyEl ? D.txt(companyEl) : '';
    var area = '';
    var spans = container.querySelectorAll('span');
    for (var i = 0; i < spans.length; i++) {
      var st = D.txt(spans[i]);
      if (/·|省|市|区|县/.test(st) && st.length < 30) { area = st; break; }
    }

    // tags: the <div> that holds several <span>s (experience / education / ...)
    var tagSpans = [];
    var divs = card.querySelectorAll('div');
    for (var j = 0; j < divs.length; j++) {
      var sp = divs[j].querySelectorAll('span');
      if (sp.length >= 2) {
        for (var k = 0; k < sp.length; k++) tagSpans.push(D.txt(sp[k]));
      }
    }
    var tags = tagSpans.filter(function (t) { return t && t !== title; });

    var salaryHidden = !salaryText;
    var experience = tags.filter(function (t) { return /年|经验|应届|在校|不限/.test(t); })[0] || '经验不限';
    var education = tags.filter(function (t) { return /学历|中专|中技|高中|大专|本科|硕士|博士|不限/.test(t); })[0] || '学历不限';
    var city = (area || '').split(/[·|\/\s]/)[0].replace(/[省市]$/, '') || '';

    var job = {
      id: id, index: index || 0, title: title, company: company, salaryText: salaryText,
      salaryHidden: salaryHidden, salary: BAA.parseSalary(salaryText), city: city, area: area,
      experience: experience, education: education, tags: tags, tagsText: tags.join(' '),
      companyInfo: area, companySize: '', companyStage: '', hrActive: false, publishDays: 0,
      link: abs, rawText: rawText, el: card
    };
    card.__baaJob = job;
    return job;
  };

  BAA.parseCard = function (card, cfg, index) {
    if (card.__baaJob) return card.__baaJob;
    if (cfg && cfg.platform === 'yupao') return BAA.parseCardYupao(card, cfg, index);

    var title = D.txt(D.q(card, cfg.selectors.title));
    var salaryText = D.txt(D.q(card, cfg.selectors.salary));
    var company = D.txt(D.q(card, cfg.selectors.company));
    var area = D.txt(D.q(card, cfg.selectors.companyInfo));
    var tags = D.qa(card, cfg.selectors.tagList).map(D.txt).filter(Boolean);
    var linkEl = D.q(card, cfg.selectors.link);
    var link = linkEl ? (linkEl.href || linkEl.getAttribute('href') || '') : '';
    var rawText = D.txt(card);

    if (!title) {
      var a = card.querySelector('a[href*="job_detail"]');
      if (a) title = D.txt(a).split(/\s{2,}/)[0] || D.txt(a);
    }
    if (!salaryText) {
      var sm = rawText.match(/\d+(?:\.\d+)?\s*[-~]\s*\d+(?:\.\d+)?\s*[Kk万千]/);
      if (sm) salaryText = sm[0];
    }
    if (!company) {
      var cn = card.querySelector('[class*="company-name"], [class*="boss-name"]');
      if (cn) company = D.txt(cn);
    }

    var idMatch = String(link).match(/job_detail\/([^.\/?#]+)/);
    var id = idMatch ? idMatch[1] : BAA.hash(company + '|' + title + '|' + area);
    var salaryHidden = !salaryText || !!D.q(card, '.zp-hide-salary');

    var experience = tags.filter(function (t) { return EXP_RE.test(t); })[0]
      || (rawText.match(EXP_RE) || [])[0] || '经验不限';
    var education = tags.filter(function (t) { return EDU_RE.test(t); })[0]
      || (rawText.match(new RegExp(EDU_RE.source, 'g')) || [])[0] || '学历不限';

    var city = (area || '').split(/[·|\/\s]/)[0].replace(/市$/, '') || '';
    var hrActive = !!D.q(card, '.boss-online-icon') || /刚刚活跃|今日活跃|在线/.test(rawText);

    var job = {
      id: id,
      index: index || 0,
      title: title,
      company: company,
      salaryText: salaryText,
      salaryHidden: salaryHidden,
      salary: BAA.parseSalary(salaryText),
      city: city,
      area: area,
      experience: experience,
      education: education,
      tags: tags,
      tagsText: tags.join(' '),
      companyInfo: area,
      companySize: '',
      companyStage: '',
      hrActive: hrActive,
      publishDays: 0,
      link: link,
      rawText: rawText,
      el: card
    };
    card.__baaJob = job;
    return job;
  };

  BAA.calibrate = function (cfg, doc) {
    doc = doc || document;
    var cards = BAA.findCards(cfg, doc);
    var chat = BAA.findChatButton(cfg, doc);
    var detail = D.q(doc, cfg.selectors.detailBox);
    var allChat = Array.prototype.slice.call(doc.querySelectorAll('a,button,span,div'))
      .filter(function (e) {
        return e.children.length === 0 && /立即沟通|继续沟通|马上沟通|投简历|立即投递/.test(D.txt(e));
      }).slice(0, 12).map(function (e) {
        return { tag: e.tagName, cls: String(e.className || ''), text: D.txt(e), ka: e.getAttribute('ka') || '' };
      });
    return {
      url: (doc.location || location).href,
      cardCount: cards.length,
      cardSelector: D.hit(cfg.selectors.jobCard, doc),
      titleSelector: D.hit(cfg.selectors.title, doc),
      salarySelector: D.hit(cfg.selectors.salary, doc),
      companySelector: D.hit(cfg.selectors.company, doc),
      chatSelector: D.hit(cfg.selectors.chatButton, doc),
      detailBoxSelector: D.hit(cfg.selectors.detailBox, doc),
      chatFound: !!chat,
      chatClass: chat ? String(chat.className || '') : '',
      chatKa: chat ? (chat.getAttribute('ka') || '') : '',
      detailName: detail ? D.txt(D.q(detail, cfg.selectors.detailName) || D.q(detail, '.job-name')) : '',
      allChat: allChat,
      samples: cards.slice(0, 3).map(function (c, i) {
        var j = BAA.parseCard(c, cfg, i);
        return {
          id: j.id, title: j.title, company: j.company, salary: j.salaryText,
          salaryHidden: j.salaryHidden, area: j.area, tags: j.tags,
          experience: j.experience, education: j.education, link: j.link
        };
      })
    };
  };
})(typeof window !== 'undefined' ? window : globalThis);
