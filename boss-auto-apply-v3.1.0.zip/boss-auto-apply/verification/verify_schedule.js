/* v2.4 fixed time-window scheduler - Node unit tests (no browser needed).
 * Run: node verification/verify_schedule.js
 */
'use strict';
const assert = require('assert');
const path = require('path');

// --- minimal chrome.storage.local mock, installed BEFORE config.js loads ---
const store = {};
global.chrome = {
  runtime: { sendMessage: () => Promise.resolve({}) },
  storage: {
    local: {
      get(keys) {
        if (typeof keys === 'string') return Promise.resolve({ [keys]: store[keys] });
        if (Array.isArray(keys)) {
          const out = {};
          keys.forEach(k => { if (k in store) out[k] = store[k]; });
          return Promise.resolve(out);
        }
        return Promise.resolve(Object.assign({}, store));
      },
      set(o) { Object.assign(store, o); return Promise.resolve(); },
      remove(k) { delete store[k]; return Promise.resolve(); }
    }
  }
};

require(path.join(__dirname, '..', 'src', 'config.js'));
const BAA = globalThis.BAA;

let passed = 0, failed = 0;
const results = [];
function t(name, fn) {
  try { fn(); passed++; results.push({ name, pass: true }); }
  catch (e) { failed++; results.push({ name, pass: false, error: String(e && e.message || e) }); }
}
async function ta(name, fn) {
  try { await fn(); passed++; results.push({ name, pass: true }); }
  catch (e) { failed++; results.push({ name, pass: false, error: String(e && e.message || e) }); }
}

const D = (day, h, m) => new Date(2026, 10, day, h || 0, m || 0, 0, 0).getTime();
const sch = (o) => Object.assign({
  enabled: true,
  weekdays: [0, 1, 2, 3, 4, 5, 6],
  windows: [{ start: '09:00', end: '12:00', enabled: true },
            { start: '14:00', end: '18:00', enabled: true }],
  onWindowEnd: 'pause'
}, o || {});

/* ---- parseClock ---- */
t('parseClock 正常值', () => {
  assert.strictEqual(BAA.parseClock('09:00'), 540);
  assert.strictEqual(BAA.parseClock('9:05'), 545);
  assert.strictEqual(BAA.parseClock('23:59'), 1439);
  assert.strictEqual(BAA.parseClock('00:00'), 0);
});
t('parseClock 拒绝非法值', () => {
  ['', '24:00', '12:60', 'abc', '9', null, undefined, '12:0'].forEach(v =>
    assert.strictEqual(BAA.parseClock(v), -1, String(v)));
});

/* ---- disabled / empty configs ---- */
t('默认配置：定时关闭', () => {
  const st = BAA.scheduleStatus(BAA.DEFAULT_CONFIG.schedule, D(4, 10));
  assert.strictEqual(st.enabled, false);
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.reason, 'disabled');
});
t('开启但无有效窗口', () => {
  const st = BAA.scheduleStatus(sch({ windows: [] }), D(4, 10));
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.reason, 'no-windows');
});
t('开启但未选执行日', () => {
  const st = BAA.scheduleStatus(sch({ weekdays: [] }), D(4, 10));
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.reason, 'no-weekdays');
});
t('开始=结束的窗口被忽略', () => {
  const st = BAA.scheduleStatus(sch({ windows: [{ start: '09:00', end: '09:00' }] }), D(4, 10));
  assert.strictEqual(st.reason, 'no-windows');
});

/* ---- basic window boundaries ---- */
t('窗口起点包含 / 终点排除', () => {
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 9, 0)).active, true);
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 8, 59)).active, false);
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 11, 59)).active, true);
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 12, 0)).active, false);
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 14, 0)).active, true);
  assert.strictEqual(BAA.scheduleStatus(sch(), D(4, 18, 0)).active, false);
});
t('窗口标签与起止时间正确', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 10, 30));
  assert.strictEqual(st.windowLabel, '09:00-12:00');
  assert.strictEqual(new Date(st.windowStart).getHours(), 9);
  assert.strictEqual(new Date(st.windowEnd).getHours(), 12);
  assert.strictEqual(st.windowIndex, 0);
});
t('第二个窗口命中 index=1', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 15));
  assert.strictEqual(st.active, true);
  assert.strictEqual(st.windowIndex, 1);
  assert.strictEqual(st.windowLabel, '14:00-18:00');
});

/* ---- next start / next change ---- */
t('早于首窗口 -> nextStartAt 今天 09:00', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 8));
  assert.strictEqual(st.nextStartAt, D(4, 9));
  assert.strictEqual(st.nextChangeAt, D(4, 9));
  assert.strictEqual(st.boundaryType, 'start');
});
t('两窗口之间 -> nextStartAt 今天 14:00', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 12, 30));
  assert.strictEqual(st.nextStartAt, D(4, 14));
  assert.strictEqual(st.nextChangeAt, D(4, 14));
});
t('窗口内 -> nextChangeAt 是该窗口结束', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 10));
  assert.strictEqual(st.nextChangeAt, D(4, 12));
  assert.strictEqual(st.boundaryType, 'end');
});
t('当天窗口全过 -> nextStartAt 次日 09:00', () => {
  const st = BAA.scheduleStatus(sch(), D(4, 19));
  assert.strictEqual(st.nextStartAt, D(5, 9));
  assert.strictEqual(st.nextChangeAt, D(5, 9));
});

/* ---- weekday filter ---- */
t('仅工作日：周三 10:00 在窗口内', () => {
  assert.strictEqual(BAA.scheduleStatus(sch({ weekdays: [1, 2, 3, 4, 5] }), D(4, 10)).active, true);
});
t('仅工作日：周六 10:00 不在窗口内，下次是周一', () => {
  // 2026-11-04 is Wednesday, so 11-07 is Saturday and 11-09 is Monday.
  const st = BAA.scheduleStatus(sch({ weekdays: [1, 2, 3, 4, 5] }), D(7, 10));
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.nextStartAt, D(9, 9));
});
t('仅周末：周三不在窗口内', () => {
  const st = BAA.scheduleStatus(sch({ weekdays: [0, 6] }), D(4, 10));
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.nextStartAt, D(7, 9));
});

/* ---- cross-midnight ---- */
t('跨午夜 22:00-02:00：当晚 23:30 命中，终点为次日 02:00', () => {
  const st = BAA.scheduleStatus(sch({ windows: [{ start: '22:00', end: '02:00', enabled: true }] }), D(4, 23, 30));
  assert.strictEqual(st.active, true);
  assert.strictEqual(st.windowEnd, D(5, 2));
});
t('跨午夜：次日 01:00 仍命中（归属前一晚的窗口）', () => {
  const st = BAA.scheduleStatus(sch({ windows: [{ start: '22:00', end: '02:00', enabled: true }] }), D(5, 1));
  assert.strictEqual(st.active, true);
  assert.strictEqual(st.windowStart, D(4, 22));
});
t('跨午夜：次日 02:00 起不再命中', () => {
  const st = BAA.scheduleStatus(sch({ windows: [{ start: '22:00', end: '02:00', enabled: true }] }), D(5, 2, 1));
  assert.strictEqual(st.active, false);
});
t('跨午夜 + 工作日：周六凌晨仍属周五窗口', () => {
  const st = BAA.scheduleStatus(sch({
    weekdays: [1, 2, 3, 4, 5],
    windows: [{ start: '22:00', end: '02:00', enabled: true }]
  }), D(7, 1));
  assert.strictEqual(st.active, true);
  assert.strictEqual(st.windowStart, D(6, 22));
});

/* ---- disabled windows / overlapping windows ---- */
t('enabled=false 的时间段被忽略', () => {
  const st = BAA.scheduleStatus(sch({ windows: [
    { start: '09:00', end: '12:00', enabled: false },
    { start: '14:00', end: '18:00', enabled: true }
  ] }), D(4, 10));
  assert.strictEqual(st.active, false);
  assert.strictEqual(st.nextStartAt, D(4, 14));
});
t('重叠窗口：nextChangeAt 是真正退出时段的 12:00', () => {
  const st = BAA.scheduleStatus(sch({ windows: [
    { start: '09:00', end: '12:00', enabled: true },
    { start: '10:00', end: '11:00', enabled: true }
  ] }), D(4, 9, 30));
  assert.strictEqual(st.active, true);
  assert.strictEqual(st.nextChangeAt, D(4, 12));
  assert.strictEqual(st.boundaryType, 'end');
});

/* ---- full-day sweep ---- */
t('整天逐分钟扫描：恰好 420 分钟在 09-12 / 14-18 内', () => {
  let n = 0;
  for (let m = 0; m < 1440; m++) {
    const ts = D(4, 0, 0) + m * 60000;
    if (BAA.scheduleStatus(sch(), ts).active) n++;
  }
  assert.strictEqual(n, 420);
});

/* ---- summary ---- */
t('scheduleSummary 文案', () => {
  assert.ok(BAA.scheduleSummary(BAA.DEFAULT_CONFIG.schedule).indexOf('未启用') >= 0);
  assert.ok(BAA.scheduleSummary(sch()).indexOf('每天 09:00-12:00、14:00-18:00') >= 0);
  assert.ok(BAA.scheduleSummary(sch({ weekdays: [1, 2, 3, 4, 5] })).indexOf('工作日') >= 0);
  assert.ok(BAA.scheduleSummary(sch({ weekdays: [0, 6] })).indexOf('周末') >= 0);
});

/* ---- config migration / runtime helpers ---- */
(async function main() {
  await ta('getConfig 迁移补齐 schedule 并写回 __v24', async () => {
    store['baa.config'] = { behavior: { dailyLimit: 40 }, tasks: [{ query: 'x', city: '101280600' }] };
    const cfg = await BAA.getConfig();
    assert.strictEqual(cfg.behavior.dailyLimit, 40, '保留用户旧设置');
    assert.strictEqual(cfg.behavior.chatGreetingEnabled, true, 'v2.2 迁移仍生效');
    assert.ok(cfg.schedule, 'schedule 块存在');
    assert.strictEqual(cfg.schedule.enabled, false, '默认关闭，不改变旧行为');
    assert.strictEqual(cfg.schedule.windows.length, 2);
    // write-back is fire-and-forget inside getConfig; give it a microtask.
    await new Promise(r => setImmediate(r));
    assert.strictEqual(store['baa.config'].__v24, true);
    assert.ok(store['baa.config'].schedule);
  });

  await ta('setScheduleOverride 在窗口内写到窗口结束', async () => {
    const cfg = sch();
    const now = D(4, 10);
    const fakeNow = Date.now;
    Date.now = () => now;
    try {
      await BAA.setScheduleOverride({ schedule: cfg });
      const rt = await BAA.getScheduleRuntime();
      assert.strictEqual(rt.overrideUntil, D(4, 12));
      assert.strictEqual(rt.autoManaged, false);
      await BAA.clearScheduleOverride();
      assert.strictEqual((await BAA.getScheduleRuntime()).overrideUntil, 0);
    } finally { Date.now = fakeNow; }
  });

  await ta('takeAutoStart 是单次的', async () => {
    await BAA.setAutoStart({ pending: true, ts: 1, command: 'START', windowStart: 2 });
    const a = await BAA.takeAutoStart();
    assert.strictEqual(a.command, 'START');
    assert.strictEqual(await BAA.takeAutoStart(), null);
  });

  await ta('getLogs 合并页面/后台两条日志流并按时间排序', async () => {
    store['baa.logs'] = [{ ts: 2, level: 'info', msg: 'page' }];
    store['baa.bglogs'] = [{ ts: 1, level: 'info', msg: 'bg' }];
    const l = await BAA.getLogs();
    assert.deepStrictEqual(l.map(x => x.msg), ['bg', 'page']);
  });

  await ta('BAA.log 只写页面流，不复制后台日志（防重复）', async () => {
    await BAA.log('info', 'page2');
    assert.strictEqual(store['baa.logs'].length, 2);
    assert.strictEqual(store['baa.bglogs'].length, 1);
    const merged = await BAA.getLogs();
    assert.strictEqual(merged.filter(x => x.msg === 'bg').length, 1);
    assert.strictEqual(merged.length, 3);
  });

  await ta('clearLogs 同时清空两条日志流', async () => {
    await BAA.clearLogs();
    assert.strictEqual(store['baa.logs'].length, 0);
    assert.strictEqual(store['baa.bglogs'].length, 0);
    assert.strictEqual((await BAA.getLogs()).length, 0);
  });

  await ta('scheduleRuntime 默认值齐全', async () => {
    const rt = await BAA.getScheduleRuntime();
    ['lastDecision', 'activeWindowStart', 'overrideUntil', 'autoManaged', 'wasActive',
     'pauseGuardUntil'].forEach(k => assert.ok(k in rt, k));
  });

  const report = {
    at: new Date().toISOString(),
    version: BAA.VERSION,
    passed, failed, total: passed + failed,
    results
  };
  require('fs').writeFileSync(path.join(__dirname, 'verify_schedule_result.json'),
    JSON.stringify(report, null, 2), 'utf8');
  console.log('\n=== v2.4 schedule unit tests ===');
  results.forEach(r => console.log((r.pass ? 'PASS  ' : 'FAIL  ') + r.name +
    (r.pass ? '' : '  -> ' + r.error)));
  console.log('\n' + passed + '/' + (passed + failed) + ' passed');
  process.exit(failed ? 1 : 0);
})();
